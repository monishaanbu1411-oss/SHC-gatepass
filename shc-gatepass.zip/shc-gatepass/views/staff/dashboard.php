<?php /** Faculty landing page: what I issued, and what my department looks like now. */ ?>
<div class="row g-3 mb-3">
  <?php
  $tiles = [
    ['Students outside now', $dept['outside'],       'person-walking-arrow-right', 'bg-crimson', 'staff/monitor'],
    ['Passes I issued today', $stats['issued_today'], 'file-circle-plus',           'bg-navy',    'staff/history'],
    ['Waiting at the gate',   $stats['awaiting_exit'],'door-open',                  'bg-info',    'staff/history'],
    ['Overdue in department', $dept['overdue'],       'triangle-exclamation',       'bg-warn',    'staff/monitor'],
  ];
  foreach ($tiles as [$label, $num, $icon, $bg, $link]): ?>
    <div class="col-6 col-lg-3">
      <a class="stat" href="<?= url($link) ?>">
        <span class="stat-icon <?= $bg ?>"><i class="fa-solid fa-<?= $icon ?>"></i></span>
        <span>
          <span class="stat-num"><?= (int)$num ?></span>
          <span class="stat-label d-block"><?= e($label) ?></span>
        </span>
      </a>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-12 col-xl-7">
    <div class="card-x h-100">
      <div class="cx-head">
        <h2><i class="fa-solid fa-street-view me-2"></i>
          <?= Auth::isHod() ? 'Department students outside' : 'Students outside from my department' ?></h2>
        <a class="ms-auto btn btn-sm btn-outline-secondary" href="<?= url('staff/monitor') ?>">Open monitor</a>
      </div>
      <div class="cx-body p-0">
        <?php $showDept = false; require ROOT_PATH . '/views/layouts/_outside_table.php'; ?>
      </div>
    </div>
  </div>

  <div class="col-12 col-xl-5">
    <div class="card-x mb-3">
      <div class="cx-body d-flex align-items-center gap-3">
        <span class="stat-icon bg-crimson" style="width:52px;height:52px;flex:0 0 52px;font-size:1.3rem">
          <i class="fa-solid fa-file-circle-plus"></i>
        </span>
        <div class="flex-grow-1">
          <div style="font-family:var(--display);font-weight:600">Issue a movement pass</div>
          <div style="font-size:.82rem;color:var(--muted)">
            Pick your class, tick the students, approve. Takes about fifteen seconds.
          </div>
        </div>
        <a class="btn btn-shc" href="<?= url('staff/issue') ?>">Start</a>
      </div>
    </div>

    <div class="card-x">
      <div class="cx-head">
        <h2><i class="fa-solid fa-clock-rotate-left me-2"></i>Recently issued by me</h2>
      </div>
      <div class="cx-body p-0">
        <?php if (!$recent): ?>
          <div class="empty">
            <i class="fa-regular fa-file"></i>
            <strong>No passes yet</strong>
            Passes you approve will be listed here.
          </div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table-x">
              <thead><tr><th>Student</th><th>Reason</th><th>Out</th><th>Status</th></tr></thead>
              <tbody>
              <?php foreach ($recent as $p): ?>
                <tr>
                  <td>
                    <a href="<?= url('pass/view/' . $p['pass_uid']) ?>" style="font-weight:600"><?= e($p['student_name']) ?></a>
                    <span class="mono d-block" style="font-size:.74rem;color:var(--muted)"><?= e($p['register_no']) ?></span>
                  </td>
                  <td style="font-size:.82rem"><?= e(reason_label($p['reason_code'], $p['reason_other'])) ?></td>
                  <td class="mono" style="font-size:.79rem"><?= e(fmt_time($p['out_time'])) ?></td>
                  <td><span class="st <?= status_class($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
