<?php /** Live department monitor. Refreshes itself so an HOD can leave it open. */ ?>
<div class="row g-3 mb-3">
  <?php
  $tiles = [
    ['Outside now',      $stats['outside'],        'person-walking-arrow-right', 'bg-crimson'],
    ['Overdue',          $stats['overdue'],        'triangle-exclamation',       'bg-danger'],
    ['Issued today',     $stats['issued_today'],   'file-circle-plus',           'bg-navy'],
    ['Returned today',   $stats['returned_today'], 'right-to-bracket',           'bg-ok'],
  ];
  foreach ($tiles as [$label, $num, $icon, $bg]): ?>
    <div class="col-6 col-lg-3">
      <div class="stat">
        <span class="stat-icon <?= $bg ?>"><i class="fa-solid fa-<?= $icon ?>"></i></span>
        <span>
          <span class="stat-num" data-counter="<?= e(strtolower(str_replace(' ', '_', $label))) ?>"><?= (int)$num ?></span>
          <span class="stat-label d-block"><?= e($label) ?></span>
        </span>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="card-x">
  <div class="cx-head">
    <h2><i class="fa-solid fa-street-view me-2"></i><?= e($pageTitle) ?></h2>
    <span class="ms-auto d-flex align-items-center gap-2" style="font-size:.78rem;color:var(--muted)">
      <span class="spinner-grow spinner-grow-sm" style="color:var(--ok);width:.5rem;height:.5rem"></span>
      Live &middot; refreshes every 20 seconds
    </span>
  </div>
  <div class="cx-body p-0" id="outsideWrap">
    <?php require ROOT_PATH . '/views/layouts/_outside_table.php'; ?>
  </div>
</div>

<script>
(function () {
  const { apiGet, esc } = window.SHCApp;

  async function refresh() {
    const d = await apiGet('api/outside');
    if (!d.ok) return;
    const wrap = document.getElementById('outsideWrap');

    if (!d.rows.length) {
      wrap.innerHTML = `<div class="empty"><i class="fa-solid fa-user-check"></i>
        <strong>Everyone is on campus</strong>No student is currently outside.</div>`;
      return;
    }

    wrap.innerHTML = `<div class="table-responsive"><table class="table-x">
      <thead><tr><th>Student</th><th>Department</th><th>Approved by</th><th>Reason</th>
      <th>Out</th><th>Return by</th><th>Time left</th><th></th></tr></thead><tbody>` +
      d.rows.map((r) => `
        <tr${r.overdue ? ' style="background:rgba(192,40,31,.06)"' : ''}>
          <td><div class="d-flex align-items-center gap-2">
            ${r.photo ? `<img class="ava ava-sm" src="${esc(r.photo)}" alt="">`
                      : `<span class="ava ava-sm">${esc(r.initials)}</span>`}
            <span class="lh-1"><span class="d-block" style="font-weight:600">${esc(r.name)}</span>
            <span class="mono" style="font-size:.75rem;color:var(--muted)">${esc(r.register)}</span></span>
          </div></td>
          <td class="mono" style="font-size:.78rem">${esc(r.dept)}</td>
          <td style="font-size:.83rem">${esc(r.staff)}</td>
          <td style="font-size:.83rem">${esc(r.reason)}</td>
          <td class="mono" style="font-size:.8rem">${esc(r.out)}</td>
          <td class="mono" style="font-size:.8rem">${esc(r.expiry)}</td>
          <td><span class="countdown${r.overdue ? ' over' : ''}" data-countdown="${r.seconds}">—:—</span></td>
          <td><a class="btn btn-sm btn-outline-secondary" href="${r.url}">Pass</a></td>
        </tr>`).join('') + '</tbody></table></div>';

    window.SHCApp.tickCountdowns();
  }

  setInterval(refresh, 20000);
  document.addEventListener('shc:notified', refresh);
})();
</script>
