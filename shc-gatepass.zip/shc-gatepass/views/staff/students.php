<?php /** Department student directory, read-only for faculty. */ ?>
<div class="card-x">
  <div class="cx-head">
    <h2><i class="fa-solid fa-users me-2"></i>Students in my department</h2>
    <form class="ms-auto d-flex gap-2" method="get" action="<?= url('staff/students') ?>">
      <input class="form-control form-control-sm" name="q" value="<?= e($q) ?>"
             placeholder="Name or register number" style="width:230px">
      <button class="btn btn-sm btn-navy">Search</button>
    </form>
  </div>
  <div class="cx-body">
    <?php if (!$students): ?>
      <div class="empty">
        <i class="fa-solid fa-user-slash"></i>
        <strong>No students match that search</strong>
        Try a different name or register number.
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table-x" data-dt data-dt-nosort="[5]">
          <thead>
            <tr><th>Register No</th><th>Name</th><th>Class</th><th>Residence</th><th>Contact</th><th>Blood</th></tr>
          </thead>
          <tbody>
          <?php foreach ($students as $s): ?>
            <tr>
              <td class="mono" style="font-weight:600"><?= e($s['register_no']) ?></td>
              <td>
                <div class="d-flex align-items-center gap-2">
                  <?php if ($ph = photo_url($s['photo'])): ?>
                    <img class="ava ava-sm" src="<?= e($ph) ?>" alt="">
                  <?php else: ?>
                    <span class="ava ava-sm"><?= e(initials($s['name'])) ?></span>
                  <?php endif; ?>
                  <?= e($s['name']) ?>
                </div>
              </td>
              <td style="font-size:.82rem"><?= e($s['prog_name']) ?> &middot; Shift <?= e($s['shift']) ?></td>
              <td style="font-size:.82rem"><?= e($s['residence']) ?></td>
              <td class="mono" style="font-size:.78rem"><?= e($s['phone']) ?></td>
              <td class="mono" style="font-size:.78rem"><?= e($s['blood_group']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
