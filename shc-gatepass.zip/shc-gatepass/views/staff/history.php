<?php /** Every pass this faculty member has issued, searchable and exportable. */ ?>
<div class="card-x">
  <div class="cx-head">
    <h2><i class="fa-solid fa-clock-rotate-left me-2"></i>Passes I issued</h2>
    <span class="ms-auto" style="font-size:.8rem;color:var(--muted)"><?= count($passes) ?> records</span>
  </div>
  <div class="cx-body">
    <?php if (!$passes): ?>
      <div class="empty">
        <i class="fa-regular fa-file"></i>
        <strong>Nothing issued yet</strong>
        Start from the Issue movement pass screen.
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table-x" data-dt data-dt-order='[[3,"desc"]]' data-dt-nosort="[7]">
          <thead>
            <tr>
              <th>Pass ID</th><th>Student</th><th>Class</th><th>Issued</th>
              <th>Reason</th><th>Validity</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($passes as $p): ?>
            <tr>
              <td class="mono" style="font-size:.76rem"><?= e($p['pass_uid']) ?></td>
              <td>
                <span style="font-weight:600"><?= e($p['student_name']) ?></span>
                <span class="mono d-block" style="font-size:.74rem;color:var(--muted)"><?= e($p['register_no']) ?></span>
              </td>
              <td style="font-size:.8rem"><?= e($p['prog_name']) ?> &middot; Sh <?= e($p['shift']) ?></td>
              <td data-order="<?= e($p['created_at']) ?>" style="font-size:.8rem"><?= e(fmt_dt($p['created_at'])) ?></td>
              <td style="font-size:.82rem"><?= e(reason_label($p['reason_code'], $p['reason_other'])) ?></td>
              <td class="mono" style="font-size:.79rem"><?= e(fmt_mins((int)$p['validity_mins'])) ?></td>
              <td><span class="st <?= status_class($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
              <td><a class="btn btn-sm btn-outline-secondary" href="<?= url('pass/view/' . $p['pass_uid']) ?>">Open</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
