<?php
/**
 * Step 1: pick course, class section and hour, then tick students.
 * Step 2: a modal confirms reason, out time and validity, then approves.
 *
 * The layout intentionally mirrors the attendance-entry screen faculty
 * already use every day, so the only new thing to learn is the modal.
 */
?>
<div class="card-x mb-3">
  <div class="cx-head">
    <h2><i class="fa-solid fa-file-circle-plus me-2"></i>Issue movement pass</h2>
    <span class="ms-auto st st-approved">Step 1 of 2</span>
  </div>

  <div class="cx-body">
    <div class="row g-3 align-items-end">

      <div class="col-12 col-md-3">
        <label class="form-label" for="passDate">Date</label>
        <input class="form-control" id="passDate" value="<?= date('d/m/Y') ?>" readonly>
      </div>

      <div class="col-12 col-md-3">
        <label class="form-label" for="passTime">Current time</label>
        <input class="form-control mono" id="passTime" value="<?= date('h:i A') ?>" readonly>
      </div>

      <div class="col-12 col-md-6">
        <label class="form-label" for="courseSel">Course</label>
        <select class="form-select" id="courseSel">
          <option value="">-- Select Course --</option>
          <?php foreach ($courses as $c): ?>
            <option value="<?= (int)$c['id'] ?>"><?= e($c['code']) ?> - <?= e($c['title']) ?></option>
          <?php endforeach; ?>
        </select>
        <?php if (!$courses): ?>
          <div class="form-text text-danger">
            No courses are assigned to you yet. Ask the administrator to assign your course load.
          </div>
        <?php endif; ?>
      </div>

      <div class="col-12 col-md-6">
        <label class="form-label" for="progSel">Programme name</label>
        <select class="form-select" id="progSel" disabled>
          <option value="">-- Programme Name --</option>
        </select>
      </div>

      <div class="col-12 col-md-6">
        <label class="form-label">Hour (class period)</label>
        <div class="hour-pick" id="hourPick">
          <?php for ($h = 1; $h <= CLASS_HOURS; $h++): ?>
            <label><input type="checkbox" name="hours" value="<?= $h ?>"> <?= $h ?></label>
          <?php endfor; ?>
        </div>
      </div>
    </div>

    <hr class="my-3" style="border-color:var(--line)">

    <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
      <strong style="font-family:var(--display);font-size:.95rem">Student roster</strong>
      <span class="mono ms-1" id="rosterCount" style="color:var(--crimson);font-weight:700">#0/0</span>
      <span id="rosterLabel" style="color:var(--muted);font-size:.83rem"></span>

      <div class="ms-auto d-flex flex-wrap gap-2">
        <button class="btn btn-sm btn-outline-secondary" id="btnRefresh" type="button">
          <i class="fa-solid fa-rotate me-1"></i>Refresh
        </button>
        <button class="btn btn-sm btn-outline-secondary" id="btnNames" type="button">
          <i class="fa-solid fa-eye me-1"></i>View names
        </button>
        <button class="btn btn-sm btn-outline-secondary" id="btnClear" type="button">
          <i class="fa-solid fa-eraser me-1"></i>Clear
        </button>
      </div>
    </div>

    <div class="roster hide-names" id="roster">
      <div class="empty" style="grid-column:1/-1">
        <i class="fa-solid fa-list-check"></i>
        <strong>Choose a course and programme</strong>
        The class roster loads here.
      </div>
    </div>

    <div class="d-flex flex-wrap gap-2 align-items-center mt-3">
      <button class="btn btn-shc btn-lg" id="btnOpenForm" type="button" disabled>
        Open form <i class="fa-solid fa-arrow-right ms-1"></i>
      </button>
      <span style="color:var(--muted);font-size:.83rem">
        Tick every student going out, then open the approval form.
      </span>
    </div>
  </div>
</div>

<!-- ==================== STEP 2: verification & approval ==================== -->
<div class="modal fade" id="approveModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content" style="border-radius:var(--r);border-color:var(--line)">

      <div class="modal-header" style="background:var(--navy);color:#fff;border-radius:var(--r) var(--r) 0 0">
        <h5 class="modal-title" style="font-family:var(--display);color:#fff">
          Verify &amp; approve outpass
        </h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">

        <div class="card-x mb-3" style="box-shadow:none">
          <div class="cx-body py-2">
            <div class="d-flex align-items-center gap-2 mb-2">
              <strong style="font-size:.85rem">Selected students</strong>
              <span class="st st-approved" id="selCount">0</span>
              <span class="ms-auto mono" style="font-size:.78rem;color:var(--muted)" id="selClass"></span>
            </div>
            <div class="d-flex flex-wrap gap-2" id="selList"></div>
          </div>
        </div>

        <div class="row g-3">
          <div class="col-12 col-md-6">
            <label class="form-label" for="reasonSel">Reason for going out</label>
            <select class="form-select" id="reasonSel">
              <?php foreach (REASONS as $code => $label): ?>
                <option value="<?= e($code) ?>"><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-12 col-md-6">
            <label class="form-label" for="destInput">Destination <span style="text-transform:none;font-weight:400">(optional)</span></label>
            <input class="form-control" id="destInput" maxlength="160" placeholder="e.g. Govt. Hospital, Tirupattur">
          </div>

          <div class="col-12 d-none" id="otherWrap">
            <label class="form-label" for="otherText">Specify the reason</label>
            <textarea class="form-control" id="otherText" rows="2" maxlength="255"
                      placeholder="Write the reason exactly as it should appear on the pass"></textarea>
          </div>

          <div class="col-12 col-md-6">
            <label class="form-label" for="outTime">Out time</label>
            <input class="form-control mono" id="outTime" type="datetime-local"
                   value="<?= date('Y-m-d\TH:i') ?>">
          </div>

          <div class="col-12 col-md-6">
            <label class="form-label">Validity</label>
            <select class="form-select" id="validitySel">
              <?php foreach ([45, 60, 75, 90, 105, 120] as $m): ?>
                <option value="<?= $m ?>"<?= $m === 60 ? ' selected' : '' ?>><?= e(fmt_mins($m)) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="form-text" style="font-size:.74rem">
              College rule: between <?= (int)MIN_VALIDITY ?> minutes and <?= e(fmt_mins(MAX_VALIDITY)) ?>.
            </div>
          </div>

          <div class="col-12">
            <div class="alert mb-0 py-2" style="background:var(--surface-2);border:1px solid var(--line);font-size:.82rem">
              <i class="fa-solid fa-bell me-1" style="color:var(--crimson)"></i>
              On approval the student, the Head of Department and the gate are alerted at once.
              A return-before time of
              <strong class="mono" id="previewExpiry">—</strong>
              will be printed on the pass.
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Back to roster</button>
        <button class="btn btn-shc btn-lg" id="btnApprove">
          <i class="fa-solid fa-stamp me-1"></i> Approve outpass
        </button>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  const { api, apiGet, esc } = window.SHCApp;
  const $ = (s) => document.querySelector(s);

  const courseSel = $('#courseSel'), progSel = $('#progSel'), roster = $('#roster');
  const rosterCount = $('#rosterCount'), rosterLabel = $('#rosterLabel');
  const btnOpen = $('#btnOpenForm');
  let students = [], picked = new Set(), namesOn = false;

  // ---- keep the clock on the form honest -------------------------------
  setInterval(() => {
    const d = new Date();
    let h = d.getHours(); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
    $('#passTime').value = `${String(h).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')} ${ap}`;
  }, 1000);

  // ---- course -> programme --------------------------------------------
  async function loadProgrammes() {
    progSel.innerHTML = '<option value="">-- Programme Name --</option>';
    progSel.disabled = true;
    clearRoster('Choose a programme', 'Class sections you handle for this course appear above.');
    if (!courseSel.value) return;

    const d = await apiGet('api/programmes/' + courseSel.value);
    if (!d.ok || !d.rows.length) {
      clearRoster('No class assigned', 'You are not assigned to a class section for this course.');
      return;
    }
    d.rows.forEach((r) => {
      const o = document.createElement('option');
      o.value = r.id; o.textContent = r.label;
      progSel.appendChild(o);
    });
    progSel.disabled = false;
    if (d.rows.length === 1) { progSel.value = d.rows[0].id; loadRoster(); }
  }

  courseSel.addEventListener('change', loadProgrammes);
  progSel.addEventListener('change', loadRoster);
  $('#btnRefresh').addEventListener('click', () => {
    // Refresh should recover the whole chain, not just the roster.
    if (progSel.value) loadRoster(); else loadProgrammes();
  });

  // The browser restores form values on a reload or a Back navigation, but a
  // restored value fires no change event. Pick that up on load, otherwise the
  // programme list stays empty and disabled with a course already showing.
  // With a single assigned course, select it outright and save a click.
  if (!courseSel.value && courseSel.options.length === 2) {
    courseSel.selectedIndex = 1;
  }
  if (courseSel.value) loadProgrammes();

  // ---- roster ----------------------------------------------------------
  async function loadRoster() {
    picked.clear();
    if (!progSel.value) { clearRoster('Choose a programme', 'The class roster loads here.'); return; }

    roster.innerHTML = '<div class="empty" style="grid-column:1/-1">' +
      '<i class="fa-solid fa-spinner fa-spin"></i><strong>Loading roster…</strong></div>';

    const d = await apiGet('api/roster/' + progSel.value);
    if (!d.ok) { clearRoster('Could not load the roster', 'Try refreshing.'); return; }

    students = d.students;
    rosterLabel.textContent = d.programme;
    drawRoster();
  }

  function drawRoster() {
    if (!students.length) {
      clearRoster('No students in this class', 'Add students from the administration screens.');
      return;
    }
    roster.innerHTML = students.map((s) => `
      <label class="rs-item ${s.busy ? 'busy' : ''}" data-id="${s.id}" title="${esc(s.name)}">
        <input type="checkbox" value="${s.id}" ${s.busy ? 'disabled' : ''}>
        <span style="min-width:0">
          <span class="rs-reg">${esc(s.register)}</span>
          <span class="rs-name">${s.busy ? '· ' + esc(s.busy) : esc(s.name)}</span>
        </span>
      </label>`).join('');

    roster.querySelectorAll('input[type=checkbox]').forEach((cb) => {
      cb.addEventListener('change', () => {
        const item = cb.closest('.rs-item');
        const id = parseInt(item.dataset.id, 10);
        if (cb.checked) picked.add(id); else picked.delete(id);
        item.classList.toggle('picked', cb.checked);
        updateCount();
      });
    });
    updateCount();
  }

  function clearRoster(title, sub) {
    students = []; picked.clear();
    rosterLabel.textContent = '';
    roster.innerHTML = `<div class="empty" style="grid-column:1/-1">
      <i class="fa-solid fa-list-check"></i><strong>${esc(title)}</strong>${esc(sub)}</div>`;
    updateCount();
  }

  function updateCount() {
    rosterCount.textContent = `#${picked.size}/${students.length}`;
    btnOpen.disabled = picked.size === 0;
  }

  $('#btnNames').addEventListener('click', function () {
    namesOn = !namesOn;
    roster.classList.toggle('hide-names', !namesOn);
    this.innerHTML = namesOn
      ? '<i class="fa-solid fa-eye-slash me-1"></i>Hide names'
      : '<i class="fa-solid fa-eye me-1"></i>View names';
  });

  $('#btnClear').addEventListener('click', () => {
    picked.clear();
    roster.querySelectorAll('input:checked').forEach((cb) => {
      cb.checked = false;
      cb.closest('.rs-item').classList.remove('picked');
    });
    updateCount();
  });

  // ---- step 2 ----------------------------------------------------------
  const modal = new bootstrap.Modal($('#approveModal'));

  btnOpen.addEventListener('click', () => {
    const chosen = students.filter((s) => picked.has(s.id));
    $('#selCount').textContent = chosen.length + (chosen.length === 1 ? ' student' : ' students');
    $('#selClass').textContent = progSel.options[progSel.selectedIndex].textContent;
    $('#selList').innerHTML = chosen.map((s) => `
      <span class="d-flex align-items-center gap-2 px-2 py-1"
            style="background:var(--surface-2);border:1px solid var(--line);border-radius:8px">
        ${s.photo
          ? `<img class="ava ava-sm" src="${esc(s.photo)}" alt="">`
          : `<span class="ava ava-sm">${esc(s.initials)}</span>`}
        <span style="line-height:1.1">
          <span class="mono d-block" style="font-size:.76rem;font-weight:600">${esc(s.register)}</span>
          <span style="font-size:.74rem;color:var(--muted)">${esc(s.name)}</span>
        </span>
      </span>`).join('');
    previewExpiry();
    modal.show();
  });

  $('#reasonSel').addEventListener('change', function () {
    $('#otherWrap').classList.toggle('d-none', this.value !== 'other');
  });

  ['#outTime', '#validitySel'].forEach((s) => $(s).addEventListener('change', previewExpiry));

  function previewExpiry() {
    const t = new Date($('#outTime').value || Date.now());
    if (isNaN(t)) return;
    t.setMinutes(t.getMinutes() + parseInt($('#validitySel').value, 10));
    let h = t.getHours(); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
    $('#previewExpiry').textContent =
      `${String(h).padStart(2,'0')}:${String(t.getMinutes()).padStart(2,'0')} ${ap}`;
  }

  // ---- approve ---------------------------------------------------------
  $('#btnApprove').addEventListener('click', async function () {
    const btn = this;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> Approving…';

    const hours = Array.from(document.querySelectorAll('#hourPick input:checked')).map((c) => c.value);
    const out = $('#outTime').value ? $('#outTime').value.replace('T', ' ') + ':00' : '';

    const res = await api('staff/approve', {
      course_id: courseSel.value,
      programme_id: progSel.value,
      hours: hours,
      student_ids: Array.from(picked),
      reason_code: $('#reasonSel').value,
      reason_other: $('#otherText').value,
      destination: $('#destInput').value,
      out_time: out,
      validity_mins: $('#validitySel').value,
    });

    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-stamp me-1"></i> Approve outpass';

    if (!res.ok) {
      Swal.fire({ icon: 'error', title: 'Not approved', text: res.message,
                  confirmButtonColor: '#b3123f' });
      return;
    }

    modal.hide();
    const rows = res.passes.map((p) => `
      <tr>
        <td class="mono" style="text-align:left">${esc(p.register)}</td>
        <td style="text-align:left">${esc(p.student)}</td>
        <td class="mono">${esc(p.expiry)}</td>
        <td><a href="${p.view}" target="_blank">Open pass</a></td>
      </tr>`).join('');

    Swal.fire({
      icon: 'success',
      title: res.count === 1 ? 'Outpass approved' : res.count + ' outpasses approved',
      html: `<p style="font-size:.9rem">${esc(res.message)}</p>
             <table class="table table-sm" style="font-size:.82rem">
               <thead><tr><th style="text-align:left">Register</th><th style="text-align:left">Name</th>
               <th>Return by</th><th></th></tr></thead><tbody>${rows}</tbody></table>
             ${res.skipped && res.skipped.length
               ? `<p style="font-size:.78rem;color:#b26a00">Skipped (already holding a pass): ${esc(res.skipped.join(', '))}</p>`
               : ''}`,
      width: 620,
      confirmButtonText: 'Done',
      confirmButtonColor: '#b3123f'
    }).then(() => loadRoster());
  });
})();
</script>
