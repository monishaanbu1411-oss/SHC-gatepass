<?php /** Every pass, filterable and exportable. Emergency cancel lives here too. */ ?>
<div class="card-x">
  <div class="cx-head flex-wrap gap-2">
    <h2><i class="fa-solid fa-id-card me-2"></i>All movement passes</h2>
    <span class="ms-auto" style="font-size:.8rem;color:var(--muted)"><?= count($passes) ?> rows</span>
  </div>

  <div class="cx-body">
    <form class="row g-2 align-items-end mb-3" method="get" action="<?= url('admin/passes') ?>">
      <div class="col-6 col-md-2">
        <label class="form-label" for="fl_dept">Department</label>
        <select class="form-select form-select-sm" id="fl_dept" name="dept">
          <option value="">All</option>
          <?php foreach ($departments as $d): ?>
            <option value="<?= (int)$d['id'] ?>"<?= $filters['dept_id'] === (int)$d['id'] ? ' selected' : '' ?>>
              <?= e($d['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-6 col-md-2">
        <label class="form-label" for="fl_status">Status</label>
        <select class="form-select form-select-sm" id="fl_status" name="status">
          <option value="">All</option>
          <?php foreach (STATUS_LABELS as $k => $v): ?>
            <option value="<?= e($k) ?>"<?= $filters['status'] === $k ? ' selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-6 col-md-2">
        <label class="form-label" for="fl_reason">Reason</label>
        <select class="form-select form-select-sm" id="fl_reason" name="reason">
          <option value="">All</option>
          <?php foreach (REASONS as $k => $v): ?>
            <option value="<?= e($k) ?>"<?= $filters['reason_code'] === $k ? ' selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-6 col-md-2">
        <label class="form-label" for="fl_from">From</label>
        <input class="form-control form-control-sm" id="fl_from" type="date" name="from" value="<?= e($filters['from']) ?>">
      </div>
      <div class="col-6 col-md-2">
        <label class="form-label" for="fl_to">To</label>
        <input class="form-control form-control-sm" id="fl_to" type="date" name="to" value="<?= e($filters['to']) ?>">
      </div>
      <div class="col-6 col-md-2 d-flex gap-2">
        <button class="btn btn-sm btn-navy flex-grow-1">Apply</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('admin/export?' . http_build_query(array_filter([
             'dept' => $filters['dept_id'], 'status' => $filters['status'],
             'reason' => $filters['reason_code'], 'from' => $filters['from'], 'to' => $filters['to'],
           ]))) ?>" title="Export to CSV"><i class="fa-solid fa-file-csv"></i></a>
      </div>
    </form>

    <div class="table-responsive">
      <table class="table-x" data-dt data-dt-nosort="[7]">
        <thead>
          <tr><th>Pass ID</th><th>Student</th><th>Dept</th><th>Approved by</th>
              <th>Reason</th><th>Out / Return</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($passes as $p): ?>
          <tr>
            <td class="mono" style="font-size:.75rem"><?= e($p['pass_uid']) ?></td>
            <td>
              <span style="font-weight:600"><?= e($p['student_name']) ?></span>
              <span class="mono d-block" style="font-size:.73rem;color:var(--muted)"><?= e($p['register_no']) ?></span>
            </td>
            <td class="mono" style="font-size:.77rem"><?= e($p['dept_code']) ?></td>
            <td style="font-size:.8rem"><?= e($p['staff_name']) ?></td>
            <td style="font-size:.8rem"><?= e(reason_label($p['reason_code'], $p['reason_other'])) ?></td>
            <td class="mono" style="font-size:.76rem">
              <?= e(fmt_time($p['exit_time'] ?: $p['out_time'])) ?> &rarr; <?= e(fmt_time($p['return_time'])) ?>
            </td>
            <td><span class="st <?= status_class($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
            <td class="text-end" style="white-space:nowrap">
              <a class="btn btn-sm btn-outline-secondary" href="<?= url('pass/view/' . $p['pass_uid']) ?>">Open</a>
              <?php if (in_array($p['status'], ['approved', 'left_campus'], true)): ?>
                <button class="btn btn-sm btn-outline-danger" data-revoke="<?= e($p['pass_uid']) ?>"
                        data-name="<?= e($p['student_name']) ?>">Cancel</button>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
(function () {
  const { api, esc } = window.SHCApp;
  document.querySelectorAll('[data-revoke]').forEach((btn) => {
    btn.addEventListener('click', async function () {
      const { value: reason } = await Swal.fire({
        title: 'Cancel this pass?',
        html: `<p style="font-size:.9rem">${esc(this.dataset.name)}'s pass stops working at the gate
               immediately. The student, the faculty member and security are told.</p>`,
        input: 'text', inputPlaceholder: 'Reason for cancelling',
        inputValidator: (v) => (!v ? 'A reason is required' : undefined),
        showCancelButton: true, confirmButtonText: 'Cancel the pass',
        confirmButtonColor: '#c0281f', cancelButtonText: 'Keep it'
      });
      if (!reason) return;
      const res = await api('admin/revoke', { uid: this.dataset.revoke, reason: reason });
      Swal.fire({
        icon: res.ok ? 'success' : 'error',
        title: res.ok ? 'Pass cancelled' : 'Not cancelled',
        text: res.message, confirmButtonColor: '#b3123f'
      }).then(() => { if (res.ok) location.reload(); });
    });
  });
})();
</script>
