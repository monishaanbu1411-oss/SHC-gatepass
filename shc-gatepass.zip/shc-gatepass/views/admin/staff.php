<?php /** Staff accounts, HOD role assignment and course load. */ ?>
<div class="card-x">
  <div class="cx-head flex-wrap gap-2">
    <h2><i class="fa-solid fa-chalkboard-user me-2"></i>Staff &amp; Heads of Department</h2>
    <form class="ms-auto d-flex gap-2" method="get" action="<?= url('admin/staff') ?>">
      <select class="form-select form-select-sm" name="dept" style="width:190px" onchange="this.form.submit()">
        <option value="">All departments</option>
        <?php foreach ($departments as $d): ?>
          <option value="<?= (int)$d['id'] ?>"<?= $dept === (int)$d['id'] ? ' selected' : '' ?>><?= e($d['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <button class="btn btn-sm btn-shc" id="btnAddStaff"><i class="fa-solid fa-plus me-1"></i>Add staff</button>
  </div>

  <div class="cx-body">
    <div class="table-responsive">
      <table class="table-x" data-dt data-dt-nosort="[5]">
        <thead>
          <tr><th>Staff ID</th><th>Name</th><th>Department</th><th>Role</th><th>Courses</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($staff as $s): ?>
          <tr>
            <td class="mono" style="font-weight:600"><?= e($s['staff_code']) ?></td>
            <td>
              <?= e($s['name']) ?>
              <span class="d-block" style="font-size:.74rem;color:var(--muted)"><?= e($s['designation']) ?></span>
            </td>
            <td style="font-size:.83rem"><?= e($s['dept_name']) ?></td>
            <td>
              <span class="st <?= $s['role'] === 'hod' ? 'st-approved' : 'st-revoked' ?>">
                <?= $s['role'] === 'hod' ? 'HOD' : 'Faculty' ?>
              </span>
              <?php if (!(int)$s['is_active']): ?><span class="st st-expired ms-1">Inactive</span><?php endif; ?>
            </td>
            <td>
              <button class="btn btn-sm btn-outline-secondary" data-load="<?= (int)$s['id'] ?>"
                      data-name="<?= e($s['name']) ?>">
                <?= (int)$s['course_count'] ?> assigned
              </button>
            </td>
            <td class="text-end">
              <button class="btn btn-sm btn-outline-secondary" data-edit='<?= e(json_encode([
                'id' => (int)$s['id'], 'staff_code' => $s['staff_code'], 'name' => $s['name'],
                'dept_id' => (int)$s['dept_id'], 'role' => $s['role'], 'designation' => $s['designation'],
                'email' => $s['email'], 'phone' => $s['phone'], 'is_active' => (int)$s['is_active'],
              ])) ?>'>Edit</button>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- add / edit staff -->
<div class="modal fade" id="staffModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:var(--r)">
      <div class="modal-header" style="background:var(--navy);color:#fff;border-radius:var(--r) var(--r) 0 0">
        <h5 class="modal-title" id="staffTitle" style="font-family:var(--display);color:#fff">Add staff</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="s_id">
        <div class="row g-3">
          <div class="col-12 col-md-5">
            <label class="form-label" for="s_staff_code">Staff ID</label>
            <input class="form-control mono" id="s_staff_code" placeholder="T261002">
          </div>
          <div class="col-12 col-md-7">
            <label class="form-label" for="s_name">Full name</label>
            <input class="form-control" id="s_name">
          </div>
          <div class="col-12 col-md-6">
            <label class="form-label" for="s_dept_id">Department</label>
            <select class="form-select" id="s_dept_id">
              <?php foreach ($departments as $d): ?>
                <option value="<?= (int)$d['id'] ?>"><?= e($d['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12 col-md-6">
            <label class="form-label" for="s_role">Role</label>
            <select class="form-select" id="s_role">
              <option value="staff">Faculty</option>
              <option value="hod">Head of Department</option>
            </select>
            <div class="form-text" style="font-size:.73rem">HODs see the whole department's movement.</div>
          </div>
          <div class="col-12">
            <label class="form-label" for="s_designation">Designation</label>
            <input class="form-control" id="s_designation" placeholder="Assistant Professor">
          </div>
          <div class="col-12 col-md-7">
            <label class="form-label" for="s_email">Email</label>
            <input class="form-control" id="s_email" type="email">
          </div>
          <div class="col-12 col-md-5">
            <label class="form-label" for="s_phone">Phone</label>
            <input class="form-control mono" id="s_phone">
          </div>
          <div class="col-12">
            <label class="form-label" for="s_password">Password</label>
            <input class="form-control" id="s_password" type="text" placeholder="Leave blank to keep the current one">
          </div>
          <div class="col-12">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="s_is_active" checked>
              <label class="form-check-label" for="s_is_active">Account is active</label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-shc" id="btnSaveStaff">Save staff</button>
      </div>
    </div>
  </div>
</div>

<!-- course load -->
<div class="modal fade" id="loadModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content" style="border-radius:var(--r)">
      <div class="modal-header" style="background:var(--navy);color:#fff;border-radius:var(--r) var(--r) 0 0">
        <h5 class="modal-title" id="loadTitle" style="font-family:var(--display);color:#fff">Course load</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p style="font-size:.85rem;color:var(--muted)">
          A faculty member can only issue passes to classes listed here.
        </p>
        <div id="loadRows" class="mb-3"></div>
        <div class="row g-2 align-items-end">
          <div class="col-12 col-md-5">
            <label class="form-label" for="a_course">Course</label>
            <select class="form-select form-select-sm" id="a_course">
              <?php foreach ($courses as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= e($c['code']) ?> - <?= e($c['title']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12 col-md-5">
            <label class="form-label" for="a_prog">Class section</label>
            <select class="form-select form-select-sm" id="a_prog">
              <?php foreach ($programmes as $p): ?>
                <option value="<?= (int)$p['id'] ?>"><?= e(LookupModel::progLabel($p)) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12 col-md-2">
            <button class="btn btn-sm btn-shc w-100" id="btnAssign">Assign</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  const { api, apiGet, esc } = window.SHCApp;
  const $ = (s) => document.querySelector(s);
  const modal = new bootstrap.Modal($('#staffModal'));
  const loadModal = new bootstrap.Modal($('#loadModal'));
  let currentStaff = 0;

  const F = ['id','staff_code','name','dept_id','role','designation','email','phone'];

  $('#btnAddStaff').addEventListener('click', () => {
    F.forEach((f) => $('#s_' + f).value = '');
    $('#s_is_active').checked = true;
    $('#s_staff_code').disabled = false;
    $('#staffTitle').textContent = 'Add staff';
    modal.show();
  });

  document.querySelectorAll('[data-edit]').forEach((b) => {
    b.addEventListener('click', function () {
      const d = JSON.parse(this.dataset.edit);
      F.forEach((f) => $('#s_' + f).value = d[f] ?? '');
      $('#s_is_active').checked = !!d.is_active;
      $('#s_password').value = '';
      $('#s_staff_code').disabled = true;
      $('#staffTitle').textContent = 'Edit ' + d.name;
      modal.show();
    });
  });

  $('#btnSaveStaff').addEventListener('click', async function () {
    const p = {};
    F.forEach((f) => p[f] = $('#s_' + f).value);
    p.staff_code = $('#s_staff_code').value;
    p.password = $('#s_password').value;
    p.is_active = $('#s_is_active').checked ? 1 : 0;

    this.disabled = true;
    const res = await api('admin/save-staff', p);
    this.disabled = false;

    if (!res.ok) {
      Swal.fire({ icon: 'error', title: 'Not saved', text: res.message, confirmButtonColor: '#b3123f' });
      return;
    }
    modal.hide();
    Swal.fire({ icon: 'success', title: 'Saved', text: res.message, confirmButtonColor: '#b3123f' })
        .then(() => location.reload());
  });

  // ---- course load ----
  async function drawLoad() {
    const d = await apiGet('admin/staff-courses/' + currentStaff);
    const box = $('#loadRows');
    if (!d.rows.length) {
      box.innerHTML = `<div class="empty py-3"><i class="fa-solid fa-book"></i>
        <strong>No courses assigned</strong>This faculty member cannot issue any passes yet.</div>`;
      return;
    }
    box.innerHTML = d.rows.map((r) => `
      <div class="d-flex align-items-center gap-2 py-2" style="border-bottom:1px solid var(--line);font-size:.85rem">
        <span class="mono" style="font-weight:600">${esc(r.code)}</span>
        <span class="flex-grow-1" style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
          ${esc(r.title)}</span>
        <span class="st st-approved">${esc(r.prog_name)} Sh ${esc(r.shift)}</span>
        <button class="btn btn-sm btn-outline-danger" data-unassign="${r.id}">Remove</button>
      </div>`).join('');

    box.querySelectorAll('[data-unassign]').forEach((b) => {
      b.addEventListener('click', async function () {
        await api('admin/unassign-course', { row_id: this.dataset.unassign, staff_id: currentStaff });
        drawLoad();
      });
    });
  }

  document.querySelectorAll('[data-load]').forEach((b) => {
    b.addEventListener('click', function () {
      currentStaff = this.dataset.load;
      $('#loadTitle').textContent = 'Course load — ' + this.dataset.name;
      $('#loadRows').innerHTML = '<div class="text-center py-4"><i class="fa-solid fa-spinner fa-spin"></i></div>';
      loadModal.show();
      drawLoad();
    });
  });

  $('#btnAssign').addEventListener('click', async function () {
    const res = await api('admin/assign-course', {
      staff_id: currentStaff, course_id: $('#a_course').value, programme_id: $('#a_prog').value
    });
    if (!res.ok) {
      Swal.fire({ icon: 'error', title: 'Not assigned', text: res.message, confirmButtonColor: '#b3123f' });
      return;
    }
    drawLoad();
  });
})();
</script>
