<?php /** Student account management: add, edit, deactivate, bulk import. */ ?>
<div class="card-x">
  <div class="cx-head flex-wrap gap-2">
    <h2><i class="fa-solid fa-user-graduate me-2"></i>Student accounts</h2>
    <form class="ms-auto d-flex gap-2 flex-wrap" method="get" action="<?= url('admin/students') ?>">
      <input class="form-control form-control-sm" name="q" value="<?= e($q) ?>"
             placeholder="Name or register number" style="width:210px">
      <select class="form-select form-select-sm" name="dept" style="width:170px">
        <option value="">All departments</option>
        <?php foreach ($departments as $d): ?>
          <option value="<?= (int)$d['id'] ?>"<?= $dept === (int)$d['id'] ? ' selected' : '' ?>>
            <?= e($d['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-sm btn-navy">Search</button>
    </form>
    <button class="btn btn-sm btn-outline-secondary" id="btnImport">
      <i class="fa-solid fa-file-csv me-1"></i>Bulk import
    </button>
    <button class="btn btn-sm btn-shc" id="btnAdd">
      <i class="fa-solid fa-plus me-1"></i>Add student
    </button>
  </div>

  <div class="cx-body">
    <div class="table-responsive">
      <table class="table-x" data-dt data-dt-nosort="[5]">
        <thead>
          <tr><th>Register No</th><th>Name</th><th>Class</th><th>Contact</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($students as $s): ?>
          <tr>
            <td class="mono" style="font-weight:600"><?= e($s['register_no']) ?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <span class="ava ava-sm"><?= e(initials($s['name'])) ?></span>
                <span>
                  <?= e($s['name']) ?>
                  <span class="d-block" style="font-size:.73rem;color:var(--muted)">
                    DOB <?= e(fmt_date($s['dob'])) ?> &middot; <?= e($s['residence']) ?>
                  </span>
                </span>
              </div>
            </td>
            <td style="font-size:.82rem"><?= e($s['dept_code']) ?> &middot; <?= e($s['prog_name']) ?> Sh <?= e($s['shift']) ?></td>
            <td class="mono" style="font-size:.77rem"><?= e($s['phone']) ?></td>
            <td>
              <span class="st <?= (int)$s['is_active'] ? 'st-returned' : 'st-revoked' ?>">
                <?= (int)$s['is_active'] ? 'Active' : 'Inactive' ?>
              </span>
            </td>
            <td class="text-end">
              <button class="btn btn-sm btn-outline-secondary" data-edit='<?= e(json_encode([
                'id' => (int)$s['id'], 'register_no' => $s['register_no'], 'name' => $s['name'],
                'dob' => $s['dob'], 'dept_id' => (int)$s['dept_id'], 'programme_id' => (int)$s['programme_id'],
                'roll_index' => (int)$s['roll_index'], 'gender' => $s['gender'], 'phone' => $s['phone'],
                'parent_phone' => $s['parent_phone'], 'email' => $s['email'],
                'blood_group' => $s['blood_group'], 'residence' => $s['residence'],
                'is_active' => (int)$s['is_active'],
              ])) ?>'>Edit</button>
              <button class="btn btn-sm btn-outline-danger" data-del="<?= (int)$s['id'] ?>"
                      data-name="<?= e($s['name']) ?>">Deactivate</button>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- add / edit -->
<div class="modal fade" id="stuModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content" style="border-radius:var(--r)">
      <div class="modal-header" style="background:var(--navy);color:#fff;border-radius:var(--r) var(--r) 0 0">
        <h5 class="modal-title" id="stuTitle" style="font-family:var(--display);color:#fff">Add student</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="f_id">
        <div class="row g-3">
          <div class="col-12 col-md-4">
            <label class="form-label" for="f_register_no">Register number</label>
            <input class="form-control mono" id="f_register_no" placeholder="BU2610A01">
          </div>
          <div class="col-12 col-md-8">
            <label class="form-label" for="f_name">Full name</label>
            <input class="form-control" id="f_name">
          </div>
          <div class="col-12 col-md-4">
            <label class="form-label" for="f_dob">Date of birth</label>
            <input class="form-control" id="f_dob" type="date">
            <div class="form-text" style="font-size:.73rem">This is the student's sign-in password.</div>
          </div>
          <div class="col-12 col-md-4">
            <label class="form-label" for="f_dept_id">Department</label>
            <select class="form-select" id="f_dept_id">
              <?php foreach ($departments as $d): ?>
                <option value="<?= (int)$d['id'] ?>"><?= e($d['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12 col-md-4">
            <label class="form-label" for="f_programme_id">Class section</label>
            <select class="form-select" id="f_programme_id">
              <?php foreach ($programmes as $p): ?>
                <option value="<?= (int)$p['id'] ?>" data-dept="<?= (int)$p['dept_id'] ?>">
                  <?= e(LookupModel::progLabel($p)) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-6 col-md-3">
            <label class="form-label" for="f_roll_index">Roll no</label>
            <input class="form-control" id="f_roll_index" type="number" min="1">
          </div>
          <div class="col-6 col-md-3">
            <label class="form-label" for="f_gender">Gender</label>
            <select class="form-select" id="f_gender">
              <option value="">—</option><option value="M">Male</option>
              <option value="F">Female</option><option value="O">Other</option>
            </select>
          </div>
          <div class="col-6 col-md-3">
            <label class="form-label" for="f_blood_group">Blood group</label>
            <input class="form-control" id="f_blood_group" maxlength="6" placeholder="O+">
          </div>
          <div class="col-6 col-md-3">
            <label class="form-label" for="f_residence">Residence</label>
            <select class="form-select" id="f_residence">
              <option value="Day Scholar">Day Scholar</option>
              <option value="Hosteller">Hosteller</option>
            </select>
          </div>
          <div class="col-12 col-md-4">
            <label class="form-label" for="f_phone">Phone</label>
            <input class="form-control mono" id="f_phone">
          </div>
          <div class="col-12 col-md-4">
            <label class="form-label" for="f_parent_phone">Parent phone</label>
            <input class="form-control mono" id="f_parent_phone">
          </div>
          <div class="col-12 col-md-4">
            <label class="form-label" for="f_email">Email</label>
            <input class="form-control" id="f_email" type="email">
          </div>
          <div class="col-12">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="f_is_active" checked>
              <label class="form-check-label" for="f_is_active">Account is active</label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-shc" id="btnSaveStu">Save student</button>
      </div>
    </div>
  </div>
</div>

<!-- import -->
<div class="modal fade" id="impModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:var(--r)">
      <div class="modal-header" style="background:var(--navy);color:#fff;border-radius:var(--r) var(--r) 0 0">
        <h5 class="modal-title" style="font-family:var(--display);color:#fff">Bulk import students</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p style="font-size:.86rem">
          Upload a CSV with one student per row, in this column order:
        </p>
        <pre class="mono" style="background:var(--surface-2);padding:.7rem;border-radius:var(--r-sm);font-size:.76rem;border:1px solid var(--line)">register_no, name, dob (YYYY-MM-DD), class_id, phone, parent_phone, blood_group</pre>
        <label class="form-label">Class section IDs</label>
        <div style="max-height:150px;overflow:auto;font-size:.8rem;border:1px solid var(--line);border-radius:var(--r-sm);padding:.5rem">
          <?php foreach ($programmes as $p): ?>
            <div><span class="mono" style="font-weight:700"><?= (int)$p['id'] ?></span> — <?= e(LookupModel::progLabel($p)) ?></div>
          <?php endforeach; ?>
        </div>
        <label class="form-label mt-3" for="impFile">CSV file (max 5 MB)</label>
        <input class="form-control" type="file" id="impFile" accept=".csv,text/csv">
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-shc" id="btnDoImport">Import students</button>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  const { api, esc } = window.SHCApp;
  const $ = (s) => document.querySelector(s);
  const modal = new bootstrap.Modal($('#stuModal'));
  const impModal = new bootstrap.Modal($('#impModal'));

  const FIELDS = ['id','register_no','name','dob','dept_id','programme_id','roll_index',
                  'gender','phone','parent_phone','email','blood_group','residence'];

  function fill(data) {
    FIELDS.forEach((f) => { const el = $('#f_' + f); if (el) el.value = data[f] ?? ''; });
    $('#f_is_active').checked = data.is_active === undefined ? true : !!data.is_active;
  }

  $('#btnAdd').addEventListener('click', () => {
    fill({}); $('#f_register_no').disabled = false;
    $('#stuTitle').textContent = 'Add student';
    modal.show();
  });

  document.querySelectorAll('[data-edit]').forEach((b) => {
    b.addEventListener('click', function () {
      const d = JSON.parse(this.dataset.edit);
      fill(d);
      $('#f_register_no').disabled = true;   // the register number is the identity
      $('#stuTitle').textContent = 'Edit ' + d.name;
      modal.show();
    });
  });

  $('#btnSaveStu').addEventListener('click', async function () {
    const payload = {};
    FIELDS.forEach((f) => { const el = $('#f_' + f); if (el) payload[f] = el.value; });
    payload.register_no = $('#f_register_no').value;   // include even when disabled
    payload.is_active = $('#f_is_active').checked ? 1 : 0;

    this.disabled = true;
    const res = await api('admin/save-student', payload);
    this.disabled = false;

    if (!res.ok) {
      Swal.fire({ icon: 'error', title: 'Not saved', text: res.message, confirmButtonColor: '#b3123f' });
      return;
    }
    modal.hide();
    Swal.fire({ icon: 'success', title: 'Saved', text: res.message, confirmButtonColor: '#b3123f' })
        .then(() => location.reload());
  });

  document.querySelectorAll('[data-del]').forEach((b) => {
    b.addEventListener('click', async function () {
      const id = this.dataset.del, name = this.dataset.name;
      const c = await Swal.fire({
        icon: 'warning', title: 'Deactivate this account?',
        html: `<p style="font-size:.9rem">${esc(name)} will no longer be able to sign in.
               Their pass history is kept for auditing.</p>`,
        showCancelButton: true, confirmButtonText: 'Deactivate',
        confirmButtonColor: '#c0281f', cancelButtonText: 'Keep active'
      });
      if (!c.isConfirmed) return;
      const res = await api('admin/delete-student', { id: id });
      Swal.fire({ icon: 'success', title: 'Deactivated', text: res.message, confirmButtonColor: '#b3123f' })
          .then(() => location.reload());
    });
  });

  // ---- import ----
  $('#btnImport').addEventListener('click', () => impModal.show());

  $('#btnDoImport').addEventListener('click', async function () {
    const file = $('#impFile').files[0];
    if (!file) {
      Swal.fire({ icon: 'warning', title: 'Choose a file first', confirmButtonColor: '#b3123f' });
      return;
    }
    const body = new FormData();
    body.append('csrf_token', window.SHC.csrf);
    body.append('file', file);

    this.disabled = true;
    this.innerHTML = 'Importing…';
    const r = await fetch(window.SHC.base + '/admin/import-students', {
      method: 'POST', body: body, headers: { 'X-Requested-With': 'XMLHttpRequest' }
    });
    const res = await r.json();
    this.disabled = false;
    this.innerHTML = 'Import students';

    impModal.hide();
    Swal.fire({
      icon: res.ok ? 'success' : 'error',
      title: res.ok ? 'Import finished' : 'Import failed',
      html: `<p>${esc(res.message || '')}</p>` +
            (res.failed && res.failed.length
              ? `<div style="text-align:left;font-size:.78rem;max-height:180px;overflow:auto">
                   ${res.failed.map((f) => esc(f)).join('<br>')}</div>` : ''),
      confirmButtonColor: '#b3123f'
    }).then(() => { if (res.ok) location.reload(); });
  });
})();
</script>
