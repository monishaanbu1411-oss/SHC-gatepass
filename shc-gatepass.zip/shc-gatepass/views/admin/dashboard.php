<?php
/**
 * Administration overview.
 *
 * The department cards are the working part of this screen: each one is a
 * live count of students outside from that department, and clicking it opens
 * the actual list of who they are.
 */
?>
<div class="row g-3 mb-3">
  <?php
  $tiles = [
    ['Students outside now', $stats['outside'],      'person-walking-arrow-right', 'bg-crimson', 'outside'],
    ['Overdue returns',      $stats['overdue'],      'triangle-exclamation',       'bg-danger',  'overdue'],
    ['Passes issued today',  $stats['issued_today'], 'file-circle-plus',           'bg-navy',    'issued_today'],
    ['Returned today',       $stats['returned_today'],'right-to-bracket',          'bg-ok',      'returned_today'],
    ['Enrolled students',    $totals['students'],    'user-graduate',              'bg-violet',  null],
    ['Faculty & HODs',       $totals['staff'],       'chalkboard-user',            'bg-olive',   null],
  ];
  foreach ($tiles as [$label, $num, $icon, $bg, $key]): ?>
    <div class="col-6 col-lg-4 col-xxl-2">
      <div class="stat">
        <span class="stat-icon <?= $bg ?>"><i class="fa-solid fa-<?= $icon ?>"></i></span>
        <span style="min-width:0">
          <span class="stat-num"<?= $key ? ' data-counter="' . e($key) . '"' : '' ?>><?= (int)$num ?></span>
          <span class="stat-label d-block"><?= e($label) ?></span>
        </span>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- ==================== department drill-down ==================== -->
<div class="card-x mb-3">
  <div class="cx-head">
    <h2><i class="fa-solid fa-building-columns me-2"></i>Outside campus, by department</h2>
    <span class="ms-auto" style="font-size:.78rem;color:var(--muted)">
      Click a department to see exactly who is out
    </span>
  </div>
  <div class="cx-body">
    <div class="row g-2" id="deptCards">
      <?php foreach ($byDept as $d): ?>
        <div class="col-6 col-md-4 col-xl-3 col-xxl-2">
          <div class="stat dept-card clickable" data-dept="<?= (int)$d['id'] ?>"
               data-name="<?= e($d['name']) ?>" role="button" tabindex="0">
            <span>
              <span class="dc-out" data-dept-count="<?= (int)$d['id'] ?>"
                    style="color:<?= (int)$d['outside'] ? 'var(--crimson)' : 'var(--muted)' ?>">
                <?= (int)$d['outside'] ?>
              </span>
              <span class="stat-label d-block"><?= e($d['name']) ?></span>
              <span class="dc-code"><?= e($d['code']) ?> &middot; <?= (int)$d['today'] ?> today</span>
              <?php if ((int)$d['overdue']): ?>
                <span class="st st-expired mt-1"><?= (int)$d['overdue'] ?> overdue</span>
              <?php endif; ?>
            </span>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-12 col-xl-7">
    <div class="card-x h-100">
      <div class="cx-head"><h2><i class="fa-solid fa-chart-column me-2"></i>Passes issued, last 14 days</h2></div>
      <div class="cx-body"><canvas id="chartDays" height="120"></canvas></div>
    </div>
  </div>
  <div class="col-12 col-xl-5">
    <div class="card-x h-100">
      <div class="cx-head"><h2><i class="fa-solid fa-chart-pie me-2"></i>Reasons, last 30 days</h2></div>
      <div class="cx-body"><canvas id="chartReason" height="150"></canvas></div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-12 col-xl-8">
    <div class="card-x h-100">
      <div class="cx-head">
        <h2><i class="fa-solid fa-street-view me-2"></i>Everyone currently outside</h2>
        <span class="ms-auto st st-out"><?= count($outside) ?></span>
      </div>
      <div class="cx-body p-0" style="max-height:460px;overflow:auto">
        <?php require ROOT_PATH . '/views/layouts/_outside_table.php'; ?>
      </div>
    </div>
  </div>

  <div class="col-12 col-xl-4">
    <div class="card-x h-100">
      <div class="cx-head"><h2><i class="fa-solid fa-ranking-star me-2"></i>Most approvals, 30 days</h2></div>
      <div class="cx-body p-0">
        <?php if (!$approvers): ?>
          <div class="empty"><i class="fa-regular fa-chart-bar"></i><strong>No data yet</strong>Approvals appear here.</div>
        <?php else: ?>
          <table class="table-x">
            <thead><tr><th>Faculty</th><th>Dept</th><th class="text-end">Passes</th></tr></thead>
            <tbody>
            <?php foreach ($approvers as $a): ?>
              <tr>
                <td>
                  <span style="font-weight:600"><?= e($a['name']) ?></span>
                  <span class="mono d-block" style="font-size:.73rem;color:var(--muted)"><?= e($a['staff_code']) ?></span>
                </td>
                <td class="mono" style="font-size:.78rem"><?= e($a['dept_code']) ?></td>
                <td class="text-end mono" style="font-weight:700"><?= (int)$a['total'] ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- drill-down modal -->
<div class="modal fade" id="deptModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content" style="border-radius:var(--r);border-color:var(--line)">
      <div class="modal-header" style="background:var(--navy);color:#fff;border-radius:var(--r) var(--r) 0 0">
        <h5 class="modal-title" id="deptModalTitle" style="font-family:var(--display);color:#fff">Department</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="deptModalBody"></div>
    </div>
  </div>
</div>

<script>
(function () {
  const { apiGet, api, esc } = window.SHCApp;

  // ---------------- charts ----------------
  const gridColour = getComputedStyle(document.documentElement).getPropertyValue('--line').trim();
  const inkColour = getComputedStyle(document.documentElement).getPropertyValue('--muted').trim();

  new Chart(document.getElementById('chartDays'), {
    type: 'bar',
    data: {
      labels: <?= json_encode(array_map(fn($r) => date('d M', strtotime($r['day'])), $perDay)) ?>,
      datasets: [{
        label: 'Passes issued',
        data: <?= json_encode(array_map(fn($r) => (int)$r['total'], $perDay)) ?>,
        backgroundColor: '#16255c',
        borderRadius: 5,
        maxBarThickness: 34
      }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: inkColour, font: { size: 11 } } },
        y: { beginAtZero: true, grid: { color: gridColour },
             ticks: { color: inkColour, precision: 0, font: { size: 11 } } }
      }
    }
  });

  new Chart(document.getElementById('chartReason'), {
    type: 'doughnut',
    data: {
      labels: <?= json_encode(array_map(fn($r) => reason_label($r['reason_code']), $byReason)) ?>,
      datasets: [{
        data: <?= json_encode(array_map(fn($r) => (int)$r['total'], $byReason)) ?>,
        backgroundColor: ['#b3123f', '#16255c', '#4b2a86', '#4d5a1f', '#0d6f9c',
                          '#b26a00', '#1a7f4b', '#8d0e31', '#5a6683'],
        borderWidth: 0
      }]
    },
    options: {
      cutout: '58%',
      plugins: { legend: { position: 'right', labels: { color: inkColour, boxWidth: 12, font: { size: 11 } } } }
    }
  });

  // ---------------- department drill-down ----------------
  const modal = new bootstrap.Modal(document.getElementById('deptModal'));

  async function openDept(id, name) {
    document.getElementById('deptModalTitle').textContent = name;
    document.getElementById('deptModalBody').innerHTML =
      '<div class="text-center py-5"><i class="fa-solid fa-spinner fa-spin fa-2x" style="color:var(--navy)"></i></div>';
    modal.show();

    const d = await apiGet('admin/department/' + id);
    const body = document.getElementById('deptModalBody');

    if (!d.ok || !d.students.length) {
      body.innerHTML = `<div class="empty"><i class="fa-solid fa-user-check"></i>
        <strong>Nobody is outside</strong>Every student in ${esc(name)} is on campus.</div>`;
      return;
    }

    body.innerHTML = d.students.map((s) => `
      <div class="d-flex align-items-center gap-3 py-2" style="border-bottom:1px solid var(--line)">
        ${s.photo ? `<img class="ava ava-lg" src="${esc(s.photo)}" alt="">`
                  : `<span class="ava ava-lg">${esc(s.initials)}</span>`}
        <div class="flex-grow-1" style="min-width:0">
          <div style="font-weight:600">${esc(s.name)}</div>
          <div class="mono" style="font-size:.76rem;color:var(--muted)">${esc(s.register)} · ${esc(s.programme)}</div>
          <div style="font-size:.8rem;color:var(--muted)">
            ${esc(s.reason)} · approved by ${esc(s.staff)}
          </div>
        </div>
        <div class="text-end">
          <div class="mono" style="font-size:.76rem;color:var(--muted)">out ${esc(s.out_time)}</div>
          <span class="countdown${s.overdue ? ' over' : ''}" data-countdown="${s.seconds}">—:—</span>
          <div class="mt-1 d-flex gap-1 justify-content-end">
            <a class="btn btn-sm btn-outline-secondary" href="${s.url}">Pass</a>
            <button class="btn btn-sm btn-outline-danger" data-revoke="${esc(s.uid)}"
                    data-name="${esc(s.name)}">Cancel</button>
          </div>
        </div>
      </div>`).join('');

    window.SHCApp.tickCountdowns();
    wireRevoke();
  }

  document.querySelectorAll('[data-dept]').forEach((card) => {
    const go = () => openDept(card.dataset.dept, card.dataset.name);
    card.addEventListener('click', go);
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
  });

  // ---------------- emergency override ----------------
  function wireRevoke() {
    document.querySelectorAll('[data-revoke]').forEach((btn) => {
      btn.addEventListener('click', async function () {
        const uid = this.dataset.revoke, name = this.dataset.name;
        const { value: reason } = await Swal.fire({
          title: 'Cancel this pass?',
          html: `<p style="font-size:.9rem">${esc(name)}'s pass will stop working at the gate immediately.
                 The student, the faculty member and security are told.</p>`,
          input: 'text',
          inputPlaceholder: 'Reason for cancelling',
          inputValidator: (v) => (!v ? 'A reason is required' : undefined),
          showCancelButton: true,
          confirmButtonText: 'Cancel the pass',
          confirmButtonColor: '#c0281f',
          cancelButtonText: 'Keep it'
        });
        if (!reason) return;

        const res = await api('admin/revoke', { uid: uid, reason: reason });
        Swal.fire({
          icon: res.ok ? 'success' : 'error',
          title: res.ok ? 'Pass cancelled' : 'Not cancelled',
          text: res.message, confirmButtonColor: '#b3123f'
        }).then(() => { if (res.ok) location.reload(); });
      });
    });
  }

  // ---------------- live counters ----------------
  setInterval(async () => {
    const d = await apiGet('api/counters');
    if (!d.ok) return;
    Object.entries(d.stats).forEach(([k, v]) => {
      const el = document.querySelector(`[data-counter="${k}"]`);
      if (el) el.textContent = v;
    });
    (d.byDept || []).forEach((dep) => {
      const el = document.querySelector(`[data-dept-count="${dep.id}"]`);
      if (el) {
        el.textContent = dep.outside;
        el.style.color = parseInt(dep.outside, 10) ? 'var(--crimson)' : 'var(--muted)';
      }
    });
  }, 20000);
})();
</script>
