<?php /** Gate security accounts and gate station assignment. */ ?>
<div class="card-x">
  <div class="cx-head">
    <h2><i class="fa-solid fa-user-shield me-2"></i>Gate security accounts</h2>
    <button class="btn btn-sm btn-shc ms-auto" id="btnAddW"><i class="fa-solid fa-plus me-1"></i>Add security</button>
  </div>
  <div class="cx-body">
    <div class="table-responsive">
      <table class="table-x">
        <thead><tr><th>Username</th><th>Name</th><th>Gate station</th><th>Phone</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($watchmen as $w): ?>
          <tr>
            <td class="mono" style="font-weight:600"><?= e($w['username']) ?></td>
            <td><?= e($w['name']) ?></td>
            <td><span class="st st-approved"><?= e($w['gate']) ?></span></td>
            <td class="mono" style="font-size:.78rem"><?= e($w['phone']) ?></td>
            <td>
              <span class="st <?= (int)$w['is_active'] ? 'st-returned' : 'st-revoked' ?>">
                <?= (int)$w['is_active'] ? 'Active' : 'Inactive' ?>
              </span>
            </td>
            <td class="text-end">
              <button class="btn btn-sm btn-outline-secondary" data-edit='<?= e(json_encode([
                'id' => (int)$w['id'], 'username' => $w['username'], 'name' => $w['name'],
                'gate' => $w['gate'], 'phone' => $w['phone'], 'is_active' => (int)$w['is_active'],
              ])) ?>'>Edit</button>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="modal fade" id="wModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:var(--r)">
      <div class="modal-header" style="background:var(--navy);color:#fff;border-radius:var(--r) var(--r) 0 0">
        <h5 class="modal-title" id="wTitle" style="font-family:var(--display);color:#fff">Add security</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="w_id">
        <div class="row g-3">
          <div class="col-12 col-md-6">
            <label class="form-label" for="w_username">Username</label>
            <input class="form-control mono" id="w_username" placeholder="gate01">
          </div>
          <div class="col-12 col-md-6">
            <label class="form-label" for="w_name">Full name</label>
            <input class="form-control" id="w_name">
          </div>
          <div class="col-12 col-md-6">
            <label class="form-label" for="w_gate">Gate station</label>
            <input class="form-control" id="w_gate" placeholder="Main Gate">
          </div>
          <div class="col-12 col-md-6">
            <label class="form-label" for="w_phone">Phone</label>
            <input class="form-control mono" id="w_phone">
          </div>
          <div class="col-12">
            <label class="form-label" for="w_password">Password</label>
            <input class="form-control" id="w_password" type="text" placeholder="Leave blank to keep the current one">
          </div>
          <div class="col-12">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="w_is_active" checked>
              <label class="form-check-label" for="w_is_active">Account is active</label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-shc" id="btnSaveW">Save account</button>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  const { api } = window.SHCApp;
  const $ = (s) => document.querySelector(s);
  const modal = new bootstrap.Modal($('#wModal'));
  const F = ['id','username','name','gate','phone'];

  $('#btnAddW').addEventListener('click', () => {
    F.forEach((f) => $('#w_' + f).value = '');
    $('#w_gate').value = 'Main Gate';
    $('#w_password').value = '';
    $('#w_is_active').checked = true;
    $('#w_username').disabled = false;
    $('#wTitle').textContent = 'Add security';
    modal.show();
  });

  document.querySelectorAll('[data-edit]').forEach((b) => {
    b.addEventListener('click', function () {
      const d = JSON.parse(this.dataset.edit);
      F.forEach((f) => $('#w_' + f).value = d[f] ?? '');
      $('#w_password').value = '';
      $('#w_is_active').checked = !!d.is_active;
      $('#w_username').disabled = true;
      $('#wTitle').textContent = 'Edit ' + d.name;
      modal.show();
    });
  });

  $('#btnSaveW').addEventListener('click', async function () {
    const p = {};
    F.forEach((f) => p[f] = $('#w_' + f).value);
    p.username = $('#w_username').value;
    p.password = $('#w_password').value;
    p.is_active = $('#w_is_active').checked ? 1 : 0;

    this.disabled = true;
    const res = await api('admin/save-watchman', p);
    this.disabled = false;

    if (!res.ok) {
      Swal.fire({ icon: 'error', title: 'Not saved', text: res.message, confirmButtonColor: '#b3123f' });
      return;
    }
    modal.hide();
    Swal.fire({ icon: 'success', title: 'Saved', text: res.message, confirmButtonColor: '#b3123f' })
        .then(() => location.reload());
  });
})();
</script>
