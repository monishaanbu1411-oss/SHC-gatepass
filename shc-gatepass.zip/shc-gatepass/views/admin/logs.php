<?php /** Audit trail: activity, sign-ins and gate scans. */ ?>
<div class="card-x">
  <div class="cx-head flex-wrap gap-2">
    <h2><i class="fa-solid fa-clipboard-list me-2"></i>Audit &amp; system logs</h2>
    <form class="ms-auto d-flex gap-2" method="get" action="<?= url('admin/logs') ?>">
      <input type="hidden" name="tab" value="<?= e($tab) ?>">
      <input class="form-control form-control-sm" name="q" value="<?= e($q) ?>"
             placeholder="Search activity" style="width:200px">
      <button class="btn btn-sm btn-navy">Search</button>
    </form>
  </div>

  <div class="cx-body">
    <ul class="nav nav-tabs mb-3" role="tablist">
      <?php foreach (['activity' => 'Activity', 'logins' => 'Sign-ins', 'scans' => 'Gate scans'] as $k => $label): ?>
        <li class="nav-item">
          <a class="nav-link<?= $tab === $k ? ' active' : '' ?>" href="<?= url('admin/logs?tab=' . $k) ?>">
            <?= e($label) ?>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>

    <?php if ($tab === 'logins'): ?>
      <div class="table-responsive">
        <table class="table-x" data-dt>
          <thead><tr><th>When</th><th>Type</th><th>Identifier</th><th>Result</th><th>IP address</th></tr></thead>
          <tbody>
          <?php foreach ($logins as $l): ?>
            <tr>
              <td class="mono" style="font-size:.77rem"><?= e(fmt_dt($l['created_at'])) ?></td>
              <td style="font-size:.8rem"><?= e(ucfirst($l['user_type'])) ?></td>
              <td class="mono" style="font-size:.79rem"><?= e($l['identifier']) ?></td>
              <td>
                <span class="st <?= (int)$l['success'] ? 'st-returned' : 'st-expired' ?>">
                  <?= (int)$l['success'] ? 'Success' : 'Failed' ?>
                </span>
              </td>
              <td class="mono" style="font-size:.77rem"><?= e($l['ip_address']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    <?php elseif ($tab === 'scans'): ?>
      <div class="table-responsive">
        <table class="table-x" data-dt>
          <thead><tr><th>When</th><th>Pass ID</th><th>Student</th><th>Event</th><th>By</th><th>Note</th></tr></thead>
          <tbody>
          <?php foreach ($scans as $s): ?>
            <tr>
              <td class="mono" style="font-size:.77rem"><?= e(fmt_dt($s['created_at'])) ?></td>
              <td class="mono" style="font-size:.75rem"><?= e($s['pass_uid']) ?></td>
              <td style="font-size:.82rem">
                <?= e($s['student_name']) ?>
                <span class="mono d-block" style="font-size:.72rem;color:var(--muted)"><?= e($s['register_no']) ?></span>
              </td>
              <td><span class="st <?= $s['event'] === 'exit' ? 'st-out' : ($s['event'] === 'return' ? 'st-returned' : 'st-approved') ?>">
                <?= e($s['event']) ?></span></td>
              <td style="font-size:.8rem"><?= e($s['actor_name']) ?></td>
              <td style="font-size:.79rem;color:var(--muted)"><?= e($s['note']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    <?php else: ?>
      <div class="table-responsive">
        <table class="table-x" data-dt>
          <thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th><th>IP address</th></tr></thead>
          <tbody>
          <?php foreach ($activity as $a): ?>
            <tr>
              <td class="mono" style="font-size:.77rem"><?= e(fmt_dt($a['created_at'])) ?></td>
              <td style="font-size:.82rem">
                <?= e($a['actor_name']) ?>
                <span class="d-block" style="font-size:.72rem;color:var(--muted)"><?= e($a['actor_type']) ?></span>
              </td>
              <td><span class="st st-approved"><?= e(str_replace('_', ' ', $a['action'])) ?></span></td>
              <td style="font-size:.8rem;color:var(--muted)"><?= e($a['detail']) ?></td>
              <td class="mono" style="font-size:.77rem"><?= e($a['ip_address']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
