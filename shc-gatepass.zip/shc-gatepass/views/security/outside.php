<?php /** Everyone currently off campus, across all departments. */ ?>
<div class="card-x">
  <div class="cx-head">
    <h2><i class="fa-solid fa-person-walking-arrow-right me-2"></i>Students outside campus</h2>
    <span class="ms-auto st st-out"><?= count($outside) ?> outside</span>
  </div>
  <div class="cx-body p-0">
    <?php require ROOT_PATH . '/views/layouts/_outside_table.php'; ?>
  </div>
</div>
