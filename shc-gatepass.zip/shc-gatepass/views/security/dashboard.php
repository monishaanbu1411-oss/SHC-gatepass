<?php /** Gate alert feed. New approvals arrive here without a page reload. */ ?>
<div class="row g-3 mb-3">
  <?php
  $tiles = [
    ['Outside now',     $stats['outside'],       'person-walking-arrow-right', 'bg-crimson', 'security/outside'],
    ['Waiting to exit', $stats['awaiting_exit'], 'door-open',                  'bg-navy',    'security/dashboard'],
    ['Overdue',         $stats['overdue'],       'triangle-exclamation',       'bg-danger',  'security/outside'],
    ['Issued today',    $stats['issued_today'],  'file-circle-plus',           'bg-violet',  'security/today'],
  ];
  foreach ($tiles as [$label, $num, $icon, $bg, $link]): ?>
    <div class="col-6 col-lg-3">
      <a class="stat" href="<?= url($link) ?>">
        <span class="stat-icon <?= $bg ?>"><i class="fa-solid fa-<?= $icon ?>"></i></span>
        <span>
          <span class="stat-num"><?= (int)$num ?></span>
          <span class="stat-label d-block"><?= e($label) ?></span>
        </span>
      </a>
    </div>
  <?php endforeach; ?>
</div>

<div class="card-x mb-3">
  <div class="cx-body d-flex flex-wrap align-items-center gap-3">
    <span class="stat-icon bg-ok" style="width:54px;height:54px;flex:0 0 54px;font-size:1.35rem">
      <i class="fa-solid fa-qrcode"></i>
    </span>
    <div class="flex-grow-1" style="min-width:180px">
      <div style="font-family:var(--display);font-weight:700;font-size:1.05rem">Scan a student's pass</div>
      <div style="font-size:.83rem;color:var(--muted)">Verify, then allow the exit or record the return.</div>
    </div>
    <a class="btn btn-shc btn-lg" href="<?= url('security/scan') ?>">Open scanner</a>
  </div>
</div>

<div class="card-x">
  <div class="cx-head">
    <h2><i class="fa-solid fa-bell-concierge me-2"></i>Approved passes at the gate</h2>
    <span class="ms-auto d-flex align-items-center gap-2" style="font-size:.78rem;color:var(--muted)">
      <span class="spinner-grow spinner-grow-sm" style="color:var(--ok);width:.5rem;height:.5rem"></span>
      Live feed
    </span>
  </div>
  <div class="cx-body p-0">
    <?php if (!$feed): ?>
      <div class="empty">
        <i class="fa-regular fa-bell"></i>
        <strong>No passes right now</strong>
        When a faculty member approves an outpass it appears here instantly.
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table-x">
          <thead>
            <tr><th>Student</th><th>Class</th><th>Reason</th><th>Return by</th>
                <th>Time left</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
          <?php foreach ($feed as $p): $late = PassModel::overdueMins($p); ?>
            <tr<?= $late ? ' style="background:rgba(192,40,31,.06)"' : '' ?>>
              <td>
                <div class="d-flex align-items-center gap-2">
                  <?php if ($ph = photo_url($p['student_photo'])): ?>
                    <img class="ava ava-sm" src="<?= e($ph) ?>" alt="">
                  <?php else: ?>
                    <span class="ava ava-sm"><?= e(initials($p['student_name'])) ?></span>
                  <?php endif; ?>
                  <span class="lh-1">
                    <span class="d-block" style="font-weight:600"><?= e($p['student_name']) ?></span>
                    <span class="mono" style="font-size:.75rem;color:var(--muted)"><?= e($p['register_no']) ?></span>
                  </span>
                </div>
              </td>
              <td style="font-size:.8rem"><?= e($p['dept_code']) ?> &middot; <?= e($p['prog_name']) ?></td>
              <td style="font-size:.82rem"><?= e(reason_label($p['reason_code'], $p['reason_other'])) ?></td>
              <td class="mono" style="font-size:.8rem"><?= e(fmt_time($p['expiry_time'])) ?></td>
              <td><span class="countdown<?= $late ? ' over' : '' ?>" data-countdown="<?= (int)$p['seconds_left'] ?>">—:—</span></td>
              <td><span class="st <?= status_class($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
              <td><a class="btn btn-sm btn-navy" href="<?= url('security/pass/' . $p['pass_uid']) ?>">Open</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
  // A new approval should put itself on the screen without anyone pressing anything.
  document.addEventListener('shc:notified', function () {
    setTimeout(function () { location.reload(); }, 1200);
  });
</script>
