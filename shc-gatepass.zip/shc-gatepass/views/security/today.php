<?php /** Everything that passed through the gate today. */ ?>
<div class="card-x">
  <div class="cx-head">
    <h2><i class="fa-solid fa-calendar-day me-2"></i>Today's passes</h2>
    <span class="ms-auto" style="font-size:.8rem;color:var(--muted)"><?= e(date('l, d M Y')) ?></span>
  </div>
  <div class="cx-body">
    <?php if (!$passes): ?>
      <div class="empty">
        <i class="fa-regular fa-calendar"></i>
        <strong>Nothing yet today</strong>
        Passes approved today will be listed here.
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table-x" data-dt data-dt-nosort="[6]">
          <thead>
            <tr><th>Pass ID</th><th>Student</th><th>Department</th><th>Out</th>
                <th>Exit / Return</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
          <?php foreach ($passes as $p): ?>
            <tr>
              <td class="mono" style="font-size:.76rem"><?= e($p['pass_uid']) ?></td>
              <td>
                <span style="font-weight:600"><?= e($p['student_name']) ?></span>
                <span class="mono d-block" style="font-size:.74rem;color:var(--muted)"><?= e($p['register_no']) ?></span>
              </td>
              <td style="font-size:.8rem"><?= e($p['dept_code']) ?></td>
              <td class="mono" style="font-size:.78rem"><?= e(fmt_time($p['out_time'])) ?></td>
              <td class="mono" style="font-size:.78rem">
                <?= e(fmt_time($p['exit_time'])) ?> &rarr; <?= e(fmt_time($p['return_time'])) ?>
              </td>
              <td><span class="st <?= status_class($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
              <td><a class="btn btn-sm btn-outline-secondary" href="<?= url('security/pass/' . $p['pass_uid']) ?>">Open</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
