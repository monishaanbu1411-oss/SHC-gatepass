<?php
/** A single pass opened from the alert feed: verdict, details, gate actions. */
$v = [
  'valid'      => ['circle-check',         'Pass verified'],
  'return_due' => ['right-to-bracket',     'Student is outside'],
  'expired'    => ['hourglass-end',        'Pass expired'],
  'used'       => ['circle-minus',         'Pass already used'],
  'revoked'    => ['ban',                  'Pass cancelled'],
  'not_found'  => ['triangle-exclamation', 'Invalid pass'],
][$verdict] ?? ['triangle-exclamation', 'Invalid pass'];
?>
<div class="row g-3">
  <div class="col-12 col-lg-6">

    <div class="verdict <?= e($verdict) ?> mb-3">
      <div class="verdict-icon"><i class="fa-solid fa-<?= e($v[0]) ?>"></i></div>
      <h2 class="verdict-title"><?= e($v[1]) ?></h2>
      <p class="verdict-msg"><?= e($message) ?></p>

      <?php if (!in_array($pass['status'], ['returned', 'expired', 'revoked'], true)): ?>
        <div class="mt-2">
          <span class="countdown" data-countdown="<?= (int)$pass['seconds_left'] ?>"
                style="background:rgba(255,255,255,.2);border-color:transparent;color:#fff;font-size:1.2rem">—:—</span>
        </div>
      <?php endif; ?>

      <?php if ($verdict === 'valid'): ?>
        <button class="btn btn-gate mt-3" style="background:var(--ok);color:#fff"
                data-act="exit" data-uid="<?= e($pass['pass_uid']) ?>">
          <i class="fa-solid fa-door-open me-2"></i>Allow exit
        </button>
      <?php elseif ($verdict === 'return_due'): ?>
        <button class="btn btn-gate mt-3" style="background:var(--navy);color:#fff"
                data-act="return" data-uid="<?= e($pass['pass_uid']) ?>">
          <i class="fa-solid fa-right-to-bracket me-2"></i>Record return
        </button>
      <?php endif; ?>
    </div>

    <div class="card-x">
      <div class="cx-head"><h2><i class="fa-solid fa-user me-2"></i>Student</h2></div>
      <div class="cx-body">
        <div class="d-flex align-items-center gap-3 mb-3">
          <?php if ($ph = photo_url($pass['student_photo'])): ?>
            <img class="ava ava-lg" src="<?= e($ph) ?>" alt="">
          <?php else: ?>
            <span class="ava ava-lg"><?= e(initials($pass['student_name'])) ?></span>
          <?php endif; ?>
          <div>
            <div style="font-family:var(--display);font-weight:700;font-size:1.1rem"><?= e($pass['student_name']) ?></div>
            <div class="mono" style="color:var(--muted)"><?= e($pass['register_no']) ?></div>
            <div style="font-size:.82rem;color:var(--muted)">
              <?= e($pass['dept_name']) ?> &middot; <?= e($pass['prog_name']) ?> &middot; Shift <?= e($pass['shift']) ?>
            </div>
          </div>
        </div>

        <div class="row g-2" style="font-size:.86rem">
          <?php foreach ([
            'Approved by'   => $pass['staff_name'],
            'Reason'        => reason_label($pass['reason_code'], $pass['reason_other']),
            'Destination'   => $pass['destination'] ?: '—',
            'Out time'      => fmt_time($pass['out_time']),
            'Return before' => fmt_time($pass['expiry_time']),
            'Exit recorded' => fmt_time($pass['exit_time']),
            'Blood group'   => $pass['blood_group'] ?: '—',
            'Student phone' => $pass['student_phone'] ?: '—',
            'Parent phone'  => $pass['parent_phone'] ?: '—',
          ] as $k => $val): ?>
            <div class="col-6">
              <div class="form-label mb-0"><?= e($k) ?></div>
              <div style="font-weight:600"><?= e($val) ?></div>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="d-flex flex-wrap gap-2 mt-3">
          <a class="btn btn-outline-secondary btn-sm" href="<?= url('pass/view/' . $pass['pass_uid']) ?>">
            <i class="fa-solid fa-eye me-1"></i>View pass copy
          </a>
          <a class="btn btn-outline-secondary btn-sm" href="<?= url('pass/print/' . $pass['pass_uid']) ?>" target="_blank">
            <i class="fa-solid fa-print me-1"></i>Print outpass
          </a>
          <a class="btn btn-outline-secondary btn-sm" href="<?= url('pass/print/' . $pass['pass_uid']) ?>" target="_blank">
            <i class="fa-solid fa-file-pdf me-1"></i>Save PDF
          </a>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-6">
    <div class="card-x">
      <div class="cx-head"><h2><i class="fa-solid fa-clipboard-list me-2"></i>What happened to this pass</h2></div>
      <div class="cx-body">
        <?php foreach ($events as $ev): ?>
          <div class="d-flex gap-2 py-2" style="border-bottom:1px solid var(--line);font-size:.84rem">
            <span class="st <?= $ev['event'] === 'exit' ? 'st-out' : ($ev['event'] === 'return' ? 'st-returned' : 'st-approved') ?>">
              <?= e($ev['event']) ?>
            </span>
            <span class="flex-grow-1">
              <?= e($ev['note'] ?: '—') ?>
              <span class="d-block" style="color:var(--muted);font-size:.78rem">
                <?= e($ev['actor_name'] ?: $ev['actor_type']) ?>
              </span>
            </span>
            <span class="mono" style="color:var(--muted);white-space:nowrap;font-size:.76rem">
              <?= e(fmt_dt($ev['created_at'])) ?>
            </span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  const { api } = window.SHCApp;
  document.querySelectorAll('[data-act]').forEach(function (btn) {
    btn.addEventListener('click', async function () {
      const act = this.dataset.act;
      this.disabled = true;
      this.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-2"></i>Recording…';

      const res = await api(act === 'exit' ? 'security/allow-exit' : 'security/record-return',
                            { uid: this.dataset.uid });

      if (!res.ok) {
        Swal.fire({ icon: 'error', title: 'Not recorded', text: res.message, confirmButtonColor: '#b3123f' });
        this.disabled = false;
        return;
      }
      Swal.fire({
        icon: 'success',
        title: act === 'exit' ? 'Exit recorded' : 'Return recorded',
        text: res.message, confirmButtonColor: '#b3123f'
      }).then(function () { location.reload(); });
    });
  });
})();
</script>
