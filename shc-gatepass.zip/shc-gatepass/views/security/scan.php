<?php
/**
 * Gate scanning.
 *
 * One decision at a time: scan, read the verdict, press the one button that
 * matters. The verdict fills the screen because it has to be readable at
 * arm's length, outdoors, on a phone.
 */
?>
<div class="row g-3">

  <div class="col-12 col-lg-5">
    <div class="card-x">
      <div class="cx-head"><h2><i class="fa-solid fa-qrcode me-2"></i>Scan a pass</h2></div>
      <div class="cx-body">

        <div id="reader" class="mb-2"></div>

        <div class="d-flex gap-2 mb-3">
          <button class="btn btn-navy flex-grow-1" id="btnCam">
            <i class="fa-solid fa-camera me-1"></i> Start camera
          </button>
          <button class="btn btn-outline-secondary d-none" id="btnStop">Stop</button>
        </div>

        <label class="form-label" for="manualCode">Or use a hand scanner / type the pass ID</label>
        <div class="input-group">
          <input class="form-control mono" id="manualCode" placeholder="SHC-<?= date('Ymd') ?>-0001" autofocus>
          <button class="btn btn-shc" id="btnCheck">Verify</button>
        </div>
        <div class="form-text" style="font-size:.75rem">
          A hand scanner types the code and presses Enter by itself.
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-7">
    <div id="resultArea">
      <div class="card-x">
        <div class="cx-body">
          <div class="empty">
            <i class="fa-solid fa-qrcode"></i>
            <strong>Waiting for a scan</strong>
            Point the camera at the student's QR code, or type the pass ID.
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js"></script>
<script>
(function () {
  const { api, esc } = window.SHCApp;
  const $ = (s) => document.querySelector(s);
  const area = $('#resultArea');
  let scanner = null, busy = false, lastCode = '', lastAt = 0;

  const VERDICTS = {
    valid:      { icon: 'circle-check',        title: 'Pass verified' },
    return_due: { icon: 'right-to-bracket',    title: 'Student is outside' },
    expired:    { icon: 'hourglass-end',       title: 'Pass expired' },
    used:       { icon: 'circle-minus',        title: 'Pass already used' },
    revoked:    { icon: 'ban',                 title: 'Pass cancelled' },
    not_found:  { icon: 'triangle-exclamation',title: 'Invalid pass' },
  };

  // ---- verify ----------------------------------------------------------
  async function verify(code) {
    if (busy || !code) return;
    // A hand scanner can fire the same code twice in a row.
    if (code === lastCode && Date.now() - lastAt < 2500) return;
    lastCode = code; lastAt = Date.now();

    busy = true;
    area.innerHTML = `<div class="card-x"><div class="cx-body text-center py-5">
      <i class="fa-solid fa-spinner fa-spin fa-2x" style="color:var(--navy)"></i>
      <div class="mt-2" style="color:var(--muted)">Checking the pass…</div></div></div>`;

    const res = await api('security/verify', { code: code });
    busy = false;
    draw(res.verdict, res.message, res.pass);
    beep(res.verdict === 'valid' || res.verdict === 'return_due');
  }

  // ---- render the verdict ---------------------------------------------
  function draw(verdict, message, p) {
    const v = VERDICTS[verdict] || VERDICTS.not_found;

    let actions = '';
    if (verdict === 'valid') {
      actions = `<button class="btn btn-gate" style="background:var(--ok);color:#fff" data-act="exit"
                   data-uid="${esc(p.uid)}"><i class="fa-solid fa-door-open me-2"></i>Allow exit</button>`;
    } else if (verdict === 'return_due') {
      actions = `<button class="btn btn-gate" style="background:var(--navy);color:#fff" data-act="return"
                   data-uid="${esc(p.uid)}"><i class="fa-solid fa-right-to-bracket me-2"></i>Record return</button>`;
    }

    let card = '';
    if (p) {
      card = `
        <div class="card-x mt-3">
          <div class="cx-body">
            <div class="d-flex align-items-center gap-3 mb-3">
              ${p.photo ? `<img class="ava ava-lg" src="${esc(p.photo)}" alt="">`
                        : `<span class="ava ava-lg">${esc(p.initials)}</span>`}
              <div class="flex-grow-1">
                <div style="font-family:var(--display);font-weight:700;font-size:1.15rem">${esc(p.student)}</div>
                <div class="mono" style="color:var(--muted)">${esc(p.register)}</div>
                <div style="font-size:.83rem;color:var(--muted)">${esc(p.dept)} · ${esc(p.programme)}</div>
              </div>
              ${p.overdue ? `<span class="st st-expired">Overdue ${p.overdue} min</span>` : ''}
            </div>

            <div class="row g-2" style="font-size:.86rem">
              ${field('Approved by', p.staff)}
              ${field('Reason', p.reason)}
              ${p.destination ? field('Destination', p.destination) : ''}
              ${field('Out time', p.out_time)}
              ${field('Return before', p.expiry)}
              ${p.exit_time ? field('Exit recorded', p.exit_time) : ''}
              ${field('Blood group', p.blood_group || '—')}
              ${field('Student phone', p.phone || '—')}
              ${field('Parent phone', p.parent || '—')}
            </div>

            <div class="d-flex flex-wrap gap-2 mt-3">
              <a class="btn btn-outline-secondary btn-sm" href="${p.view_url}">
                <i class="fa-solid fa-eye me-1"></i>View pass copy</a>
              <a class="btn btn-outline-secondary btn-sm" href="${p.print_url}" target="_blank">
                <i class="fa-solid fa-print me-1"></i>Print outpass</a>
              <a class="btn btn-outline-secondary btn-sm" href="${p.print_url}" target="_blank">
                <i class="fa-solid fa-file-pdf me-1"></i>Save PDF</a>
            </div>
          </div>
        </div>`;
    }

    area.innerHTML = `
      <div class="verdict ${verdict}">
        <div class="verdict-icon"><i class="fa-solid fa-${v.icon}"></i></div>
        <h2 class="verdict-title">${esc(v.title)}</h2>
        <p class="verdict-msg">${esc(message)}</p>
        ${p && p.seconds_left > 0 && verdict !== 'expired'
          ? `<div class="mt-2"><span class="countdown" data-countdown="${p.seconds_left}"
               style="background:rgba(255,255,255,.2);border-color:transparent;color:#fff;font-size:1.2rem">—:—</span></div>`
          : ''}
        ${actions ? `<div class="mt-3">${actions}</div>` : ''}
      </div>
      ${card}`;

    window.SHCApp.tickCountdowns();
    wireActions();
  }

  const field = (k, v) => `
    <div class="col-6">
      <div class="form-label mb-0">${esc(k)}</div>
      <div style="font-weight:600">${esc(v)}</div>
    </div>`;

  // ---- exit / return ---------------------------------------------------
  function wireActions() {
    document.querySelectorAll('[data-act]').forEach((btn) => {
      btn.addEventListener('click', async function () {
        const act = this.dataset.act, uid = this.dataset.uid;
        this.disabled = true;
        this.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-2"></i>Recording…';

        const res = await api(act === 'exit' ? 'security/allow-exit' : 'security/record-return', { uid: uid });

        if (!res.ok) {
          Swal.fire({ icon: 'error', title: 'Not recorded', text: res.message, confirmButtonColor: '#b3123f' });
          draw(res.verdict || 'not_found', res.message, null);
          return;
        }

        Swal.fire({
          icon: 'success',
          title: act === 'exit' ? 'Exit recorded' : 'Return recorded',
          text: res.message,
          confirmButtonColor: '#b3123f',
          timer: 4000, timerProgressBar: true
        });
        draw(act === 'exit' ? 'return_due' : 'used',
             act === 'exit' ? 'Student is now outside. Scan again when they come back.'
                            : 'This pass is complete.',
             res.pass);
      });
    });
  }

  // ---- input sources ---------------------------------------------------
  $('#btnCheck').addEventListener('click', () => verify($('#manualCode').value.trim()));
  $('#manualCode').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      verify($('#manualCode').value.trim());
      $('#manualCode').select();
    }
  });

  $('#btnCam').addEventListener('click', async function () {
    if (!window.Html5Qrcode) {
      Swal.fire({ icon: 'error', title: 'Camera not available',
                  text: 'The scanner library did not load. Use the typed pass ID instead.',
                  confirmButtonColor: '#b3123f' });
      return;
    }
    scanner = new Html5Qrcode('reader');
    try {
      await scanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 240, height: 240 } },
        (text) => verify(text.trim()),
        () => {}
      );
      this.classList.add('d-none');
      $('#btnStop').classList.remove('d-none');
    } catch (err) {
      Swal.fire({
        icon: 'error', title: 'Camera blocked',
        text: 'Allow camera access in the browser, or type the pass ID below.',
        confirmButtonColor: '#b3123f'
      });
    }
  });

  $('#btnStop').addEventListener('click', async function () {
    if (scanner) { await scanner.stop(); scanner.clear(); scanner = null; }
    this.classList.add('d-none');
    $('#btnCam').classList.remove('d-none');
  });

  // Short tone so the guard does not have to look at the screen to know.
  function beep(good) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.frequency.value = good ? 880 : 220;
      o.type = 'sine';
      g.gain.setValueAtTime(0.14, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      o.start(); o.stop(ctx.currentTime + 0.3);
    } catch (e) {}
  }
})();
</script>
