<?php /** The live pass, shown full size so it can be held up at the gate. */ ?>
<?php if (!$active): ?>
  <div class="card-x">
    <div class="cx-body">
      <div class="empty">
        <i class="fa-regular fa-id-card"></i>
        <strong>No live pass right now</strong>
        A movement pass appears here the moment a faculty member approves one for you.
        You cannot apply for one yourself.
      </div>
    </div>
  </div>
<?php else: ?>
  <?php foreach ($active as $p):
    $late = PassModel::overdueMins($p); ?>
    <div class="card-x mb-3">
      <div class="cx-head">
        <h2><i class="fa-solid fa-id-card me-2"></i><span class="mono"><?= e($p['pass_uid']) ?></span></h2>
        <span class="st <?= status_class($p['status']) ?> ms-2"><?= e(status_label($p['status'])) ?></span>
        <div class="ms-auto d-flex gap-2">
          <a class="btn btn-sm btn-navy" href="<?= url('pass/view/' . $p['pass_uid']) ?>">
            <i class="fa-solid fa-expand me-1"></i>Open full pass
          </a>
          <a class="btn btn-sm btn-outline-secondary" href="<?= url('pass/print/' . $p['pass_uid']) ?>" target="_blank">
            <i class="fa-solid fa-print me-1"></i>Print
          </a>
        </div>
      </div>

      <div class="cx-body">
        <div class="row g-3 align-items-center">
          <div class="col-12 col-md-7">
            <div class="d-flex align-items-center gap-3 mb-3">
              <?php if ($ph = photo_url($p['student_photo'])): ?>
                <img class="ava ava-lg" src="<?= e($ph) ?>" alt="">
              <?php else: ?>
                <span class="ava ava-lg"><?= e(initials($p['student_name'])) ?></span>
              <?php endif; ?>
              <div>
                <div style="font-family:var(--display);font-weight:700"><?= e($p['student_name']) ?></div>
                <div class="mono" style="font-size:.82rem;color:var(--muted)"><?= e($p['register_no']) ?></div>
                <div style="font-size:.8rem;color:var(--muted)"><?= e($p['dept_name']) ?> &middot; <?= e($p['prog_name']) ?></div>
              </div>
            </div>

            <?php foreach ([
              'Reason'        => reason_label($p['reason_code'], $p['reason_other']),
              'Destination'   => $p['destination'] ?: '—',
              'Approved by'   => $p['staff_name'],
              'Out time'      => fmt_time($p['out_time']),
              'Return before' => fmt_time($p['expiry_time']),
            ] as $k => $v): ?>
              <div class="d-flex justify-content-between py-1" style="border-bottom:1px solid var(--line);font-size:.86rem">
                <span style="color:var(--muted)"><?= e($k) ?></span>
                <span style="font-weight:600"><?= e($v) ?></span>
              </div>
            <?php endforeach; ?>
          </div>

          <div class="col-12 col-md-5 text-center">
            <div class="mx-auto mb-2" style="width:186px;padding:9px;background:#fff;border:1px solid var(--line);border-radius:var(--r-sm)"
                 id="qr-<?= e($p['pass_uid']) ?>" data-payload="<?= e(PassModel::qrPayload($p)) ?>"></div>
            <div style="font-size:.75rem;color:var(--muted);margin-bottom:.6rem">
              Show this code at the gate
            </div>
            <div class="d-inline-block px-3 py-2" style="border-radius:var(--r-sm);background:var(--surface-2);border:1px solid var(--line)">
              <div class="stat-label"><?= $late ? 'Overdue by' : ($p['status'] === 'left_campus' ? 'Return within' : 'Valid for') ?></div>
              <span class="countdown<?= $late ? ' over' : '' ?>" data-countdown="<?= (int)$p['seconds_left'] ?>"
                    style="font-size:1.45rem">—:—</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>

  <script>
    document.querySelectorAll('[id^="qr-"]').forEach(function (box) {
      if (typeof QRCode === 'undefined') {
        box.innerHTML = '<div style="padding:1.2rem;text-align:center;font-family:monospace;' +
          'font-size:.8rem;color:var(--navy)"><strong>Pass ID</strong><br>' +
          box.id.replace('qr-', '') + '</div>';
        return;
      }
      new QRCode(box, {
        text: box.dataset.payload, width: 168, height: 168,
        colorDark: '#16255c', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M
      });
    });
  </script>
<?php endif; ?>
