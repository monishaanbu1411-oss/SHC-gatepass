<?php /** Full movement history for the signed-in student. */ ?>
<div class="card-x">
  <div class="cx-head">
    <h2><i class="fa-solid fa-clock-rotate-left me-2"></i>My pass history</h2>
    <span class="ms-auto" style="font-size:.8rem;color:var(--muted)"><?= count($passes) ?> records</span>
  </div>
  <div class="cx-body">
    <?php if (!$passes): ?>
      <div class="empty">
        <i class="fa-regular fa-file"></i>
        <strong>No passes yet</strong>
        Passes approved for you will be listed here permanently.
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table-x" data-dt data-dt-order='[[1,"desc"]]' data-dt-nosort="[6]">
          <thead>
            <tr><th>Pass ID</th><th>Date</th><th>Reason</th><th>Approved by</th>
                <th>Out / Return</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
          <?php foreach ($passes as $p): ?>
            <tr>
              <td class="mono" style="font-size:.76rem"><?= e($p['pass_uid']) ?></td>
              <td data-order="<?= e($p['created_at']) ?>" style="font-size:.8rem"><?= e(fmt_dt($p['out_time'])) ?></td>
              <td style="font-size:.83rem"><?= e(reason_label($p['reason_code'], $p['reason_other'])) ?></td>
              <td style="font-size:.83rem"><?= e($p['staff_name']) ?></td>
              <td class="mono" style="font-size:.78rem">
                <?= e(fmt_time($p['exit_time'])) ?> &rarr; <?= e(fmt_time($p['return_time'])) ?>
              </td>
              <td><span class="st <?= status_class($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
              <td><a class="btn btn-sm btn-outline-secondary" href="<?= url('pass/view/' . $p['pass_uid']) ?>">Open</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
