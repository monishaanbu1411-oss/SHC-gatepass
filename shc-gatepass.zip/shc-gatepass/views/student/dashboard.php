<?php /** Student landing page. The live pass is the whole point, so it leads. */ ?>

<?php if ($active): ?>
  <?php $p = $active[0]; $late = PassModel::overdueMins($p); ?>
  <div class="card-x mb-3" style="border-color:var(--crimson);border-width:1.5px">
    <div class="cx-body d-flex flex-wrap align-items-center gap-3">
      <span class="stat-icon bg-crimson" style="width:54px;height:54px;flex:0 0 54px;font-size:1.35rem">
        <i class="fa-solid fa-id-card"></i>
      </span>
      <div class="flex-grow-1" style="min-width:200px">
        <div style="font-family:var(--display);font-weight:700;font-size:1.05rem">
          You have a live movement pass
        </div>
        <div style="font-size:.85rem;color:var(--muted)">
          <?= e(reason_label($p['reason_code'], $p['reason_other'])) ?> &middot;
          approved by <?= e($p['staff_name']) ?> &middot;
          return before <span class="mono"><?= e(fmt_time($p['expiry_time'])) ?></span>
        </div>
      </div>
      <div class="text-center">
        <div class="stat-label"><?= $late ? 'Overdue by' : 'Time left' ?></div>
        <span class="countdown<?= $late ? ' over' : '' ?>" data-countdown="<?= (int)$p['seconds_left'] ?>"
              style="font-size:1.25rem">—:—</span>
      </div>
      <a class="btn btn-shc btn-lg" href="<?= url('student/passes') ?>">Show my pass</a>
    </div>
  </div>
<?php endif; ?>

<div class="row g-3 mb-3">
  <?php
  $tiles = [
    ['Passes this month', $counts['month'],    'calendar-check',    'bg-navy'],
    ['Total passes',      $counts['total'],    'id-card',           'bg-violet'],
    ['Completed',         $counts['returned'], 'circle-check',      'bg-ok'],
    ['Expired unused',    $counts['expired'],  'hourglass-end',     'bg-warn'],
  ];
  foreach ($tiles as [$label, $num, $icon, $bg]): ?>
    <div class="col-6 col-lg-3">
      <div class="stat">
        <span class="stat-icon <?= $bg ?>"><i class="fa-solid fa-<?= $icon ?>"></i></span>
        <span>
          <span class="stat-num"><?= (int)$num ?></span>
          <span class="stat-label d-block"><?= e($label) ?></span>
        </span>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-7">
    <div class="card-x h-100">
      <div class="cx-head">
        <h2><i class="fa-solid fa-clock-rotate-left me-2"></i>Recent passes</h2>
        <a class="ms-auto btn btn-sm btn-outline-secondary" href="<?= url('student/history') ?>">See all</a>
      </div>
      <div class="cx-body p-0">
        <?php if (!$recent): ?>
          <div class="empty">
            <i class="fa-regular fa-file"></i>
            <strong>No passes yet</strong>
            A pass appears here as soon as a faculty member approves one for you.
          </div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table-x">
              <thead><tr><th>Date</th><th>Reason</th><th>Approved by</th><th>Status</th><th></th></tr></thead>
              <tbody>
              <?php foreach ($recent as $p): ?>
                <tr>
                  <td class="mono" style="font-size:.79rem"><?= e(fmt_date($p['out_time'])) ?></td>
                  <td style="font-size:.83rem"><?= e(reason_label($p['reason_code'], $p['reason_other'])) ?></td>
                  <td style="font-size:.83rem"><?= e($p['staff_name']) ?></td>
                  <td><span class="st <?= status_class($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
                  <td><a class="btn btn-sm btn-outline-secondary" href="<?= url('pass/view/' . $p['pass_uid']) ?>">Open</a></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-5">
    <div class="card-x h-100">
      <div class="cx-head"><h2><i class="fa-solid fa-user me-2"></i>My details</h2></div>
      <div class="cx-body">
        <div class="d-flex align-items-center gap-3 mb-3">
          <?php if ($ph = photo_url($me['photo'])): ?>
            <img class="ava ava-lg" src="<?= e($ph) ?>" alt="">
          <?php else: ?>
            <span class="ava ava-lg"><?= e(initials($me['name'])) ?></span>
          <?php endif; ?>
          <div>
            <div style="font-family:var(--display);font-weight:700;font-size:1.05rem"><?= e($me['name']) ?></div>
            <div class="mono" style="font-size:.83rem;color:var(--muted)"><?= e($me['register_no']) ?></div>
          </div>
        </div>
        <?php foreach ([
          'Department' => $me['dept_name'],
          'Class'      => $me['prog_name'] . ' · Shift ' . $me['shift'],
          'Residence'  => $me['residence'],
          'Blood group'=> $me['blood_group'],
        ] as $k => $v): ?>
          <div class="d-flex justify-content-between py-1" style="border-bottom:1px solid var(--line);font-size:.85rem">
            <span style="color:var(--muted)"><?= e($k) ?></span>
            <span style="font-weight:600"><?= e($v ?: '—') ?></span>
          </div>
        <?php endforeach; ?>
        <a class="btn btn-outline-secondary btn-sm w-100 mt-3" href="<?= url('student/profile') ?>">Full profile</a>
      </div>
    </div>
  </div>
</div>
