<?php /** Read-only profile. Corrections go through the department office. */ ?>
<div class="row g-3">
  <div class="col-12 col-lg-4">
    <div class="card-x h-100">
      <div class="cx-body text-center">
        <?php if ($ph = photo_url($me['photo'])): ?>
          <img class="ava ava-xl mb-2" src="<?= e($ph) ?>" alt="">
        <?php else: ?>
          <span class="ava ava-xl mb-2"><?= e(initials($me['name'])) ?></span>
        <?php endif; ?>
        <h2 style="margin:.3rem 0 .1rem;font-size:1.1rem"><?= e($me['name']) ?></h2>
        <div class="mono" style="color:var(--muted)"><?= e($me['register_no']) ?></div>
        <div class="st st-approved mt-2"><?= e($me['dept_code']) ?> &middot; <?= e($me['prog_name']) ?></div>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-8">
    <div class="card-x h-100">
      <div class="cx-head"><h2><i class="fa-solid fa-id-badge me-2"></i>Registered details</h2></div>
      <div class="cx-body">
        <div class="row g-3">
          <?php foreach ([
            'Department'        => $me['dept_name'],
            'Programme'         => $me['prog_name'] . ' · Shift ' . $me['shift'],
            'Year of study'     => $me['study_year'],
            'Date of birth'     => fmt_date($me['dob']),
            'Residence'         => $me['residence'],
            'Blood group'       => $me['blood_group'],
            'Phone'             => $me['phone'],
            'Parent / guardian' => $me['parent_phone'],
            'Email'             => $me['email'],
          ] as $k => $v): ?>
            <div class="col-12 col-md-6">
              <div class="form-label mb-0"><?= e($k) ?></div>
              <div style="font-weight:600"><?= e($v ?: '—') ?></div>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="alert mt-3 mb-0 py-2" style="background:var(--surface-2);border:1px solid var(--line);font-size:.82rem">
          <i class="fa-solid fa-circle-info me-1" style="color:var(--navy)"></i>
          These details come from the college records. To correct anything, visit the department office.
        </div>
      </div>
    </div>
  </div>
</div>
