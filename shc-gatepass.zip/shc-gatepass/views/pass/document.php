<?php
/**
 * The movement pass itself.
 *
 * Deliberately shaped like the pink Shift-II slip it replaces: the same
 * masthead, the same "Shift - II | STUDENT MOVEMENT PASS" band, the same
 * field order and reason checkboxes, the same signature line. What the paper
 * could not do is added underneath: the student's photo, a live countdown,
 * a QR code and a Code 128 barcode for the gate.
 */
$dead    = in_array($pass['status'], ['expired', 'revoked', 'returned'], true);
$secs    = (int)$pass['seconds_left'];
$overdue = PassModel::overdueMins($pass);
$photo   = photo_url($pass['student_photo']);
$stamp   = match ($pass['status']) {
    'expired'  => 'EXPIRED',
    'revoked'  => 'CANCELLED',
    'returned' => 'COMPLETED',
    default    => null,
};
?>
<!doctype html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Movement pass <?= e($pass['pass_uid']) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Public+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="<?= url('assets/css/app.css') ?>" rel="stylesheet">
<style>body { background: var(--bg); padding: 1.4rem .8rem; }</style>
</head>
<body>

<div class="no-print d-flex flex-wrap gap-2 justify-content-center mb-3">
  <button class="btn btn-navy btn-sm" onclick="window.print()">
    <i class="fa-solid fa-print me-1"></i> Print outpass
  </button>
  <button class="btn btn-outline-secondary btn-sm" onclick="window.print()">
    <i class="fa-solid fa-file-pdf me-1"></i> Save as PDF
  </button>
  <button class="btn btn-outline-secondary btn-sm" id="qrBig">
    <i class="fa-solid fa-expand me-1"></i> Show QR full screen
  </button>
  <a class="btn btn-outline-secondary btn-sm" href="javascript:history.back()">
    <i class="fa-solid fa-arrow-left me-1"></i> Back
  </a>
</div>

<!-- ============================ THE PASS ============================ -->
<article class="pass-doc<?= $dead ? ' is-void' : '' ?>" id="passDoc">

  <?php if ($stamp): ?>
    <div class="pd-stamp"><span><?= e($stamp) ?></span></div>
  <?php endif; ?>

  <header class="pd-head">
    <span class="pd-crest">SHC</span>
    <div>
      <div class="pd-college">SACRED HEART COLLEGE</div>
      <div class="pd-auto">(AUTONOMOUS)</div>
      <div class="pd-addr">Tirupattur, Tirupattur District &ndash; 635601.</div>
    </div>
  </header>

  <div class="pd-band">
    <div class="pd-shift">Shift &ndash; <?= e($pass['shift']) ?></div>
    <div class="pd-kind">
      <span>STUDENT MOVEMENT PASS</span>
      <span class="pd-uid"><?= e($pass['pass_uid']) ?></span>
    </div>
  </div>

  <div class="pd-body">

    <div class="d-flex gap-3 align-items-start mb-2">
      <div class="flex-grow-1">
        <div class="pd-row">
          <span class="pd-key">Date</span>
          <span class="pd-val mono"><?= e(fmt_date($pass['out_time'])) ?></span>
        </div>
        <div class="pd-row">
          <span class="pd-key">Name</span>
          <span class="pd-val"><?= e($pass['student_name']) ?></span>
        </div>
        <div class="pd-row">
          <span class="pd-key">Register No</span>
          <span class="pd-val mono"><?= e($pass['register_no']) ?></span>
        </div>
        <div class="pd-row">
          <span class="pd-key">Department</span>
          <span class="pd-val"><?= e($pass['dept_name']) ?> &middot; <?= e($pass['prog_name']) ?></span>
        </div>
      </div>

      <?php if ($photo): ?>
        <img class="ava ava-xl" src="<?= e($photo) ?>" alt="<?= e($pass['student_name']) ?>"
             style="border-color:var(--violet)">
      <?php else: ?>
        <span class="ava ava-xl" style="border-color:var(--violet);color:var(--violet);background:rgba(255,255,255,.55)">
          <?= e(initials($pass['student_name'])) ?>
        </span>
      <?php endif; ?>
    </div>

    <div class="pd-reason-title">REASON FOR GOING OUT :</div>
    <div class="pd-reasons">
      <?php foreach (REASONS as $code => $label):
        $on = $code === $pass['reason_code']; ?>
        <span class="pd-reason<?= $on ? ' on' : '' ?>">
          <span class="pd-box"><?= $on ? '&#10005;' : '' ?></span><?= e($label) ?>
        </span>
      <?php endforeach; ?>
    </div>

    <?php if ($pass['reason_code'] === 'other' && $pass['reason_other']): ?>
      <div class="pd-row mt-2">
        <span class="pd-key">Specify</span>
        <span class="pd-val"><?= e($pass['reason_other']) ?></span>
      </div>
    <?php endif; ?>
    <?php if ($pass['destination']): ?>
      <div class="pd-row mt-1">
        <span class="pd-key">Destination</span>
        <span class="pd-val"><?= e($pass['destination']) ?></span>
      </div>
    <?php endif; ?>

    <div class="pd-times">
      <div>
        <div class="pd-time-k">Out time</div>
        <div class="pd-time-v"><?= e(fmt_time($pass['out_time'])) ?></div>
      </div>
      <div>
        <div class="pd-time-k">Validity</div>
        <div class="pd-time-v"><?= e(fmt_mins((int)$pass['validity_mins'])) ?></div>
      </div>
      <div>
        <div class="pd-time-k">Return before</div>
        <div class="pd-time-v"><?= e(fmt_time($pass['expiry_time'])) ?></div>
      </div>
      <?php if ($pass['course_code']): ?>
        <div>
          <div class="pd-time-k">Class hour</div>
          <div class="pd-time-v"><?= e($pass['course_code']) ?><?= $pass['hours'] ? ' &middot; H' . e($pass['hours']) : '' ?></div>
        </div>
      <?php endif; ?>
    </div>

    <?php if ($pass['exit_time'] || $pass['return_time']): ?>
      <div class="pd-times" style="border-top-style:solid">
        <div>
          <div class="pd-time-k">Exit recorded</div>
          <div class="pd-time-v"><?= e(fmt_time($pass['exit_time'])) ?></div>
        </div>
        <div>
          <div class="pd-time-k">Return recorded</div>
          <div class="pd-time-v"><?= e(fmt_time($pass['return_time'])) ?></div>
        </div>
      </div>
    <?php endif; ?>

    <div class="pd-sign">
      <div>
        <div class="pd-sign-name"><?= e($pass['staff_name']) ?></div>
        <div class="pd-sign-line">
          <?= e($pass['designation'] ?: 'Faculty') ?> &middot;
          <span class="mono"><?= e($pass['staff_code']) ?></span>
        </div>
        <div class="pd-sign-line">Approved <?= e(fmt_dt($pass['created_at'])) ?></div>
      </div>
      <div class="text-center">
        <span class="pd-sign-mark"><?= e($pass['staff_name']) ?></span>
        <div class="pd-sign-line mt-1">Signature of approving faculty / HOD</div>
      </div>
    </div>
  </div>

  <div class="pd-codes">
    <div class="pd-qr" id="qrBox" data-payload="<?= e(PassModel::qrPayload($pass)) ?>"></div>
    <div class="pd-barcode">
      <?= $barcode ?>
      <div style="font-size:.64rem;letter-spacing:.08em;opacity:.75;margin-top:.2rem">
        SHOW THIS PASS AT THE GATE WHEN GOING OUT
      </div>
    </div>
  </div>

  <?php if (!$dead): ?>
    <div class="pd-clock<?= $overdue ? ' is-over' : '' ?>">
      <div class="text-center">
        <div class="lbl"><?= $overdue ? 'Overdue by' : ($pass['status'] === 'left_campus' ? 'Return within' : 'Valid for') ?></div>
        <div class="big countdown" data-countdown="<?= $secs ?>" style="background:none;border:none;color:inherit;padding:0">
          &mdash;:&mdash;
        </div>
      </div>
    </div>
  <?php endif; ?>

  <footer class="pd-foot">
    (Student should produce this pass at the gate at the time of going out)<br>
    Pass ID <span class="mono"><?= e($pass['pass_uid']) ?></span> &middot;
    Status: <strong><?= e(status_label($pass['status'])) ?></strong>
  </footer>
</article>

<!-- ============================ AUDIT TRAIL ============================ -->
<?php if (!empty($events)): ?>
  <div class="card-x no-print mx-auto mt-3" style="max-width:560px">
    <div class="cx-head"><h2><i class="fa-solid fa-clipboard-list me-2"></i>Pass history</h2></div>
    <div class="cx-body py-2">
      <?php foreach ($events as $ev): ?>
        <div class="d-flex gap-2 py-2" style="border-bottom:1px solid var(--line);font-size:.83rem">
          <span class="st st-<?= $ev['event'] === 'exit' ? 'out' : ($ev['event'] === 'return' ? 'returned' : 'approved') ?>">
            <?= e($ev['event']) ?>
          </span>
          <span class="flex-grow-1">
            <?= e($ev['note'] ?: '-') ?>
            <span style="color:var(--muted)">&middot; <?= e($ev['actor_name'] ?: $ev['actor_type']) ?></span>
          </span>
          <span class="mono" style="color:var(--muted);white-space:nowrap"><?= e(fmt_dt($ev['created_at'])) ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.10.7/sweetalert2.all.min.js"></script>
<script>
(function () {
  var box = document.getElementById('qrBox');
  var payload = box.dataset.payload;

  // If the QR library did not load (offline intranet), fall back to the pass ID
  // in large type so the gate can still key it in by hand.
  if (typeof QRCode === 'undefined') {
    box.innerHTML = '<div style="display:grid;place-items:center;height:100%;text-align:center;' +
      'font-family:monospace;font-size:.62rem;line-height:1.35;color:#4b2a86;padding:4px">' +
      '<div><strong>PASS ID</strong><br>' + <?= json_encode($pass['pass_uid']) ?> + '</div></div>';
  } else {
    new QRCode(box, {
      text: payload, width: 220, height: 220,
      colorDark: '#4b2a86', colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.M
    });
  }

  // Full-screen QR, for holding the phone up to a hand scanner.
  document.getElementById('qrBig').addEventListener('click', function () {
    if (typeof QRCode === 'undefined') { return; }
    var holder = document.createElement('div');
    new QRCode(holder, { text: payload, width: 300, height: 300,
                         colorDark: '#000000', colorLight: '#ffffff',
                         correctLevel: QRCode.CorrectLevel.M });
    Swal.fire({
      title: <?= json_encode($pass['pass_uid']) ?>,
      html: holder,
      width: 380,
      confirmButtonText: 'Close',
      confirmButtonColor: '#b3123f'
    });
  });

  // Live countdown on the pass face.
  var el = document.querySelector('[data-countdown]');
  if (el) {
    var paint = function (step) {
      var s = parseInt(el.dataset.countdown, 10) - (step ? 1 : 0);
      el.dataset.countdown = s;
      var over = s < 0, a = Math.abs(s);
      var h = Math.floor(a / 3600), m = Math.floor((a % 3600) / 60), sec = a % 60;
      var p = function (n) { return String(n).padStart(2, '0'); };
      el.textContent = (over ? '+' : '') + (h > 0 ? h + ':' : '') + p(m) + ':' + p(sec);
      if (over) el.closest('.pd-clock').classList.add('is-over');
    };
    paint(false);                      // show the real time straight away
    setInterval(function () { paint(true); }, 1000);
  }

  <?php if (!empty($print)): ?>
  window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 550); });
  <?php endif; ?>
})();
</script>
</body>
</html>
