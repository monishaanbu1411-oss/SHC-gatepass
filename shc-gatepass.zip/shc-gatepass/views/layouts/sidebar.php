<?php
/** Left navigation. The menu is built per role, so nobody sees a link they cannot open. */
$u = Auth::user();

$menus = [
  'student' => [
    'Movement' => [
      ['student/dashboard',     'gauge',            'Dashboard'],
      ['student/passes',        'id-card',          'My approved passes'],
      ['student/history',       'clock-rotate-left','Pass history'],
    ],
    'Account' => [
      ['student/notifications', 'bell',             'Notifications'],
      ['student/profile',       'user',             'My profile'],
    ],
  ],
  'staff' => [
    'Passes' => [
      ['staff/dashboard', 'gauge',             'Dashboard'],
      ['staff/issue',     'file-circle-plus',  'Issue movement pass'],
      ['staff/monitor',   'street-view',       Auth::isHod() ? 'Department monitor' : 'Students I sent out'],
      ['staff/history',   'clock-rotate-left', 'Passes I issued'],
    ],
    'Class' => [
      ['staff/students',      'users', 'Students'],
      ['staff/notifications', 'bell',  'Notifications'],
    ],
  ],
  'watchman' => [
    'Gate' => [
      ['security/dashboard', 'bell-concierge', 'Gate alerts'],
      ['security/scan',      'qrcode',         'Scan pass'],
      ['security/outside',   'person-walking-arrow-right', 'Students outside'],
      ['security/today',     'calendar-day',   "Today's passes"],
    ],
  ],
  'admin' => [
    'Overview' => [
      ['admin/dashboard', 'chart-line', 'Dashboard'],
      ['admin/passes',    'id-card',    'All movement passes'],
    ],
    'Accounts' => [
      ['admin/students', 'user-graduate',    'Students'],
      ['admin/staff',    'chalkboard-user',  'Staff & HODs'],
      ['admin/watchmen', 'user-shield',      'Gate security'],
    ],
    'System' => [
      ['admin/logs',          'clipboard-list', 'Audit & system logs'],
      ['admin/notifications', 'bell',           'Notifications'],
    ],
  ],
];

$roleLabel = match (Auth::type()) {
  'student'  => 'Student',
  'staff'    => Auth::isHod() ? 'Head of Department' : 'Faculty',
  'watchman' => 'Gate security',
  'admin'    => 'Administrator',
  default    => '',
};
?>
<div class="sb-scrim no-print d-none" id="sbScrim"></div>

<nav class="sidebar no-print" id="sidebar">
  <div class="sb-brand">
    <span class="sb-crest">SHC</span>
    <div>
      <div class="sb-title">Movement Pass</div>
      <div class="sb-role"><?= e($roleLabel) ?></div>
    </div>
  </div>

  <div class="sb-nav">
    <?php foreach ($menus[Auth::type()] ?? [] as $section => $links): ?>
      <div class="sb-section"><?= e($section) ?></div>
      <?php foreach ($links as [$route, $icon, $label]): ?>
        <a class="sb-link<?= nav_active($route) ?>" href="<?= url($route) ?>">
          <i class="fa-solid fa-<?= e($icon) ?>"></i>
          <span><?= e($label) ?></span>
          <?php if (str_ends_with($route, 'notifications')): ?>
            <span class="sb-count d-none" id="navUnread">0</span>
          <?php endif; ?>
        </a>
      <?php endforeach; ?>
    <?php endforeach; ?>

    <div class="sb-section">Session</div>
    <a class="sb-link" href="#" id="themeToggle">
      <i class="fa-solid fa-circle-half-stroke"></i><span>Switch theme</span>
    </a>
    <a class="sb-link" href="<?= url('logout') ?>">
      <i class="fa-solid fa-right-from-bracket"></i><span>Sign out</span>
    </a>
  </div>
</nav>

<div class="main">
  <div class="topbar">
    <button class="btn btn-sm btn-outline-secondary sb-toggle" id="sbToggle" aria-label="Open menu">
      <i class="fa-solid fa-bars"></i>
    </button>
    <h1 class="page-title"><?= e($pageTitle) ?></h1>

    <div class="ms-auto d-flex align-items-center gap-2">
      <span class="clock d-none d-md-inline" id="liveClock"><?= date('D, d M Y · h:i:s A') ?></span>

      <div class="dropdown">
        <button class="btn btn-sm btn-outline-secondary position-relative" data-bs-toggle="dropdown"
                aria-label="Notifications">
          <i class="fa-solid fa-bell"></i>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill d-none"
                style="background:var(--crimson)" id="bellCount">0</span>
        </button>
        <div class="dropdown-menu dropdown-menu-end p-0" style="width:330px;max-height:420px;overflow:auto">
          <div class="d-flex align-items-center justify-content-between px-3 py-2 border-bottom">
            <strong style="font-size:.85rem">Notifications</strong>
            <a href="#" id="markAllRead" style="font-size:.75rem">Mark all read</a>
          </div>
          <div id="bellList"><div class="empty py-4"><i class="fa-regular fa-bell"></i>Nothing yet</div></div>
        </div>
      </div>

      <div class="d-flex align-items-center gap-2">
        <span class="ava ava-sm"><?= e(initials($u['name'])) ?></span>
        <div class="d-none d-lg-block lh-1">
          <div style="font-size:.82rem;font-weight:600"><?= e($u['name']) ?></div>
          <div class="mono" style="font-size:.7rem;color:var(--muted)"><?= e($u['ident']) ?></div>
        </div>
      </div>
    </div>
  </div>

  <div class="content">
    <?php foreach ($flashes as $f): ?>
      <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show" role="alert">
        <?= e($f['msg']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endforeach; ?>
