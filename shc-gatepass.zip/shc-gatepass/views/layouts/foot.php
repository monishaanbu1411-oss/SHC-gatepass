    </div><!-- /.content -->

    <footer class="no-print text-center py-3" style="font-size:.75rem;color:var(--muted)">
      <?= e(COLLEGE_NAME) ?> &middot; Student Movement &amp; Gate Pass System
      &middot; <span class="mono"><?= date('Y') ?></span>
    </footer>
  </div><!-- /.main -->
</div><!-- /.shell -->

<?php if (!empty($pageScripts)) echo $pageScripts; ?>
</body>
</html>
