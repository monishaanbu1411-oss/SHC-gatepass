<?php /** Document head + college masthead + opening of the app shell. */ ?>
<!doctype html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#16255c">
<title><?= e($pageTitle) ?> &middot; SHC Gate Pass</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Public+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables.net-bs5/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<link href="<?= url('assets/css/app.css') ?>" rel="stylesheet">
<script>
  // Apply the saved theme before first paint so the page never flashes white.
  try {
    var t = localStorage.getItem('shc-theme');
    if (t) document.documentElement.setAttribute('data-theme', t);
  } catch (e) {}
</script>

<!--
  Libraries load here, in the head, rather than at the end of the body.
  Individual views carry their own inline scripts, and those run while the
  body is still being parsed - so anything they depend on has to already
  exist. app.js waits for DOMContentLoaded before touching the page.
-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.10.7/sweetalert2.all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables.net/1.13.7/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables.net-bs5/1.13.7/dataTables.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.2/chart.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
  window.SHC = {
    base: <?= json_encode(BASE_URL) ?>,
    csrf: <?= json_encode(Csrf::token()) ?>,
    role: <?= json_encode(Auth::type()) ?>
  };
</script>
<script src="<?= url('assets/js/app.js') ?>"></script>
</head>
<body>

<header class="masthead no-print">
  <div class="mh-name"><?= e(COLLEGE_NAME) ?></div>
  <div class="mh-sub"><?= e(COLLEGE_ADDRESS) ?> &middot; <?= e(COLLEGE_UNIV) ?></div>
</header>

<div class="shell">
