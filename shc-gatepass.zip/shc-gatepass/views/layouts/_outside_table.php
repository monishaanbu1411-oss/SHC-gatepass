<?php
/**
 * Shared table of students currently off campus.
 * Used by the HOD monitor, the gate screens and the admin drill-down.
 * Expects: $outside (array of pass rows), optional $showDept (bool).
 */
$showDept = $showDept ?? true;
?>
<?php if (!$outside): ?>
  <div class="empty">
    <i class="fa-solid fa-user-check"></i>
    <strong>Everyone is on campus</strong>
    No student is currently outside.
  </div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table-x">
      <thead>
        <tr>
          <th>Student</th>
          <?php if ($showDept): ?><th>Department</th><?php endif; ?>
          <th>Approved by</th>
          <th>Reason</th>
          <th>Out</th>
          <th>Return by</th>
          <th>Time left</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($outside as $p):
        $late = PassModel::overdueMins($p); ?>
        <tr<?= $late ? ' style="background:rgba(192,40,31,.06)"' : '' ?>>
          <td>
            <div class="d-flex align-items-center gap-2">
              <?php if ($ph = photo_url($p['student_photo'])): ?>
                <img class="ava ava-sm" src="<?= e($ph) ?>" alt="">
              <?php else: ?>
                <span class="ava ava-sm"><?= e(initials($p['student_name'])) ?></span>
              <?php endif; ?>
              <span class="lh-1">
                <span class="d-block" style="font-weight:600"><?= e($p['student_name']) ?></span>
                <span class="mono" style="font-size:.75rem;color:var(--muted)"><?= e($p['register_no']) ?></span>
              </span>
            </div>
          </td>
          <?php if ($showDept): ?>
            <td><span class="mono" style="font-size:.78rem"><?= e($p['dept_code']) ?></span>
                <span class="d-block" style="font-size:.74rem;color:var(--muted)"><?= e($p['prog_name']) ?></span></td>
          <?php endif; ?>
          <td style="font-size:.83rem"><?= e($p['staff_name']) ?></td>
          <td style="font-size:.83rem"><?= e(reason_label($p['reason_code'], $p['reason_other'])) ?></td>
          <td class="mono" style="font-size:.8rem"><?= e(fmt_time($p['exit_time'] ?: $p['out_time'])) ?></td>
          <td class="mono" style="font-size:.8rem"><?= e(fmt_time($p['expiry_time'])) ?></td>
          <td>
            <span class="countdown<?= $late ? ' over' : '' ?>" data-countdown="<?= (int)$p['seconds_left'] ?>">—:—</span>
          </td>
          <td><a class="btn btn-sm btn-outline-secondary" href="<?= url('pass/view/' . $p['pass_uid']) ?>">Pass</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>
