<?php /** Notification inbox, shared by all four roles. */ ?>
<div class="card-x" style="max-width:820px">
  <div class="cx-head">
    <h2><i class="fa-solid fa-bell me-2"></i>Notifications</h2>
    <span class="ms-auto" style="font-size:.8rem;color:var(--muted)"><?= count($items) ?> recent</span>
  </div>
  <div class="cx-body pt-0">
    <?php if (!$items): ?>
      <div class="empty">
        <i class="fa-regular fa-bell"></i>
        <strong>Nothing yet</strong>
        Alerts about passes will appear here.
      </div>
    <?php else: ?>
      <?php foreach ($items as $n):
        $icon = match ($n['icon']) {
          'check' => 'circle-check', 'walk' => 'person-walking', 'gate' => 'door-open',
          'out'   => 'right-from-bracket', 'in' => 'right-to-bracket', 'ban' => 'ban',
          default => 'bell',
        }; ?>
        <a class="notif-item<?= (int)$n['is_read'] ? '' : ' unread' ?>"
           href="<?= $n['link'] ? e(url($n['link'])) : '#' ?>"
           style="text-decoration:none;color:inherit">
          <span class="notif-dot"><i class="fa-solid fa-<?= e($icon) ?>"></i></span>
          <span class="flex-grow-1">
            <span class="notif-title d-block"><?= e($n['title']) ?></span>
            <span class="notif-body d-block"><?= e($n['body']) ?></span>
          </span>
          <span class="notif-when"><?= e(fmt_dt($n['created_at'])) ?></span>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
