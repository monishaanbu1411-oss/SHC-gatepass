<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Page not found</title>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700&family=Public+Sans:wght@400;600&display=swap" rel="stylesheet">
<link href="<?= url('assets/css/app.css') ?>" rel="stylesheet">
</head><body>
<div style="min-height:100vh;display:grid;place-items:center;padding:2rem;text-align:center">
  <div>
    <div style="font-family:var(--display);font-weight:800;font-size:4rem;color:var(--crimson);line-height:1">404</div>
    <h1 style="margin:.4rem 0">That page is not here</h1>
    <p style="color:var(--muted);max-width:44ch;margin:0 auto 1.4rem">
      The link may be old, or the pass you are looking for was removed.
    </p>
    <a class="btn btn-shc" href="<?= url('') ?>">Back to sign in</a>
  </div>
</div>
</body></html>
