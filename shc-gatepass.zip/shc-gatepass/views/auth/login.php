<?php
/** Sign in. One page, four roles: the field labels change with the tab. */
$roles = [
  'student'  => ['user-graduate',   'Student',  'Register Number', 'Date of Birth',
                 'BU2610A01', 'date',     'Your account is created by the office. Sign in with your register number and date of birth.'],
  'staff'    => ['chalkboard-user', 'Staff',    'Staff ID',        'Password',
                 'T261002',   'password', 'Faculty and Heads of Department issue movement passes from here.'],
  'watchman' => ['user-shield',     'Security', 'Username',        'Password',
                 'gate01',    'password', 'Gate duty. Scan a pass to verify it and record exits and returns.'],
  'admin'    => ['user-gear',       'Admin',    'Username',        'Password',
                 'admin',     'password', 'Full control of accounts, departments, analytics and audit logs.'],
];
[$icon, $label, $idLabel, $secretLabel, $placeholder, $secretType, $blurb] = $roles[$role];
?>
<!doctype html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#16255c">
<title>Sign in &middot; SHC Movement Pass</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Public+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="<?= url('assets/css/app.css') ?>" rel="stylesheet">
</head>
<body>

<div class="login-wrap">

  <section class="login-art">
    <span class="sb-crest mb-4" style="width:56px;height:56px;font-size:1rem">SHC</span>
    <h1><?= e(COLLEGE_NAME) ?></h1>
    <p class="la-sub"><?= e(COLLEGE_ADDRESS) ?></p>
    <p class="la-sub" style="font-size:.82rem"><?= e(COLLEGE_ACCRED) ?>, <?= e(COLLEGE_UNIV) ?>.</p>

    <div class="la-note">
      <strong style="display:block;font-family:var(--display);letter-spacing:.04em;margin-bottom:.3rem">
        STUDENT MOVEMENT PASS
      </strong>
      The pink slip is now digital. Faculty approve a pass during class, and the
      student, the Head of Department and the gate are told at the same moment.
    </div>
  </section>

  <section class="login-panel">
    <div class="login-box">

      <div class="role-tabs">
        <?php foreach ($roles as $key => $r): ?>
          <a class="role-tab<?= $key === $role ? ' on' : '' ?>" href="<?= url('login?as=' . $key) ?>">
            <i class="fa-solid fa-<?= e($r[0]) ?>"></i><?= e($r[1]) ?>
          </a>
        <?php endforeach; ?>
      </div>

      <h2 style="margin-bottom:.15rem"><?= e($label) ?> sign in</h2>
      <p style="color:var(--muted);font-size:.84rem;margin-bottom:1.2rem"><?= e($blurb) ?></p>

      <?php foreach ($flashes as $f): ?>
        <div class="alert alert-<?= e($f['type']) ?> py-2" style="font-size:.86rem"><?= e($f['msg']) ?></div>
      <?php endforeach; ?>

      <form method="post" action="<?= url('login') ?>" autocomplete="off">
        <?= Csrf::field() ?>
        <input type="hidden" name="role" value="<?= e($role) ?>">

        <div class="mb-3">
          <label class="form-label" for="identifier"><?= e($idLabel) ?></label>
          <input class="form-control form-control-lg" id="identifier" name="identifier"
                 placeholder="<?= e($placeholder) ?>" required autofocus
                 <?= $role === 'student' ? 'style="text-transform:uppercase"' : '' ?>>
        </div>

        <div class="mb-3">
          <label class="form-label" for="secret"><?= e($secretLabel) ?></label>
          <input class="form-control form-control-lg" id="secret" name="secret"
                 type="<?= e($secretType) ?>" required
                 <?= $role === 'student' ? 'max="2099-12-31"' : 'placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;"' ?>>
          <?php if ($role === 'student'): ?>
            <div class="form-text" style="font-size:.75rem">Use the date of birth recorded in the college office.</div>
          <?php endif; ?>
        </div>

        <button class="btn btn-shc btn-lg w-100 mb-3" type="submit">
          Sign in <i class="fa-solid fa-arrow-right ms-1"></i>
        </button>
      </form>

      <p style="font-size:.75rem;color:var(--muted);text-align:center;margin:0">
        Trouble signing in? Contact the department office.<br>
        Accounts are locked for <?= (int)LOCKOUT_MINUTES ?> minutes after
        <?= (int)MAX_LOGIN_ATTEMPTS ?> failed attempts.
      </p>
    </div>
  </section>
</div>

</body>
</html>
