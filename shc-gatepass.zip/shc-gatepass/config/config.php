<?php
/**
 * Application configuration.
 * Sacred Heart College (Autonomous) - Smart Student Movement & Gate Pass System
 */

// ---------------------------------------------------------------- database
// Defaults match a stock XAMPP / WAMP install. Set the SHC_DB_* environment
// variables instead of editing this file when deploying to a real server.
define('DB_HOST', getenv('SHC_DB_HOST') ?: '127.0.0.1');
define('DB_NAME', getenv('SHC_DB_NAME') ?: 'shc_gatepass');
define('DB_USER', getenv('SHC_DB_USER') ?: 'root');
define('DB_PASS', getenv('SHC_DB_PASS') !== false ? getenv('SHC_DB_PASS') : '');
define('DB_CHARSET', 'utf8mb4');

// ---------------------------------------------------------------- app
define('APP_NAME', 'Smart Student Movement & Gate Pass System');
define('COLLEGE_NAME', 'SACRED HEART COLLEGE (Autonomous)');
define('COLLEGE_ADDRESS', 'Tirupattur - 635 601, Tirupattur Dist., Tamil Nadu, India');
define('COLLEGE_ACCRED', "Accredited by NAAC (5th cycle \xe2\x80\x93 under RAF) with a CGPA of 3.53/4 at 'A++' Grade");
define('COLLEGE_UNIV', 'Affiliated to Thiruvalluvar University');

// Base URL path. '' when the app is the document root, '/shc-gatepass' under htdocs.
define('BASE_URL', rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/'));

define('ROOT_PATH', dirname(__DIR__));
define('UPLOAD_PATH', ROOT_PATH . '/uploads');
define('LOG_PATH', ROOT_PATH . '/logs');

// ---------------------------------------------------------------- security
// Change this in production; it signs every QR verification token.
define('APP_SECRET', getenv('SHC_SECRET') ?: 'shc-tirupattur-movement-pass-2026-change-me');
define('SESSION_LIFETIME', 3600);       // auto logout after 60 idle minutes
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_MINUTES', 15);

// ---------------------------------------------------------------- pass rules
define('MIN_VALIDITY', 45);             // minutes
define('MAX_VALIDITY', 120);            // minutes
define('CLASS_HOURS', 6);

date_default_timezone_set('Asia/Kolkata');

// Errors go to the log file, never to the browser.
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', LOG_PATH . '/php-error.log');
error_reporting(E_ALL);

const REASONS = [
    'doctor'     => 'To meet doctor',
    'medicine'   => 'To buy medicine',
    'dept_work'  => 'Department related work',
    'library'    => 'Library',
    'bank_atm'   => 'Bank / ATM',
    'placement'  => 'Placement / Internship',
    'emergency'  => 'Personal emergency',
    'exam_cell'  => 'Exam cell / Office work',
    'other'      => 'Any other (specify)',
];

const STATUS_LABELS = [
    'approved'    => 'Approved',
    'left_campus' => 'Left campus',
    'returned'    => 'Returned',
    'expired'     => 'Expired',
    'revoked'     => 'Revoked',
];
