-- =====================================================================
--  Sacred Heart College (Autonomous), Tirupattur
--  Smart Student Movement & Digital Gate Pass Management System
--  Database Schema  |  MySQL 8 / MariaDB 10.4+  |  InnoDB, utf8mb4
-- =====================================================================

CREATE DATABASE IF NOT EXISTS shc_gatepass
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shc_gatepass;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS pass_events, notifications, gate_passes, staff_courses,
  students, staff, watchmen, admins, courses, programmes, departments,
  login_logs, activity_logs, settings;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------- master
CREATE TABLE departments (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  code        VARCHAR(12)  NOT NULL UNIQUE,
  name        VARCHAR(120) NOT NULL,
  is_active   TINYINT(1)   NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- A programme is a concrete class section: "I BCA - Shift II"
CREATE TABLE programmes (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  dept_id       INT NOT NULL,
  name          VARCHAR(80) NOT NULL,          -- I BCA
  study_year    TINYINT     NOT NULL,          -- 1 | 2 | 3
  shift         ENUM('I','II') NOT NULL,
  section       VARCHAR(4)  DEFAULT NULL,      -- A | B
  is_active     TINYINT(1)  NOT NULL DEFAULT 1,
  UNIQUE KEY uq_prog (dept_id, name, shift, section),
  CONSTRAINT fk_prog_dept FOREIGN KEY (dept_id) REFERENCES departments(id)
) ENGINE=InnoDB;

CREATE TABLE courses (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  code      VARCHAR(20)  NOT NULL UNIQUE,      -- CAPU102T
  title     VARCHAR(160) NOT NULL,
  dept_id   INT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT fk_course_dept FOREIGN KEY (dept_id) REFERENCES departments(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- people
CREATE TABLE staff (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  staff_code    VARCHAR(20)  NOT NULL UNIQUE,  -- T261002
  name          VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  dept_id       INT NOT NULL,
  role          ENUM('staff','hod') NOT NULL DEFAULT 'staff',
  designation   VARCHAR(80)  DEFAULT NULL,
  email         VARCHAR(120) DEFAULT NULL,
  phone         VARCHAR(20)  DEFAULT NULL,
  photo         VARCHAR(255) DEFAULT NULL,
  is_active     TINYINT(1)   NOT NULL DEFAULT 1,
  last_login    DATETIME     DEFAULT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_staff_dept FOREIGN KEY (dept_id) REFERENCES departments(id)
) ENGINE=InnoDB;

-- Which staff member handles which course for which class section
CREATE TABLE staff_courses (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  staff_id      INT NOT NULL,
  course_id     INT NOT NULL,
  programme_id  INT NOT NULL,
  UNIQUE KEY uq_handling (staff_id, course_id, programme_id),
  CONSTRAINT fk_sc_staff  FOREIGN KEY (staff_id)     REFERENCES staff(id)      ON DELETE CASCADE,
  CONSTRAINT fk_sc_course FOREIGN KEY (course_id)    REFERENCES courses(id)    ON DELETE CASCADE,
  CONSTRAINT fk_sc_prog   FOREIGN KEY (programme_id) REFERENCES programmes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE students (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  register_no    VARCHAR(20)  NOT NULL UNIQUE,   -- BU2610A01
  name           VARCHAR(120) NOT NULL,
  dob            DATE         NOT NULL,          -- doubles as the login secret
  dept_id        INT NOT NULL,
  programme_id   INT NOT NULL,
  roll_index     SMALLINT     DEFAULT NULL,      -- position in the roster
  gender         ENUM('M','F','O') DEFAULT NULL,
  phone          VARCHAR(20)  DEFAULT NULL,
  parent_phone   VARCHAR(20)  DEFAULT NULL,
  email          VARCHAR(120) DEFAULT NULL,
  blood_group    VARCHAR(6)   DEFAULT NULL,
  residence      ENUM('Hosteller','Day Scholar') DEFAULT 'Day Scholar',
  photo          VARCHAR(255) DEFAULT NULL,
  is_active      TINYINT(1)   NOT NULL DEFAULT 1,
  last_login     DATETIME     DEFAULT NULL,
  created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_stu_prog (programme_id),
  CONSTRAINT fk_stu_dept FOREIGN KEY (dept_id)      REFERENCES departments(id),
  CONSTRAINT fk_stu_prog FOREIGN KEY (programme_id) REFERENCES programmes(id)
) ENGINE=InnoDB;

CREATE TABLE watchmen (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(40)  NOT NULL UNIQUE,
  name          VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  gate          VARCHAR(60)  NOT NULL DEFAULT 'Main Gate',
  phone         VARCHAR(20)  DEFAULT NULL,
  is_active     TINYINT(1)   NOT NULL DEFAULT 1,
  last_login    DATETIME     DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE admins (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(40)  NOT NULL UNIQUE,
  name          VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  email         VARCHAR(120) DEFAULT NULL,
  is_active     TINYINT(1)   NOT NULL DEFAULT 1,
  last_login    DATETIME     DEFAULT NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- passes
CREATE TABLE gate_passes (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  pass_uid        VARCHAR(24)  NOT NULL UNIQUE,  -- SHC-20260813-0007
  verify_token    CHAR(40)     NOT NULL UNIQUE,  -- signed value carried in the QR
  student_id      INT NOT NULL,
  staff_id        INT NOT NULL,                  -- approving faculty
  course_id       INT DEFAULT NULL,
  programme_id    INT NOT NULL,
  dept_id         INT NOT NULL,                  -- denormalised for fast counters
  hours           VARCHAR(20) DEFAULT NULL,      -- "2,3"
  reason_code     VARCHAR(40)  NOT NULL,
  reason_other    VARCHAR(255) DEFAULT NULL,
  destination     VARCHAR(160) DEFAULT NULL,
  out_time        DATETIME NOT NULL,
  validity_mins   SMALLINT NOT NULL,             -- 45..120
  expiry_time     DATETIME NOT NULL,
  status          ENUM('approved','left_campus','returned','expired','revoked')
                  NOT NULL DEFAULT 'approved',
  exit_time       DATETIME DEFAULT NULL,
  return_time     DATETIME DEFAULT NULL,
  exit_gate_id    INT DEFAULT NULL,
  return_gate_id  INT DEFAULT NULL,
  revoked_by      INT DEFAULT NULL,
  revoke_reason   VARCHAR(255) DEFAULT NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_status (status),
  KEY idx_dept_status (dept_id, status),
  KEY idx_student (student_id),
  KEY idx_created (created_at),
  CONSTRAINT fk_gp_student FOREIGN KEY (student_id)   REFERENCES students(id),
  CONSTRAINT fk_gp_staff   FOREIGN KEY (staff_id)     REFERENCES staff(id),
  CONSTRAINT fk_gp_course  FOREIGN KEY (course_id)    REFERENCES courses(id),
  CONSTRAINT fk_gp_prog    FOREIGN KEY (programme_id) REFERENCES programmes(id),
  CONSTRAINT fk_gp_dept    FOREIGN KEY (dept_id)      REFERENCES departments(id)
) ENGINE=InnoDB;

-- Immutable audit trail for every pass
CREATE TABLE pass_events (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  pass_id     INT NOT NULL,
  event       VARCHAR(40) NOT NULL,       -- issued | scanned | exit | return | expired | revoked
  actor_type  ENUM('student','staff','watchman','admin','system') NOT NULL,
  actor_id    INT DEFAULT NULL,
  actor_name  VARCHAR(120) DEFAULT NULL,
  note        VARCHAR(255) DEFAULT NULL,
  ip_address  VARCHAR(45)  DEFAULT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_pe_pass (pass_id),
  CONSTRAINT fk_pe_pass FOREIGN KEY (pass_id) REFERENCES gate_passes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------- notify + logging
CREATE TABLE notifications (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  recipient_type  ENUM('student','staff','watchman','admin') NOT NULL,
  recipient_id    INT NOT NULL,             -- 0 = broadcast to every user of that type
  pass_id         INT DEFAULT NULL,
  icon            VARCHAR(40) DEFAULT 'bell',
  title           VARCHAR(140) NOT NULL,
  body            VARCHAR(255) DEFAULT NULL,
  link            VARCHAR(160) DEFAULT NULL,
  is_read         TINYINT(1) NOT NULL DEFAULT 0,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_inbox (recipient_type, recipient_id, is_read),
  CONSTRAINT fk_nt_pass FOREIGN KEY (pass_id) REFERENCES gate_passes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE login_logs (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_type   VARCHAR(20) NOT NULL,
  identifier  VARCHAR(60) NOT NULL,
  user_id     INT DEFAULT NULL,
  success     TINYINT(1) NOT NULL,
  ip_address  VARCHAR(45) DEFAULT NULL,
  user_agent  VARCHAR(255) DEFAULT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ll_ident (identifier, created_at)
) ENGINE=InnoDB;

CREATE TABLE activity_logs (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  actor_type  VARCHAR(20) NOT NULL,
  actor_id    INT DEFAULT NULL,
  actor_name  VARCHAR(120) DEFAULT NULL,
  action      VARCHAR(60)  NOT NULL,
  entity      VARCHAR(40)  DEFAULT NULL,
  entity_id   INT DEFAULT NULL,
  detail      VARCHAR(255) DEFAULT NULL,
  ip_address  VARCHAR(45)  DEFAULT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_al_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE settings (
  skey   VARCHAR(60) PRIMARY KEY,
  svalue VARCHAR(255) NOT NULL
) ENGINE=InnoDB;
