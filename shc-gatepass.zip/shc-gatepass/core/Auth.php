<?php
/**
 * Session-based authentication and role gate for all four user types.
 */
final class Auth
{
    /** Table + identifier column for each role. */
    private const SOURCES = [
        'student'  => ['students', 'register_no'],
        'staff'    => ['staff',    'staff_code'],
        'watchman' => ['watchmen', 'username'],
        'admin'    => ['admins',   'username'],
    ];

    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) return;

        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            'secure'   => !empty($_SERVER['HTTPS']),
        ]);
        session_name('SHCPASS');
        session_start();

        // Idle timeout
        if (!empty($_SESSION['last_seen']) && time() - $_SESSION['last_seen'] > SESSION_LIFETIME) {
            self::logout('timeout');
        }
        $_SESSION['last_seen'] = time();
    }

    public static function check(): bool
    {
        return !empty($_SESSION['user']['id']) && !empty($_SESSION['user']['type']);
    }

    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function id(): int
    {
        return (int)($_SESSION['user']['id'] ?? 0);
    }

    public static function type(): string
    {
        return $_SESSION['user']['type'] ?? '';
    }

    public static function isHod(): bool
    {
        return self::type() === 'staff' && ($_SESSION['user']['role'] ?? '') === 'hod';
    }

    /** Stop the request unless the visitor holds one of the given roles. */
    public static function require(string ...$types): void
    {
        if (!self::check()) {
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
                json_out(['ok' => false, 'message' => 'Your session ended. Sign in again.'], 401);
            }
            flash('warning', 'Sign in to continue.');
            redirect('login');
        }
        if ($types && !in_array(self::type(), $types, true)) {
            http_response_code(403);
            exit('You do not have access to this page.');
        }
    }

    /** Home dashboard for a role. */
    public static function home(?string $type = null): string
    {
        return match ($type ?? self::type()) {
            'student'  => 'student/dashboard',
            'staff'    => 'staff/dashboard',
            'watchman' => 'security/dashboard',
            'admin'    => 'admin/dashboard',
            default    => 'login',
        };
    }

    /**
     * Verify credentials for a role.
     * Students authenticate with register number + date of birth; everyone
     * else with a username + password.
     * Returns [ok, user|message].
     */
    public static function attempt(string $type, string $identifier, string $secret): array
    {
        if (!isset(self::SOURCES[$type])) {
            return [false, 'Unknown login type.'];
        }
        $identifier = trim($identifier);

        if (self::isLockedOut($identifier)) {
            return [false, 'Too many failed attempts. Try again in ' . LOCKOUT_MINUTES . ' minutes.'];
        }

        [$table, $column] = self::SOURCES[$type];
        $sql = "SELECT * FROM {$table} WHERE {$column} = ? LIMIT 1";
        $stmt = Database::pdo()->prepare($sql);
        $stmt->execute([$identifier]);
        $row = $stmt->fetch();

        $ok = false;
        if ($row) {
            $ok = $type === 'student'
                ? hash_equals((string)$row['dob'], $secret)          // DOB as YYYY-MM-DD
                : password_verify($secret, (string)$row['password_hash']);
        }

        self::logLogin($type, $identifier, $row['id'] ?? null, $ok);

        if (!$row || !$ok) {
            return [false, 'Those details do not match our records.'];
        }
        if (!(int)$row['is_active']) {
            return [false, 'This account is deactivated. Contact the office.'];
        }

        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id'      => (int)$row['id'],
            'type'    => $type,
            'name'    => $row['name'],
            'ident'   => $row[$column],
            'role'    => $row['role'] ?? $type,
            'dept_id' => isset($row['dept_id']) ? (int)$row['dept_id'] : null,
            'gate'    => $row['gate'] ?? null,
            'photo'   => $row['photo'] ?? null,
        ];
        $_SESSION['last_seen'] = time();

        Database::pdo()->prepare("UPDATE {$table} SET last_login = NOW() WHERE id = ?")
                       ->execute([$row['id']]);
        Logger::activity($type, (int)$row['id'], $row['name'], 'login', $table, (int)$row['id']);

        return [true, $_SESSION['user']];
    }

    public static function logout(string $reason = 'manual'): never
    {
        if (self::check()) {
            $u = self::user();
            Logger::activity($u['type'], (int)$u['id'], $u['name'], 'logout', null, null, $reason);
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            setcookie(session_name(), '', time() - 42000, '/');
        }
        session_destroy();
        session_start();
        if ($reason === 'timeout') {
            flash('warning', 'You were signed out after 60 minutes of inactivity.');
        }
        redirect('login');
    }

    private static function logLogin(string $type, string $ident, ?int $uid, bool $ok): void
    {
        Database::pdo()->prepare(
            'INSERT INTO login_logs (user_type, identifier, user_id, success, ip_address, user_agent)
             VALUES (?,?,?,?,?,?)'
        )->execute([$type, $ident, $uid, (int)$ok, client_ip(),
                    substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)]);
    }

    private static function isLockedOut(string $ident): bool
    {
        $stmt = Database::pdo()->prepare(
            'SELECT COUNT(*) FROM login_logs
             WHERE identifier = ? AND success = 0 AND created_at > (NOW() - INTERVAL ? MINUTE)'
        );
        $stmt->execute([$ident, LOCKOUT_MINUTES]);
        return (int)$stmt->fetchColumn() >= MAX_LOGIN_ATTEMPTS;
    }
}
