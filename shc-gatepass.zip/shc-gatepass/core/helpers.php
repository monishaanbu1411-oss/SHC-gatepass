<?php
/** Small helpers used across views and controllers. */

/** Escape for HTML output. Every dynamic value in a view goes through this. */
function e(?string $v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Build an absolute app URL. */
function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

function json_out(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function post(string $key, $default = null)
{
    return $_POST[$key] ?? $default;
}

function get(string $key, $default = null)
{
    return $_GET[$key] ?? $default;
}

function client_ip(): string
{
    return substr($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45);
}

/** "13 Aug 2026, 02:45 PM" */
function fmt_dt(?string $dt): string
{
    return $dt ? date('d M Y, h:i A', strtotime($dt)) : '-';
}

function fmt_time(?string $dt): string
{
    return $dt ? date('h:i A', strtotime($dt)) : '-';
}

function fmt_date(?string $dt): string
{
    return $dt ? date('d/m/Y', strtotime($dt)) : '-';
}

/** "1 h 20 m" from a minute count. */
function fmt_mins(int $m): string
{
    if ($m < 60) return $m . ' min';
    $h = intdiv($m, 60);
    $r = $m % 60;
    return $r ? "{$h} h {$r} m" : "{$h} h";
}

/** Human label for a reason code. */
function reason_label(string $code, ?string $other = null): string
{
    if ($code === 'other') return $other ?: 'Any other';
    return REASONS[$code] ?? ucfirst(str_replace('_', ' ', $code));
}

/** Bootstrap badge class for a pass status. */
function status_class(string $status): string
{
    return match ($status) {
        'approved'    => 'st-approved',
        'left_campus' => 'st-out',
        'returned'    => 'st-returned',
        'expired'     => 'st-expired',
        'revoked'     => 'st-revoked',
        default       => 'st-approved',
    };
}

function status_label(string $status): string
{
    return STATUS_LABELS[$status] ?? ucfirst($status);
}

/** Initials fallback when a student has no photo on file. */
function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name));
    $out = strtoupper(substr($parts[0] ?? 'S', 0, 1));
    if (count($parts) > 1) $out .= strtoupper(substr(end($parts), 0, 1));
    return $out;
}

/** Photo URL for a student row, or null when none is uploaded. */
function photo_url(?string $photo): ?string
{
    if (!$photo) return null;
    return url('uploads/photos/' . $photo);
}

/** Flash messages survive exactly one redirect. */
function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function take_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

/** Marks the nav item for the current route. */
function nav_active(string $route): string
{
    $current = trim($_GET['url'] ?? '', '/');
    return str_starts_with($current, trim($route, '/')) ? ' active' : '';
}
