<?php
/**
 * Self-contained Code 128-B barcode renderer (SVG output, no external library).
 * Pattern table follows the Code 128 specification: each value maps to 11
 * modules, 1 = bar, 0 = space.
 */
final class Barcode
{
    /** Values 0-105. Index = code value, Code B character = chr(value + 32). */
    private const PATTERNS = [
        '11011001100', '11001101100', '11001100110', '10010011000', '10010001100', '10001001100',
        '10011001000', '10011000100', '10001100100', '11001001000', '11001000100', '11000100100',
        '10110011100', '10011011100', '10011001110', '10111001100', '10011101100', '10011100110',
        '11001110010', '11001011100', '11001001110', '11011100100', '11001110100', '11101101110',
        '11101001100', '11100101100', '11100100110', '11101100100', '11100110100', '11100110010',
        '11011011000', '11011000110', '11000110110', '10100011000', '10001011000', '10001000110',
        '10110001000', '10001101000', '10001100010', '11010001000', '11000101000', '11000100010',
        '10110111000', '10110001110', '10001101110', '10111011000', '10111000110', '10001110110',
        '11101110110', '11010001110', '11000101110', '11011101000', '11011100010', '11011101110',
        '11101011000', '11101000110', '11100010110', '11101101000', '11101100010', '11100011010',
        '11101111010', '11001000010', '11110001010', '10100110000', '10100001100', '10010110000',
        '10010000110', '10000101100', '10000100110', '10110010000', '10110000100', '10011010000',
        '10011000010', '10000110100', '10000110010', '11000010010', '11001010000', '11110111010',
        '11000010100', '10001111010', '10100111100', '10010111100', '10010011110', '10111100100',
        '10011110100', '10011110010', '11110100100', '11110010100', '11110010010', '11011011110',
        '11011110110', '11110110110', '10101111000', '10100011110', '10001011110', '10111101000',
        '10111100010', '11110101000', '11110100010', '10111011110', '10111101110', '11101011110',
        '11110101110', '11010000100', '11010010000', '11010011100'
    ];
    private const STOP     = '1100011101011';   // stop + 2 termination bars
    private const START_B  = 104;

    /**
     * Render $text as a Code 128-B barcode.
     *
     * @param int $moduleWidth pixel width of one module
     * @param int $height      bar height in pixels
     */
    public static function svg(string $text, int $moduleWidth = 2, int $height = 60, bool $showText = true): string
    {
        $text = preg_replace('/[^\x20-\x7E]/', '', $text);
        if ($text === '') $text = '0';

        $values = [self::START_B];
        $len = strlen($text);
        for ($i = 0; $i < $len; $i++) {
            $values[] = ord($text[$i]) - 32;
        }

        // Weighted modulo-103 checksum
        $sum = self::START_B;
        for ($i = 1; $i < count($values); $i++) {
            $sum += $values[$i] * $i;
        }
        $values[] = $sum % 103;

        $bits = '';
        foreach ($values as $v) {
            $bits .= self::PATTERNS[$v];
        }
        $bits .= self::STOP;

        $quiet  = 10 * $moduleWidth;
        $width  = (strlen($bits) * $moduleWidth) + (2 * $quiet);
        $textH  = $showText ? 18 : 0;
        $total  = $height + $textH;

        $bars = '';
        $n = strlen($bits);
        $i = 0;
        while ($i < $n) {
            if ($bits[$i] === '1') {
                $run = 1;
                while ($i + $run < $n && $bits[$i + $run] === '1') $run++;
                $x = $quiet + ($i * $moduleWidth);
                $bars .= sprintf('<rect x="%d" y="0" width="%d" height="%d"/>', $x, $run * $moduleWidth, $height);
                $i += $run;
            } else {
                $i++;
            }
        }

        $label = '';
        if ($showText) {
            $label = sprintf(
                '<text x="%d" y="%d" text-anchor="middle" font-family="monospace" font-size="13" letter-spacing="2" fill="currentColor">%s</text>',
                intdiv($width, 2), $total - 4, htmlspecialchars($text, ENT_QUOTES)
            );
        }

        return sprintf(
            '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" role="img" aria-label="Barcode %s"><g fill="currentColor">%s</g>%s</svg>',
            $width, $total, $width, $total, htmlspecialchars($text, ENT_QUOTES), $bars, $label
        );
    }
}
