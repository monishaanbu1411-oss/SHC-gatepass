<?php
/**
 * Front-controller router.  URLs look like  /role/action/param
 * e.g. /staff/issue, /security/verify/SHC-20260813-0007, /api/notifications
 */
final class Router
{
    private const MAP = [
        ''         => ['AuthController', 'index'],
        'login'    => ['AuthController', 'login'],
        'logout'   => ['AuthController', 'logout'],
        'student'  => ['StudentController', null],
        'staff'    => ['StaffController', null],
        'security' => ['SecurityController', null],
        'admin'    => ['AdminController', null],
        'api'      => ['ApiController', null],
        'pass'     => ['PassController', null],
    ];

    public function dispatch(string $url): void
    {
        $parts  = array_values(array_filter(explode('/', trim($url, '/')), 'strlen'));
        $key    = $parts[0] ?? '';
        $action = $parts[1] ?? 'index';
        $args   = array_slice($parts, 2);

        if (!isset(self::MAP[$key])) {
            $this->notFound();
        }

        [$controller, $fixedAction] = self::MAP[$key];
        if ($fixedAction !== null) {
            $action = $fixedAction;
            $args   = array_slice($parts, 1);
        }

        $file = ROOT_PATH . '/controllers/' . $controller . '.php';
        if (!is_file($file)) {
            $this->notFound();
        }
        require_once $file;

        $method = str_replace('-', '_', $action);
        $obj = new $controller();
        if (!method_exists($obj, $method) || !is_callable([$obj, $method])) {
            $this->notFound();
        }
        $obj->$method(...$args);
    }

    private function notFound(): never
    {
        http_response_code(404);
        require ROOT_PATH . '/views/errors/404.php';
        exit;
    }
}
