<?php
/** Thin base model: shared PDO helpers, always parameter-bound. */
abstract class Model
{
    protected PDO $db;

    public function __construct()
    {
        $this->db = Database::pdo();
    }

    protected function all(string $sql, array $args = []): array
    {
        $st = $this->db->prepare($sql);
        $st->execute($args);
        return $st->fetchAll();
    }

    protected function one(string $sql, array $args = []): ?array
    {
        $st = $this->db->prepare($sql);
        $st->execute($args);
        return $st->fetch() ?: null;
    }

    protected function scalar(string $sql, array $args = [])
    {
        $st = $this->db->prepare($sql);
        $st->execute($args);
        return $st->fetchColumn();
    }

    protected function run(string $sql, array $args = []): int
    {
        $st = $this->db->prepare($sql);
        $st->execute($args);
        return $st->rowCount();
    }

    protected function insert(string $sql, array $args = []): int
    {
        $this->db->prepare($sql)->execute($args);
        return (int)$this->db->lastInsertId();
    }
}
