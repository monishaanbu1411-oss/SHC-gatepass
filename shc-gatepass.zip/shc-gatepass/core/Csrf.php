<?php
/** Per-session CSRF token. Every POST is checked against it. */
final class Csrf
{
    public static function token(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function field(): string
    {
        return '<input type="hidden" name="csrf_token" value="' . self::token() . '">';
    }

    public static function check(): void
    {
        $sent = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!hash_equals(self::token(), (string)$sent)) {
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
                json_out(['ok' => false, 'message' => 'Your session expired. Reload the page and try again.'], 419);
            }
            http_response_code(419);
            exit('Security check failed. Go back, reload the page and try again.');
        }
    }
}
