<?php
/** Writes the audit trail: activity log rows plus per-pass events. */
final class Logger
{
    public static function activity(
        string $actorType, ?int $actorId, ?string $actorName, string $action,
        ?string $entity = null, ?int $entityId = null, ?string $detail = null
    ): void {
        Database::pdo()->prepare(
            'INSERT INTO activity_logs
             (actor_type, actor_id, actor_name, action, entity, entity_id, detail, ip_address)
             VALUES (?,?,?,?,?,?,?,?)'
        )->execute([$actorType, $actorId, $actorName, $action, $entity, $entityId,
                    $detail ? substr($detail, 0, 255) : null, client_ip()]);
    }

    public static function passEvent(
        int $passId, string $event, string $actorType,
        ?int $actorId = null, ?string $actorName = null, ?string $note = null
    ): void {
        Database::pdo()->prepare(
            'INSERT INTO pass_events (pass_id, event, actor_type, actor_id, actor_name, note, ip_address)
             VALUES (?,?,?,?,?,?,?)'
        )->execute([$passId, $event, $actorType, $actorId, $actorName, $note, client_ip()]);
    }
}
