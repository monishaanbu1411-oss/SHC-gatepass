<?php
/** Base controller: view rendering and model loading. */
abstract class Controller
{
    /** Render a view inside the shared chrome (or bare, for print pages). */
    protected function render(string $path, array $data = [], ?string $layout = 'app'): void
    {
        $file = ROOT_PATH . '/views/' . $path . '.php';
        if (!is_file($file)) {
            http_response_code(500);
            exit("View not found: {$path}");
        }
        extract($data, EXTR_SKIP);
        $flashes = take_flashes();

        if ($layout === null) {           // bare page (printable pass, scan screens)
            require $file;
            return;
        }

        $pageTitle = $data['title'] ?? APP_NAME;
        require ROOT_PATH . '/views/layouts/head.php';
        require ROOT_PATH . '/views/layouts/sidebar.php';
        require $file;
        require ROOT_PATH . '/views/layouts/foot.php';
    }

    protected function model(string $name)
    {
        $file = ROOT_PATH . '/models/' . $name . '.php';
        require_once $file;
        return new $name();
    }

    /** Reject anything that is not a POST. */
    protected function postOnly(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            json_out(['ok' => false, 'message' => 'Invalid request method.'], 405);
        }
        Csrf::check();
    }
}
