<?php
/** Reference data: departments, class sections, courses, staff course load. */
class LookupModel extends Model
{
    public function departments(): array
    {
        return $this->all('SELECT * FROM departments WHERE is_active = 1 ORDER BY name');
    }

    public function programmes(): array
    {
        return $this->all(
            'SELECT p.*, d.name AS dept_name, d.code AS dept_code
             FROM programmes p JOIN departments d ON d.id = p.dept_id
             WHERE p.is_active = 1 ORDER BY d.name, p.study_year, p.shift'
        );
    }

    public function programme(int $id): ?array
    {
        return $this->one(
            'SELECT p.*, d.name AS dept_name, d.code AS dept_code
             FROM programmes p JOIN departments d ON d.id = p.dept_id WHERE p.id = ?', [$id]
        );
    }

    /** "I BCA - Shift II" */
    public static function progLabel(array $p): string
    {
        $label = $p['name'] . ' - Shift ' . $p['shift'];
        if (!empty($p['section'])) $label .= ' (Sec ' . $p['section'] . ')';
        return $label;
    }

    /** Courses the logged-in staff member actually teaches. */
    public function coursesForStaff(int $staffId): array
    {
        return $this->all(
            'SELECT DISTINCT c.id, c.code, c.title
             FROM staff_courses sc JOIN courses c ON c.id = sc.course_id
             WHERE sc.staff_id = ? AND c.is_active = 1
             ORDER BY c.code', [$staffId]
        );
    }

    /** Class sections this staff member takes for a given course. */
    public function programmesForStaffCourse(int $staffId, int $courseId): array
    {
        return $this->all(
            'SELECT p.*, d.name AS dept_name
             FROM staff_courses sc
             JOIN programmes p ON p.id = sc.programme_id
             JOIN departments d ON d.id = p.dept_id
             WHERE sc.staff_id = ? AND sc.course_id = ?
             ORDER BY p.study_year, p.shift', [$staffId, $courseId]
        );
    }

    /** Guard: does this staff member really handle this course + section? */
    public function staffHandles(int $staffId, int $courseId, int $programmeId): bool
    {
        return (bool)$this->scalar(
            'SELECT 1 FROM staff_courses WHERE staff_id = ? AND course_id = ? AND programme_id = ?',
            [$staffId, $courseId, $programmeId]
        );
    }

    public function course(int $id): ?array
    {
        return $this->one('SELECT * FROM courses WHERE id = ?', [$id]);
    }

    public function allCourses(): array
    {
        return $this->all(
            'SELECT c.*, d.name AS dept_name FROM courses c
             JOIN departments d ON d.id = c.dept_id ORDER BY c.code'
        );
    }

    public function setting(string $key, string $default = ''): string
    {
        $v = $this->scalar('SELECT svalue FROM settings WHERE skey = ?', [$key]);
        return $v === false ? $default : (string)$v;
    }
}
