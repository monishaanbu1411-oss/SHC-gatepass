<?php
/** Read-side of the audit trail for the admin log screens. */
class LogModel extends Model
{
    public function activity(int $limit = 200, string $q = ''): array
    {
        $sql = 'SELECT * FROM activity_logs WHERE 1=1';
        $args = [];
        if ($q !== '') {
            $sql .= ' AND (actor_name LIKE ? OR action LIKE ? OR detail LIKE ?)';
            $args = ["%$q%", "%$q%", "%$q%"];
        }
        return $this->all($sql . ' ORDER BY id DESC LIMIT ' . (int)$limit, $args);
    }

    public function logins(int $limit = 200): array
    {
        return $this->all('SELECT * FROM login_logs ORDER BY id DESC LIMIT ' . (int)$limit);
    }

    public function scans(int $limit = 200): array
    {
        return $this->all(
            "SELECT pe.*, gp.pass_uid, s.name AS student_name, s.register_no
             FROM pass_events pe
             JOIN gate_passes gp ON gp.id = pe.pass_id
             JOIN students s ON s.id = gp.student_id
             WHERE pe.event IN ('exit','return','scanned','revoked')
             ORDER BY pe.id DESC LIMIT " . (int)$limit
        );
    }

    public function failedLogins(int $limit = 100): array
    {
        return $this->all(
            'SELECT * FROM login_logs WHERE success = 0 ORDER BY id DESC LIMIT ' . (int)$limit
        );
    }
}
