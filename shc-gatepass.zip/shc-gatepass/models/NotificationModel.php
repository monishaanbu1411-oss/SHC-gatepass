<?php
/** In-app notifications, polled over AJAX by every dashboard. */
class NotificationModel extends Model
{
    public function push(string $type, int $recipientId, string $title,
                         ?string $body = null, ?int $passId = null,
                         ?string $link = null, string $icon = 'bell'): int
    {
        return $this->insert(
            'INSERT INTO notifications (recipient_type, recipient_id, pass_id, icon, title, body, link)
             VALUES (?,?,?,?,?,?,?)',
            [$type, $recipientId, $passId, $icon, $title, $body, $link]
        );
    }

    /** recipient_id 0 means "every user of this type", used for the gate feed. */
    public function inbox(string $type, int $id, int $limit = 30): array
    {
        return $this->all(
            'SELECT * FROM notifications
             WHERE recipient_type = ? AND recipient_id IN (0, ?)
             ORDER BY created_at DESC, id DESC LIMIT ' . (int)$limit, [$type, $id]
        );
    }

    public function unreadCount(string $type, int $id): int
    {
        return (int)$this->scalar(
            'SELECT COUNT(*) FROM notifications
             WHERE recipient_type = ? AND recipient_id IN (0, ?) AND is_read = 0', [$type, $id]
        );
    }

    /** Anything newer than the id the browser last saw. */
    public function since(string $type, int $id, int $lastId): array
    {
        return $this->all(
            'SELECT * FROM notifications
             WHERE recipient_type = ? AND recipient_id IN (0, ?) AND id > ?
             ORDER BY id ASC LIMIT 20', [$type, $id, $lastId]
        );
    }

    public function markRead(string $type, int $id, ?int $notifId = null): int
    {
        if ($notifId) {
            return $this->run(
                'UPDATE notifications SET is_read = 1
                 WHERE id = ? AND recipient_type = ? AND recipient_id IN (0, ?)',
                [$notifId, $type, $id]
            );
        }
        return $this->run(
            'UPDATE notifications SET is_read = 1
             WHERE recipient_type = ? AND recipient_id IN (0, ?) AND is_read = 0', [$type, $id]
        );
    }

    /**
     * Fan out the alerts that follow an approval: the student, the department
     * HOD and every watchman on duty are told at the same moment.
     */
    public function announceIssue(array $pass, array $staff): void
    {
        $when = date('h:i A', strtotime($pass['out_time']));
        $till = date('h:i A', strtotime($pass['expiry_time']));
        $reason = reason_label($pass['reason_code'], $pass['reason_other']);

        // Student
        $this->push('student', (int)$pass['student_id'],
            'Your movement pass is approved',
            "{$staff['name']} approved your pass - {$reason}. Valid {$when} to {$till}.",
            (int)$pass['id'], 'student/passes', 'check');

        // HOD of the student's department (skip if the HOD issued it)
        $hods = $this->all(
            "SELECT id FROM staff WHERE dept_id = ? AND role = 'hod' AND is_active = 1",
            [$pass['dept_id']]
        );
        foreach ($hods as $h) {
            if ((int)$h['id'] === (int)$pass['staff_id']) continue;
            $this->push('staff', (int)$h['id'],
                'Student leaving campus',
                "{$pass['student_name']} ({$pass['register_no']}) - {$reason}. Approved by {$staff['name']}.",
                (int)$pass['id'], 'staff/monitor', 'walk');
        }

        // Every watchman
        $this->push('watchman', 0,
            'New pass at the gate',
            "{$pass['student_name']} - {$pass['register_no']} - {$pass['dept_code']} - valid till {$till}.",
            (int)$pass['id'], 'security/pass/' . $pass['pass_uid'], 'gate');
    }

    /** Gate scanned the student out. */
    public function announceExit(array $pass, string $guard): void
    {
        $t = date('h:i A', strtotime($pass['exit_time'] ?: 'now'));
        $this->push('student', (int)$pass['student_id'], 'Exit recorded',
            "You left the campus at {$t}. Return before " . date('h:i A', strtotime($pass['expiry_time'])) . '.',
            (int)$pass['id'], 'student/passes', 'out');
        $this->push('staff', (int)$pass['staff_id'], 'Student left the campus',
            "{$pass['student_name']} ({$pass['register_no']}) exited at {$t}.",
            (int)$pass['id'], 'staff/monitor', 'out');
        $this->push('admin', 0, 'Student left the campus',
            "{$pass['student_name']} - {$pass['dept_code']} - {$t} - gate: {$guard}.",
            (int)$pass['id'], 'admin/dashboard', 'out');
    }

    /** Gate scanned the student back in. */
    public function announceReturn(array $pass, string $guard, bool $late): void
    {
        $t = date('h:i A', strtotime($pass['return_time'] ?: 'now'));
        $tag = $late ? ' (after the return time)' : '';
        $this->push('student', (int)$pass['student_id'], 'Welcome back',
            "Your return was recorded at {$t}{$tag}.", (int)$pass['id'], 'student/history', 'in');
        $this->push('staff', (int)$pass['staff_id'], 'Student returned safely',
            "{$pass['student_name']} ({$pass['register_no']}) returned at {$t}{$tag}.",
            (int)$pass['id'], 'staff/monitor', 'in');
        $this->push('admin', 0, 'Student returned',
            "{$pass['student_name']} - {$pass['dept_code']} - {$t} - gate: {$guard}.",
            (int)$pass['id'], 'admin/dashboard', 'in');
    }

    public function announceRevoke(array $pass, string $adminName, string $reason): void
    {
        $this->push('student', (int)$pass['student_id'], 'Your pass was cancelled',
            "{$adminName} cancelled pass {$pass['pass_uid']}. Reason: {$reason}",
            (int)$pass['id'], 'student/history', 'ban');
        $this->push('staff', (int)$pass['staff_id'], 'Pass cancelled by administration',
            "{$pass['pass_uid']} for {$pass['student_name']} was cancelled. Reason: {$reason}",
            (int)$pass['id'], 'staff/history', 'ban');
        $this->push('watchman', 0, 'Pass cancelled - do not allow exit',
            "{$pass['pass_uid']} - {$pass['student_name']} ({$pass['register_no']}).",
            (int)$pass['id'], 'security/dashboard', 'ban');
    }
}
