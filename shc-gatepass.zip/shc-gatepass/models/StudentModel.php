<?php
/** Student records and class rosters. */
class StudentModel extends Model
{
    private const SELECT = 'SELECT s.*, d.name AS dept_name, d.code AS dept_code,
                p.name AS prog_name, p.shift, p.section, p.study_year
         FROM students s
         JOIN departments d ON d.id = s.dept_id
         JOIN programmes  p ON p.id = s.programme_id';

    public function find(int $id): ?array
    {
        return $this->one(self::SELECT . ' WHERE s.id = ?', [$id]);
    }

    public function findByRegister(string $reg): ?array
    {
        return $this->one(self::SELECT . ' WHERE s.register_no = ?', [$reg]);
    }

    /** The roster for one class section, ordered the way the paper register is. */
    public function roster(int $programmeId): array
    {
        return $this->all(
            'SELECT id, register_no, name, photo, roll_index, gender, is_active
             FROM students WHERE programme_id = ? AND is_active = 1
             ORDER BY roll_index, register_no', [$programmeId]
        );
    }

    /** Only the students that belong to this section - used to validate a submission. */
    public function idsInProgramme(array $ids, int $programmeId): array
    {
        if (!$ids) return [];
        $in = implode(',', array_fill(0, count($ids), '?'));
        $rows = $this->all(
            "SELECT id FROM students WHERE programme_id = ? AND is_active = 1 AND id IN ($in)",
            array_merge([$programmeId], $ids)
        );
        return array_column($rows, 'id');
    }

    public function search(string $q = '', ?int $deptId = null, int $limit = 200): array
    {
        $sql = self::SELECT . ' WHERE 1=1';
        $args = [];
        if ($q !== '') {
            $sql .= ' AND (s.name LIKE ? OR s.register_no LIKE ?)';
            $args[] = "%$q%"; $args[] = "%$q%";
        }
        if ($deptId) { $sql .= ' AND s.dept_id = ?'; $args[] = $deptId; }
        $sql .= ' ORDER BY s.register_no LIMIT ' . (int)$limit;
        return $this->all($sql, $args);
    }

    public function create(array $d): int
    {
        return $this->insert(
            'INSERT INTO students (register_no, name, dob, dept_id, programme_id, roll_index,
                gender, phone, parent_phone, email, blood_group, residence, photo)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [$d['register_no'], $d['name'], $d['dob'], $d['dept_id'], $d['programme_id'],
             $d['roll_index'] ?? null, $d['gender'] ?? null, $d['phone'] ?? null,
             $d['parent_phone'] ?? null, $d['email'] ?? null, $d['blood_group'] ?? null,
             $d['residence'] ?? 'Day Scholar', $d['photo'] ?? null]
        );
    }

    public function update(int $id, array $d): int
    {
        return $this->run(
            'UPDATE students SET name=?, dob=?, dept_id=?, programme_id=?, roll_index=?,
                gender=?, phone=?, parent_phone=?, email=?, blood_group=?, residence=?, is_active=?
             WHERE id=?',
            [$d['name'], $d['dob'], $d['dept_id'], $d['programme_id'], $d['roll_index'] ?? null,
             $d['gender'] ?? null, $d['phone'] ?? null, $d['parent_phone'] ?? null,
             $d['email'] ?? null, $d['blood_group'] ?? null, $d['residence'] ?? 'Day Scholar',
             (int)($d['is_active'] ?? 1), $id]
        );
    }

    public function delete(int $id): int
    {
        return $this->run('UPDATE students SET is_active = 0 WHERE id = ?', [$id]);
    }

    public function countAll(): int
    {
        return (int)$this->scalar('SELECT COUNT(*) FROM students WHERE is_active = 1');
    }
}
