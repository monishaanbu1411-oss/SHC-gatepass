<?php
/**
 * Gate passes: issuing, gate verification, exit / return recording, analytics.
 *
 * Status meanings
 *   approved     issued by faculty, student has not reached the gate yet
 *   left_campus  scanned out at the gate, student is off campus
 *   returned     scanned back in
 *   expired      validity ran out before the student ever left
 *   revoked      cancelled by an administrator
 *
 * A pass that is scanned out and runs past its expiry stays on left_campus and
 * is reported as *overdue*. Losing track of a student who is still off campus
 * would be worse than showing a stale status, so the count of students outside
 * always includes them.
 */
class PassModel extends Model
{
    private const SELECT = "
        SELECT gp.*,
               s.register_no, s.name AS student_name, s.photo AS student_photo,
               s.phone AS student_phone, s.parent_phone, s.blood_group, s.residence,
               st.name AS staff_name, st.staff_code, st.designation,
               d.name AS dept_name, d.code AS dept_code,
               p.name AS prog_name, p.shift, p.section, p.study_year,
               c.code AS course_code, c.title AS course_title,
               TIMESTAMPDIFF(SECOND, NOW(), gp.expiry_time) AS seconds_left,
               (gp.status = 'left_campus' AND gp.expiry_time < NOW()) AS is_overdue
        FROM gate_passes gp
        JOIN students    s  ON s.id  = gp.student_id
        JOIN staff       st ON st.id = gp.staff_id
        JOIN departments d  ON d.id  = gp.dept_id
        JOIN programmes  p  ON p.id  = gp.programme_id
        LEFT JOIN courses c ON c.id  = gp.course_id";

    // ------------------------------------------------------------- issuing

    /**
     * Issue one pass. Returns the new pass id.
     * Caller is responsible for validating that the staff member handles the class.
     */
    public function issue(array $d): int
    {
        $out    = $d['out_time'];
        $mins   = max(MIN_VALIDITY, min(MAX_VALIDITY, (int)$d['validity_mins']));
        $expiry = date('Y-m-d H:i:s', strtotime($out) + ($mins * 60));

        $uid   = $this->nextUid();
        $token = self::makeToken($uid);

        return $this->insert(
            'INSERT INTO gate_passes
               (pass_uid, verify_token, student_id, staff_id, course_id, programme_id, dept_id,
                hours, reason_code, reason_other, destination, out_time, validity_mins, expiry_time)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [$uid, $token, $d['student_id'], $d['staff_id'], $d['course_id'] ?: null,
             $d['programme_id'], $d['dept_id'], $d['hours'] ?? null, $d['reason_code'],
             $d['reason_other'] ?? null, $d['destination'] ?? null, $out, $mins, $expiry]
        );
    }

    /** Sequential, human-readable id: SHC-20260813-0007 */
    private function nextUid(): string
    {
        $day = date('Ymd');
        $n = (int)$this->scalar(
            'SELECT COUNT(*) FROM gate_passes WHERE DATE(created_at) = CURDATE()'
        );
        // Collisions are possible under concurrency, so probe upward.
        do {
            $n++;
            $uid = sprintf('SHC-%s-%04d', $day, $n);
            $taken = $this->scalar('SELECT 1 FROM gate_passes WHERE pass_uid = ?', [$uid]);
        } while ($taken);
        return $uid;
    }

    /** HMAC over the pass id: a QR cannot be forged without APP_SECRET. */
    public static function makeToken(string $uid): string
    {
        return hash_hmac('sha1', $uid . '|' . microtime(true), APP_SECRET);
    }

    /** What the QR image actually encodes. */
    public static function qrPayload(array $pass): string
    {
        return 'SHCPASS:' . $pass['pass_uid'] . ':' . $pass['verify_token'];
    }

    // ------------------------------------------------------------- reading

    public function find(int $id): ?array
    {
        return $this->one(self::SELECT . ' WHERE gp.id = ?', [$id]);
    }

    public function findByUid(string $uid): ?array
    {
        return $this->one(self::SELECT . ' WHERE gp.pass_uid = ?', [$uid]);
    }

    public function findByToken(string $token): ?array
    {
        return $this->one(self::SELECT . ' WHERE gp.verify_token = ?', [$token]);
    }

    /**
     * Resolve whatever the scanner produced: a full QR payload, a bare pass id
     * or a barcode reading.
     */
    public function resolveScan(string $raw): ?array
    {
        $raw = trim($raw);
        if ($raw === '') return null;

        if (str_starts_with($raw, 'SHCPASS:')) {
            $parts = explode(':', $raw);
            $uid   = $parts[1] ?? '';
            $token = $parts[2] ?? '';
            $pass  = $this->findByUid($uid);
            // Both halves must agree, otherwise the code was tampered with.
            if ($pass && hash_equals($pass['verify_token'], $token)) return $pass;
            return null;
        }
        if (preg_match('/^SHC-\d{8}-\d{4}$/', $raw)) {
            return $this->findByUid($raw);
        }
        if (preg_match('/^[a-f0-9]{40}$/i', $raw)) {
            return $this->findByToken($raw);
        }
        return null;
    }

    public function forStudent(int $studentId, ?array $statuses = null, int $limit = 100): array
    {
        $sql = self::SELECT . ' WHERE gp.student_id = ?';
        $args = [$studentId];
        if ($statuses) {
            $sql .= ' AND gp.status IN (' . implode(',', array_fill(0, count($statuses), '?')) . ')';
            $args = array_merge($args, $statuses);
        }
        $sql .= ' ORDER BY gp.created_at DESC LIMIT ' . (int)$limit;
        return $this->all($sql, $args);
    }

    /** Passes a student can still use right now. */
    public function activeForStudent(int $studentId): array
    {
        return $this->all(
            self::SELECT . " WHERE gp.student_id = ?
             AND gp.status IN ('approved','left_campus')
             ORDER BY gp.out_time DESC", [$studentId]
        );
    }

    public function issuedByStaff(int $staffId, int $limit = 200): array
    {
        return $this->all(
            self::SELECT . ' WHERE gp.staff_id = ? ORDER BY gp.created_at DESC LIMIT ' . (int)$limit,
            [$staffId]
        );
    }

    /** Everyone currently off campus, optionally narrowed to one department. */
    public function currentlyOutside(?int $deptId = null): array
    {
        $sql = self::SELECT . " WHERE gp.status = 'left_campus'";
        $args = [];
        if ($deptId) { $sql .= ' AND gp.dept_id = ?'; $args[] = $deptId; }
        return $this->all($sql . ' ORDER BY gp.expiry_time ASC', $args);
    }

    /** Live feed for the gate: recently approved but not yet used. */
    public function gateFeed(int $limit = 60): array
    {
        return $this->all(
            self::SELECT . " WHERE gp.status IN ('approved','left_campus')
             ORDER BY gp.created_at DESC LIMIT " . (int)$limit
        );
    }

    public function todayAtGate(int $limit = 200): array
    {
        return $this->all(
            self::SELECT . ' WHERE DATE(gp.created_at) = CURDATE()
             ORDER BY gp.created_at DESC LIMIT ' . (int)$limit
        );
    }

    public function events(int $passId): array
    {
        return $this->all(
            'SELECT * FROM pass_events WHERE pass_id = ? ORDER BY id ASC', [$passId]
        );
    }

    // ------------------------------------------------------- gate actions

    /**
     * Decide what the gate should do with a scanned pass.
     * Returns [verdict, message] where verdict is one of
     * valid | return_due | expired | used | revoked | not_found.
     */
    public function evaluate(?array $pass): array
    {
        if (!$pass) {
            return ['not_found', 'This code is not a valid college pass.'];
        }
        if ($pass['status'] === 'revoked') {
            return ['revoked', 'This pass was cancelled by the administration.'];
        }
        if ($pass['status'] === 'returned') {
            return ['used', 'This pass was already completed. The student is back on campus.'];
        }
        if ($pass['status'] === 'left_campus') {
            $late = (int)$pass['is_overdue'];
            return ['return_due', $late
                ? 'Student is outside and past the return time. Record the return.'
                : 'Student is currently outside. Record the return.'];
        }
        if ($pass['status'] === 'expired' || (int)$pass['seconds_left'] <= 0) {
            return ['expired', 'The validity of this pass has ended.'];
        }
        return ['valid', 'Pass verified. Allow the student to exit.'];
    }

    /** Record an exit. Guarded so the same pass cannot be used twice. */
    public function markExit(int $passId, int $watchmanId, string $watchmanName): bool
    {
        $n = $this->run(
            "UPDATE gate_passes
             SET status = 'left_campus', exit_time = NOW(), exit_gate_id = ?
             WHERE id = ? AND status = 'approved' AND expiry_time > NOW()",
            [$watchmanId, $passId]
        );
        if ($n) {
            Logger::passEvent($passId, 'exit', 'watchman', $watchmanId, $watchmanName,
                              'Student left the campus');
        }
        return (bool)$n;
    }

    public function markReturn(int $passId, int $watchmanId, string $watchmanName): bool
    {
        $n = $this->run(
            "UPDATE gate_passes
             SET status = 'returned', return_time = NOW(), return_gate_id = ?
             WHERE id = ? AND status = 'left_campus'",
            [$watchmanId, $passId]
        );
        if ($n) {
            $pass = $this->find($passId);
            $late = strtotime($pass['return_time']) - strtotime($pass['expiry_time']);
            $note = $late > 60
                ? 'Returned ' . fmt_mins((int)round($late / 60)) . ' after the expiry time'
                : 'Returned within the allowed time';
            Logger::passEvent($passId, 'return', 'watchman', $watchmanId, $watchmanName, $note);
        }
        return (bool)$n;
    }

    public function revoke(int $passId, int $adminId, string $adminName, string $reason): bool
    {
        $n = $this->run(
            "UPDATE gate_passes SET status = 'revoked', revoked_by = ?, revoke_reason = ?
             WHERE id = ? AND status IN ('approved','left_campus')",
            [$adminId, $reason, $passId]
        );
        if ($n) {
            Logger::passEvent($passId, 'revoked', 'admin', $adminId, $adminName, $reason);
        }
        return (bool)$n;
    }

    /**
     * Close out passes that ran out before the student ever left.
     * Cheap enough to call on every dashboard load.
     */
    public function expireStale(): int
    {
        $rows = $this->all(
            "SELECT id FROM gate_passes WHERE status = 'approved' AND expiry_time < NOW()"
        );
        foreach ($rows as $r) {
            $this->run("UPDATE gate_passes SET status = 'expired' WHERE id = ?", [$r['id']]);
            Logger::passEvent((int)$r['id'], 'expired', 'system', null, 'System',
                              'Validity ended before the student used the pass');
        }
        return count($rows);
    }

    /** Minutes a student is overdue, or 0. */
    public static function overdueMins(array $pass): int
    {
        if ($pass['status'] !== 'left_campus') return 0;
        $diff = time() - strtotime($pass['expiry_time']);
        return $diff > 0 ? (int)round($diff / 60) : 0;
    }

    // ---------------------------------------------------------- analytics

    public function stats(?int $deptId = null, ?int $staffId = null): array
    {
        $w = '1=1'; $args = [];
        if ($deptId)  { $w .= ' AND dept_id = ?';  $args[] = $deptId; }
        if ($staffId) { $w .= ' AND staff_id = ?'; $args[] = $staffId; }

        $q = fn(string $extra, array $more = []) => (int)$this->scalar(
            "SELECT COUNT(*) FROM gate_passes WHERE $w AND $extra", array_merge($args, $more)
        );

        return [
            'outside'       => $q("status = 'left_campus'"),
            'overdue'       => $q("status = 'left_campus' AND expiry_time < NOW()"),
            'issued_today'  => $q('DATE(created_at) = CURDATE()'),
            'returned_today'=> $q("status = 'returned' AND DATE(return_time) = CURDATE()"),
            'awaiting_exit' => $q("status = 'approved'"),
            'expired_today' => $q("status = 'expired' AND DATE(created_at) = CURDATE()"),
            'this_month'    => $q('YEAR(created_at) = YEAR(CURDATE()) AND MONTH(created_at) = MONTH(CURDATE())'),
        ];
    }

    /** Department cards on the admin dashboard. */
    public function outsideByDepartment(): array
    {
        return $this->all(
            "SELECT d.id, d.code, d.name,
                    SUM(gp.status = 'left_campus') AS outside,
                    SUM(gp.status = 'left_campus' AND gp.expiry_time < NOW()) AS overdue,
                    SUM(DATE(gp.created_at) = CURDATE()) AS today
             FROM departments d
             LEFT JOIN gate_passes gp ON gp.dept_id = d.id
             WHERE d.is_active = 1
             GROUP BY d.id, d.code, d.name
             ORDER BY outside DESC, d.name"
        );
    }

    public function passesPerDay(int $days = 14): array
    {
        return $this->all(
            'SELECT DATE(created_at) AS day, COUNT(*) AS total
             FROM gate_passes
             WHERE created_at >= (CURDATE() - INTERVAL ? DAY)
             GROUP BY DATE(created_at) ORDER BY day', [$days]
        );
    }

    public function byReason(int $days = 30): array
    {
        return $this->all(
            'SELECT reason_code, COUNT(*) AS total FROM gate_passes
             WHERE created_at >= (CURDATE() - INTERVAL ? DAY)
             GROUP BY reason_code ORDER BY total DESC', [$days]
        );
    }

    public function topApprovers(int $days = 30, int $limit = 8): array
    {
        return $this->all(
            'SELECT st.name, st.staff_code, d.code AS dept_code, COUNT(*) AS total
             FROM gate_passes gp
             JOIN staff st ON st.id = gp.staff_id
             JOIN departments d ON d.id = st.dept_id
             WHERE gp.created_at >= (CURDATE() - INTERVAL ? DAY)
             GROUP BY st.id, st.name, st.staff_code, d.code
             ORDER BY total DESC LIMIT ' . (int)$limit, [$days]
        );
    }

    /** Report builder used by the admin and staff report screens. */
    public function report(array $f): array
    {
        $sql = self::SELECT . ' WHERE 1=1';
        $args = [];
        foreach ([
            'dept_id'     => 'gp.dept_id = ?',
            'staff_id'    => 'gp.staff_id = ?',
            'student_id'  => 'gp.student_id = ?',
            'status'      => 'gp.status = ?',
            'reason_code' => 'gp.reason_code = ?',
        ] as $key => $clause) {
            if (!empty($f[$key])) { $sql .= " AND $clause"; $args[] = $f[$key]; }
        }
        if (!empty($f['from'])) { $sql .= ' AND DATE(gp.created_at) >= ?'; $args[] = $f['from']; }
        if (!empty($f['to']))   { $sql .= ' AND DATE(gp.created_at) <= ?'; $args[] = $f['to']; }

        return $this->all($sql . ' ORDER BY gp.created_at DESC LIMIT 1000', $args);
    }
}
