<?php
/** Staff, HOD, watchman and admin account management. */
class StaffModel extends Model
{
    public function find(int $id): ?array
    {
        return $this->one(
            'SELECT st.*, d.name AS dept_name, d.code AS dept_code
             FROM staff st JOIN departments d ON d.id = st.dept_id WHERE st.id = ?', [$id]
        );
    }

    public function all_staff(?int $deptId = null): array
    {
        $sql = 'SELECT st.*, d.name AS dept_name, d.code AS dept_code,
                   (SELECT COUNT(*) FROM staff_courses sc WHERE sc.staff_id = st.id) AS course_count
                FROM staff st JOIN departments d ON d.id = st.dept_id WHERE 1=1';
        $args = [];
        if ($deptId) { $sql .= ' AND st.dept_id = ?'; $args[] = $deptId; }
        return $this->all($sql . ' ORDER BY d.name, st.name', $args);
    }

    public function create(array $d): int
    {
        return $this->insert(
            'INSERT INTO staff (staff_code, name, password_hash, dept_id, role, designation, email, phone)
             VALUES (?,?,?,?,?,?,?,?)',
            [$d['staff_code'], $d['name'], password_hash($d['password'], PASSWORD_DEFAULT),
             $d['dept_id'], $d['role'] ?? 'staff', $d['designation'] ?? null,
             $d['email'] ?? null, $d['phone'] ?? null]
        );
    }

    public function update(int $id, array $d): int
    {
        return $this->run(
            'UPDATE staff SET name=?, dept_id=?, role=?, designation=?, email=?, phone=?, is_active=?
             WHERE id=?',
            [$d['name'], $d['dept_id'], $d['role'] ?? 'staff', $d['designation'] ?? null,
             $d['email'] ?? null, $d['phone'] ?? null, (int)($d['is_active'] ?? 1), $id]
        );
    }

    public function resetPassword(int $id, string $plain): int
    {
        return $this->run('UPDATE staff SET password_hash = ? WHERE id = ?',
                          [password_hash($plain, PASSWORD_DEFAULT), $id]);
    }

    public function deactivate(int $id): int
    {
        return $this->run('UPDATE staff SET is_active = 0 WHERE id = ?', [$id]);
    }

    /** Course load rows for one staff member. */
    public function handling(int $staffId): array
    {
        return $this->all(
            'SELECT sc.id, c.code, c.title, p.name AS prog_name, p.shift, p.section
             FROM staff_courses sc
             JOIN courses c ON c.id = sc.course_id
             JOIN programmes p ON p.id = sc.programme_id
             WHERE sc.staff_id = ? ORDER BY c.code', [$staffId]
        );
    }

    public function assignCourse(int $staffId, int $courseId, int $programmeId): int
    {
        return $this->run(
            'INSERT IGNORE INTO staff_courses (staff_id, course_id, programme_id) VALUES (?,?,?)',
            [$staffId, $courseId, $programmeId]
        );
    }

    public function unassignCourse(int $rowId, int $staffId): int
    {
        return $this->run('DELETE FROM staff_courses WHERE id = ? AND staff_id = ?', [$rowId, $staffId]);
    }

    // --------------------------------------------------------- watchmen
    public function watchmen(): array
    {
        return $this->all('SELECT * FROM watchmen ORDER BY gate, name');
    }

    public function createWatchman(array $d): int
    {
        return $this->insert(
            'INSERT INTO watchmen (username, name, password_hash, gate, phone) VALUES (?,?,?,?,?)',
            [$d['username'], $d['name'], password_hash($d['password'], PASSWORD_DEFAULT),
             $d['gate'] ?? 'Main Gate', $d['phone'] ?? null]
        );
    }

    public function updateWatchman(int $id, array $d): int
    {
        return $this->run(
            'UPDATE watchmen SET name=?, gate=?, phone=?, is_active=? WHERE id=?',
            [$d['name'], $d['gate'] ?? 'Main Gate', $d['phone'] ?? null,
             (int)($d['is_active'] ?? 1), $id]
        );
    }

    public function resetWatchmanPassword(int $id, string $plain): int
    {
        return $this->run('UPDATE watchmen SET password_hash = ? WHERE id = ?',
                          [password_hash($plain, PASSWORD_DEFAULT), $id]);
    }

    public function countStaff(): int
    {
        return (int)$this->scalar('SELECT COUNT(*) FROM staff WHERE is_active = 1');
    }

    public function countWatchmen(): int
    {
        return (int)$this->scalar('SELECT COUNT(*) FROM watchmen WHERE is_active = 1');
    }
}
