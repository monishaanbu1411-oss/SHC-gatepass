<?php
/**
 * Faculty workflow.
 *
 * Issuing a pass is deliberately two steps, mirroring how the paper pass is
 * actually used in class:
 *   1. pick the course, class section and hour, then tick students on the roster
 *   2. confirm each student's reason, out time and validity, then approve
 */
class StaffController extends Controller
{
    private $passes;
    private $lookup;
    private $students;
    private $notify;

    public function __construct()
    {
        Auth::require('staff');
        $this->passes   = $this->model('PassModel');
        $this->lookup   = $this->model('LookupModel');
        $this->students = $this->model('StudentModel');
        $this->notify   = $this->model('NotificationModel');
    }

    public function index(): void
    {
        $this->dashboard();
    }

    public function dashboard(): void
    {
        $this->passes->expireStale();
        $me = Auth::user();

        $this->render('staff/dashboard', [
            'title'   => 'Staff dashboard',
            'stats'   => $this->passes->stats(null, Auth::id()),
            'dept'    => $this->passes->stats((int)$me['dept_id']),
            'recent'  => array_slice($this->passes->issuedByStaff(Auth::id(), 12), 0, 12),
            'outside' => $this->passes->currentlyOutside((int)$me['dept_id']),
            'courses' => $this->lookup->coursesForStaff(Auth::id()),
        ]);
    }

    /** Step 1 - class and student selection. */
    public function issue(): void
    {
        $this->render('staff/issue', [
            'title'   => 'Issue movement pass',
            'courses' => $this->lookup->coursesForStaff(Auth::id()),
        ]);
    }

    /** Step 2 - approve. Called over AJAX from the confirmation modal. */
    public function approve(): void
    {
        $this->postOnly();

        $courseId    = (int)post('course_id');
        $programmeId = (int)post('programme_id');
        $hours       = post('hours', []);
        $studentIds  = array_map('intval', (array)post('student_ids', []));
        $reasonCode  = (string)post('reason_code', '');
        $reasonOther = trim((string)post('reason_other', ''));
        $destination = trim((string)post('destination', ''));
        $outTime     = (string)post('out_time', '');
        $validity    = (int)post('validity_mins', 0);

        // ---- validation -------------------------------------------------
        if (!$programmeId || !$studentIds) {
            json_out(['ok' => false, 'message' => 'Select a class and at least one student.'], 422);
        }
        if (!$this->lookup->staffHandles(Auth::id(), $courseId, $programmeId)) {
            json_out(['ok' => false, 'message' => 'You are not assigned to this course and class.'], 403);
        }
        if (!array_key_exists($reasonCode, REASONS)) {
            json_out(['ok' => false, 'message' => 'Choose a reason for going out.'], 422);
        }
        if ($reasonCode === 'other' && $reasonOther === '') {
            json_out(['ok' => false, 'message' => 'Type the reason in the box.'], 422);
        }
        if ($validity < MIN_VALIDITY || $validity > MAX_VALIDITY) {
            json_out(['ok' => false,
                'message' => 'Validity must be between ' . MIN_VALIDITY . ' minutes and '
                             . fmt_mins(MAX_VALIDITY) . '.'], 422);
        }

        $ts = strtotime($outTime ?: 'now');
        if (!$ts) $ts = time();
        // No back-dating beyond a few minutes, and no issuing far ahead.
        if ($ts < time() - 900)  $ts = time();
        if ($ts > time() + 3600) {
            json_out(['ok' => false, 'message' => 'Out time cannot be more than an hour ahead.'], 422);
        }
        $outTime = date('Y-m-d H:i:s', $ts);

        // Only students who really belong to the chosen section
        $validIds = $this->students->idsInProgramme($studentIds, $programmeId);
        if (!$validIds) {
            json_out(['ok' => false, 'message' => 'Those students are not in the selected class.'], 422);
        }

        $prog = $this->lookup->programme($programmeId);
        $me   = Auth::user();
        $hoursStr = implode(',', array_map('intval', (array)$hours));

        // ---- issue ------------------------------------------------------
        $issued = [];
        $skipped = [];
        foreach ($validIds as $sid) {
            // One live pass per student at a time.
            if ($this->passes->activeForStudent((int)$sid)) {
                $s = $this->students->find((int)$sid);
                $skipped[] = $s['register_no'] ?? $sid;
                continue;
            }

            $passId = $this->passes->issue([
                'student_id'    => (int)$sid,
                'staff_id'      => Auth::id(),
                'course_id'     => $courseId ?: null,
                'programme_id'  => $programmeId,
                'dept_id'       => (int)$prog['dept_id'],
                'hours'         => $hoursStr,
                'reason_code'   => $reasonCode,
                'reason_other'  => $reasonCode === 'other' ? $reasonOther : null,
                'destination'   => $destination ?: null,
                'out_time'      => $outTime,
                'validity_mins' => $validity,
            ]);

            $pass = $this->passes->find($passId);
            Logger::passEvent($passId, 'issued', 'staff', Auth::id(), $me['name'],
                'Approved for ' . reason_label($reasonCode, $reasonOther));
            $this->notify->announceIssue($pass, $me);
            $issued[] = $pass;
        }

        Logger::activity('staff', Auth::id(), $me['name'], 'issue_pass', 'gate_passes', null,
            count($issued) . ' pass(es) issued for ' . LookupModel::progLabel($prog));

        if (!$issued) {
            json_out(['ok' => false,
                'message' => 'Those students already hold a live pass: ' . implode(', ', $skipped)], 409);
        }

        json_out([
            'ok'      => true,
            'count'   => count($issued),
            'skipped' => $skipped,
            'passes'  => array_map(fn($p) => [
                'id'       => (int)$p['id'],
                'uid'      => $p['pass_uid'],
                'student'  => $p['student_name'],
                'register' => $p['register_no'],
                'expiry'   => fmt_time($p['expiry_time']),
                'view'     => url('pass/view/' . $p['pass_uid']),
            ], $issued),
            'message' => count($issued) === 1
                ? 'Pass approved. The student, the HOD and the gate have been alerted.'
                : count($issued) . ' passes approved. The students, the HOD and the gate have been alerted.',
        ]);
    }

    /** Live department monitor. HODs see the whole department. */
    public function monitor(): void
    {
        $this->passes->expireStale();
        $me = Auth::user();
        $deptId = (int)$me['dept_id'];

        $outside = Auth::isHod()
            ? $this->passes->currentlyOutside($deptId)
            : array_filter($this->passes->currentlyOutside($deptId),
                           fn($p) => (int)$p['staff_id'] === Auth::id());

        $this->render('staff/monitor', [
            'title'   => Auth::isHod() ? 'Department movement monitor' : 'Students you sent out',
            'outside' => array_values($outside),
            'stats'   => $this->passes->stats($deptId),
            'isHod'   => Auth::isHod(),
        ]);
    }

    /** Every pass this staff member has issued. */
    public function history(): void
    {
        $this->render('staff/history', [
            'title'  => 'Passes you issued',
            'passes' => $this->passes->issuedByStaff(Auth::id(), 500),
        ]);
    }

    public function notifications(): void
    {
        $this->notify->markRead('staff', Auth::id());
        $this->render('shared/notifications', [
            'title' => 'Notifications',
            'items' => $this->notify->inbox('staff', Auth::id(), 60),
        ]);
    }

    /** Roster + full class list, used by the students screen. */
    public function students(): void
    {
        $me = Auth::user();
        $this->render('staff/students', [
            'title'    => 'Students',
            'students' => $this->students->search(trim((string)get('q', '')), (int)$me['dept_id'], 500),
            'q'        => (string)get('q', ''),
        ]);
    }
}
