<?php
/** Sign in and sign out for all four roles. */
class AuthController extends Controller
{
    public function index(): void
    {
        if (Auth::check()) redirect(Auth::home());
        redirect('login');
    }

    public function login(): void
    {
        if (Auth::check()) redirect(Auth::home());

        $role = get('as', 'student');
        if (!in_array($role, ['student', 'staff', 'watchman', 'admin'], true)) {
            $role = 'student';
        }

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            Csrf::check();
            $role       = post('role', 'student');
            $identifier = trim((string)post('identifier', ''));
            $secret     = (string)post('secret', '');

            if ($identifier === '' || $secret === '') {
                flash('danger', 'Enter both fields to sign in.');
                redirect('login?as=' . urlencode($role));
            }

            [$ok, $result] = Auth::attempt($role, $identifier, $secret);
            if (!$ok) {
                flash('danger', $result);
                redirect('login?as=' . urlencode($role));
            }
            redirect(Auth::home($role));
        }

        $this->render('auth/login', ['title' => 'Sign in', 'role' => $role], null);
    }

    public function logout(): void
    {
        Auth::logout();
    }
}
