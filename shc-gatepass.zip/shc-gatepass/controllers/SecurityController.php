<?php
/**
 * Gate security. Built for a phone held in one hand at the gate: big targets,
 * one decision per screen, and a verdict that reads correctly from arm's length.
 */
class SecurityController extends Controller
{
    private $passes;
    private $notify;

    public function __construct()
    {
        Auth::require('watchman');
        $this->passes = $this->model('PassModel');
        $this->notify = $this->model('NotificationModel');
    }

    public function index(): void
    {
        $this->dashboard();
    }

    /** Alert feed: passes approved by faculty, newest first. */
    public function dashboard(): void
    {
        $this->passes->expireStale();
        $this->render('security/dashboard', [
            'title'   => 'Gate alerts',
            'feed'    => $this->passes->gateFeed(60),
            'stats'   => $this->passes->stats(),
            'outside' => $this->passes->currentlyOutside(),
        ]);
    }

    public function scan(): void
    {
        $this->render('security/scan', ['title' => 'Scan pass']);
    }

    /** Full pass copy, with print and save controls. */
    public function pass(string $uid = ''): void
    {
        $pass = $this->passes->findByUid($uid);
        if (!$pass) {
            flash('danger', 'That pass could not be found.');
            redirect('security/dashboard');
        }
        [$verdict, $message] = $this->passes->evaluate($pass);

        $this->render('security/pass', [
            'title'   => 'Pass ' . $pass['pass_uid'],
            'pass'    => $pass,
            'verdict' => $verdict,
            'message' => $message,
            'events'  => $this->passes->events((int)$pass['id']),
        ]);
    }

    /**
     * Verify a scanned code. Accepts the QR payload, the pass id or a barcode
     * reading, and returns the verdict the gate screen colours itself with.
     */
    public function verify(): void
    {
        $this->postOnly();
        $this->passes->expireStale();

        $raw  = trim((string)post('code', ''));
        $pass = $this->passes->resolveScan($raw);
        [$verdict, $message] = $this->passes->evaluate($pass);

        if ($pass) {
            Logger::passEvent((int)$pass['id'], 'scanned', 'watchman', Auth::id(),
                              Auth::user()['name'], 'Verdict: ' . $verdict);
        } else {
            Logger::activity('watchman', Auth::id(), Auth::user()['name'], 'scan_invalid',
                             null, null, 'Unrecognised code: ' . substr($raw, 0, 60));
        }

        json_out([
            'ok'      => in_array($verdict, ['valid', 'return_due'], true),
            'verdict' => $verdict,
            'message' => $message,
            'pass'    => $pass ? $this->cardData($pass) : null,
        ]);
    }

    /** Record the exit. */
    public function allow_exit(): void
    {
        $this->postOnly();
        $pass = $this->passes->findByUid((string)post('uid', ''));
        if (!$pass) json_out(['ok' => false, 'message' => 'Pass not found.'], 404);

        $me = Auth::user();
        if (!$this->passes->markExit((int)$pass['id'], Auth::id(), $me['name'])) {
            [$v, $m] = $this->passes->evaluate($this->passes->find((int)$pass['id']));
            json_out(['ok' => false, 'verdict' => $v, 'message' => $m], 409);
        }

        $fresh = $this->passes->find((int)$pass['id']);
        $this->notify->announceExit($fresh, $me['name'] . ' - ' . ($me['gate'] ?? 'Gate'));
        Logger::activity('watchman', Auth::id(), $me['name'], 'allow_exit', 'gate_passes',
                         (int)$pass['id'], $fresh['register_no']);

        json_out([
            'ok'      => true,
            'message' => $fresh['student_name'] . ' may exit. Return time '
                         . fmt_time($fresh['expiry_time']) . '.',
            'pass'    => $this->cardData($fresh),
        ]);
    }

    /** Record the return. */
    public function record_return(): void
    {
        $this->postOnly();
        $pass = $this->passes->findByUid((string)post('uid', ''));
        if (!$pass) json_out(['ok' => false, 'message' => 'Pass not found.'], 404);

        $late = PassModel::overdueMins($pass) > 0;
        $me = Auth::user();
        if (!$this->passes->markReturn((int)$pass['id'], Auth::id(), $me['name'])) {
            [$v, $m] = $this->passes->evaluate($this->passes->find((int)$pass['id']));
            json_out(['ok' => false, 'verdict' => $v, 'message' => $m], 409);
        }

        $fresh = $this->passes->find((int)$pass['id']);
        $this->notify->announceReturn($fresh, $me['name'] . ' - ' . ($me['gate'] ?? 'Gate'), $late);
        Logger::activity('watchman', Auth::id(), $me['name'], 'record_return', 'gate_passes',
                         (int)$pass['id'], $fresh['register_no']);

        $mins = (int)round((strtotime($fresh['return_time']) - strtotime($fresh['exit_time'])) / 60);
        json_out([
            'ok'      => true,
            'message' => $fresh['student_name'] . ' is back on campus. Outside for ' . fmt_mins(max(0, $mins)) . '.',
            'pass'    => $this->cardData($fresh),
        ]);
    }

    public function outside(): void
    {
        $this->render('security/outside', [
            'title'   => 'Students outside campus',
            'outside' => $this->passes->currentlyOutside(),
        ]);
    }

    public function today(): void
    {
        $this->render('security/today', [
            'title'  => "Today's passes",
            'passes' => $this->passes->todayAtGate(300),
        ]);
    }

    public function notifications(): void
    {
        $this->notify->markRead('watchman', Auth::id());
        $this->render('shared/notifications', [
            'title' => 'Gate alerts',
            'items' => $this->notify->inbox('watchman', Auth::id(), 60),
        ]);
    }

    /** The subset of pass fields the scan screen renders. */
    private function cardData(array $p): array
    {
        return [
            'uid'         => $p['pass_uid'],
            'student'     => $p['student_name'],
            'register'    => $p['register_no'],
            'dept'        => $p['dept_name'],
            'programme'   => $p['prog_name'] . ' - Shift ' . $p['shift'],
            'photo'       => photo_url($p['student_photo']),
            'initials'    => initials($p['student_name']),
            'staff'       => $p['staff_name'],
            'reason'      => reason_label($p['reason_code'], $p['reason_other']),
            'destination' => $p['destination'],
            'out_time'    => fmt_time($p['out_time']),
            'expiry'      => fmt_time($p['expiry_time']),
            'exit_time'   => $p['exit_time'] ? fmt_time($p['exit_time']) : null,
            'status'      => $p['status'],
            'status_text' => status_label($p['status']),
            'seconds_left'=> (int)$p['seconds_left'],
            'overdue'     => PassModel::overdueMins($p),
            'blood_group' => $p['blood_group'],
            'phone'       => $p['student_phone'],
            'parent'      => $p['parent_phone'],
            'view_url'    => url('security/pass/' . $p['pass_uid']),
            'print_url'   => url('pass/print/' . $p['pass_uid']),
        ];
    }
}
