<?php
/** The pass document itself: on-screen copy and the printable version. */
class PassController extends Controller
{
    private $passes;

    public function __construct()
    {
        Auth::require();                       // any signed-in role
        $this->passes = $this->model('PassModel');
    }

    /** Who is allowed to look at a given pass. */
    private function load(string $uid): array
    {
        $pass = $this->passes->findByUid($uid);
        if (!$pass) {
            http_response_code(404);
            require ROOT_PATH . '/views/errors/404.php';
            exit;
        }
        $type = Auth::type();
        $allowed = match ($type) {
            'student'  => (int)$pass['student_id'] === Auth::id(),
            'staff'    => (int)$pass['staff_id'] === Auth::id()
                          || (Auth::isHod() && (int)$pass['dept_id'] === (int)Auth::user()['dept_id']),
            'watchman', 'admin' => true,
            default    => false,
        };
        if (!$allowed) {
            http_response_code(403);
            exit('You do not have access to this pass.');
        }
        return $pass;
    }

    public function view(string $uid = ''): void
    {
        $pass = $this->load($uid);
        $this->render('pass/document', [
            'title'   => 'Movement pass ' . $pass['pass_uid'],
            'pass'    => $pass,
            'events'  => $this->passes->events((int)$pass['id']),
            'barcode' => Barcode::svg($pass['pass_uid'], 2, 54),
            'print'   => false,
        ], null);
    }

    /** Same document, print stylesheet, opens the print dialog on load. */
    public function print(string $uid = ''): void
    {
        $pass = $this->load($uid);
        Logger::passEvent((int)$pass['id'], 'printed', Auth::type(), Auth::id(),
                          Auth::user()['name'], 'Pass copy printed');
        $this->render('pass/document', [
            'title'   => 'Movement pass ' . $pass['pass_uid'],
            'pass'    => $pass,
            'events'  => $this->passes->events((int)$pass['id']),
            'barcode' => Barcode::svg($pass['pass_uid'], 2, 54),
            'print'   => true,
        ], null);
    }

    /** Standalone SVG barcode, handy for hand scanners and PDF pipelines. */
    public function barcode(string $uid = ''): void
    {
        $pass = $this->load($uid);
        header('Content-Type: image/svg+xml');
        header('Cache-Control: no-store');
        echo Barcode::svg($pass['pass_uid'], 2, 70);
        exit;
    }
}
