<?php
/** Student-facing screens: live pass, history and alerts. */
class StudentController extends Controller
{
    private $passes;
    private $students;
    private $notify;

    public function __construct()
    {
        Auth::require('student');
        $this->passes   = $this->model('PassModel');
        $this->students = $this->model('StudentModel');
        $this->notify   = $this->model('NotificationModel');
    }

    public function index(): void
    {
        $this->dashboard();
    }

    public function dashboard(): void
    {
        $this->passes->expireStale();
        $all = $this->passes->forStudent(Auth::id(), null, 50);

        $this->render('student/dashboard', [
            'title'   => 'My dashboard',
            'me'      => $this->students->find(Auth::id()),
            'active'  => $this->passes->activeForStudent(Auth::id()),
            'recent'  => array_slice($all, 0, 6),
            'counts'  => [
                'total'    => count($all),
                'month'    => count(array_filter($all, fn($p) => date('Y-m', strtotime($p['created_at'])) === date('Y-m'))),
                'returned' => count(array_filter($all, fn($p) => $p['status'] === 'returned')),
                'expired'  => count(array_filter($all, fn($p) => $p['status'] === 'expired')),
            ],
        ]);
    }

    /** The live pass, with countdown, QR and barcode. */
    public function passes(): void
    {
        $this->passes->expireStale();
        $this->render('student/passes', [
            'title'  => 'My approved passes',
            'active' => $this->passes->activeForStudent(Auth::id()),
        ]);
    }

    public function history(): void
    {
        $this->render('student/history', [
            'title'  => 'Pass history',
            'passes' => $this->passes->forStudent(Auth::id(), null, 300),
        ]);
    }

    public function profile(): void
    {
        $this->render('student/profile', [
            'title' => 'My profile',
            'me'    => $this->students->find(Auth::id()),
        ]);
    }

    public function notifications(): void
    {
        $this->notify->markRead('student', Auth::id());
        $this->render('shared/notifications', [
            'title' => 'Notifications',
            'items' => $this->notify->inbox('student', Auth::id(), 60),
        ]);
    }
}
