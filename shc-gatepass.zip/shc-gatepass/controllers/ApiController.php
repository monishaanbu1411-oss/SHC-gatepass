<?php
/** AJAX endpoints shared by every dashboard. */
class ApiController extends Controller
{
    public function __construct()
    {
        Auth::require();
    }

    /** Roster for a class section - drives step 1 of the pass form. */
    public function roster(string $programmeId = '0'): void
    {
        Auth::require('staff', 'admin');
        $progId = (int)$programmeId;
        $lookup = $this->model('LookupModel');
        $prog   = $lookup->programme($progId);
        if (!$prog) json_out(['ok' => false, 'message' => 'Class not found.'], 404);

        $passes   = $this->model('PassModel');
        $students = $this->model('StudentModel');

        // Mark students who already hold a live pass so faculty cannot double-issue.
        $busy = [];
        foreach ($passes->currentlyOutside((int)$prog['dept_id']) as $p) {
            $busy[(int)$p['student_id']] = 'outside';
        }
        foreach ($students->roster($progId) as $s) {
            if (!isset($busy[(int)$s['id']]) && $passes->activeForStudent((int)$s['id'])) {
                $busy[(int)$s['id']] = 'holds a pass';
            }
        }

        $rows = array_map(fn($s) => [
            'id'       => (int)$s['id'],
            'register' => $s['register_no'],
            'name'     => $s['name'],
            'photo'    => photo_url($s['photo']),
            'initials' => initials($s['name']),
            'busy'     => $busy[(int)$s['id']] ?? null,
        ], $students->roster($progId));

        json_out([
            'ok'        => true,
            'programme' => LookupModel::progLabel($prog),
            'count'     => count($rows),
            'students'  => $rows,
        ]);
    }

    /** Class sections a staff member takes for a chosen course. */
    public function programmes(string $courseId = '0'): void
    {
        Auth::require('staff');
        $lookup = $this->model('LookupModel');
        $rows = $lookup->programmesForStaffCourse(Auth::id(), (int)$courseId);
        json_out([
            'ok'   => true,
            'rows' => array_map(fn($p) => [
                'id'    => (int)$p['id'],
                'label' => LookupModel::progLabel($p),
            ], $rows),
        ]);
    }

    /** Polled by every dashboard for the live bell. */
    public function notifications(): void
    {
        $notify = $this->model('NotificationModel');
        $lastId = (int)get('since', 0);
        $type   = Auth::type();

        $new = $lastId ? $notify->since($type, Auth::id(), $lastId) : [];
        $all = $notify->inbox($type, Auth::id(), 15);

        json_out([
            'ok'     => true,
            'unread' => $notify->unreadCount($type, Auth::id()),
            'lastId' => (int)($all[0]['id'] ?? $lastId),
            'new'    => array_map(fn($n) => [
                'id'    => (int)$n['id'],
                'title' => $n['title'],
                'body'  => $n['body'],
                'icon'  => $n['icon'],
                'link'  => $n['link'] ? url($n['link']) : null,
            ], $new),
            'items'  => array_map(fn($n) => [
                'id'    => (int)$n['id'],
                'title' => $n['title'],
                'body'  => $n['body'],
                'icon'  => $n['icon'],
                'read'  => (int)$n['is_read'],
                'when'  => self::ago($n['created_at']),
                'link'  => $n['link'] ? url($n['link']) : null,
            ], $all),
        ]);
    }

    public function read(): void
    {
        $this->postOnly();
        $notify = $this->model('NotificationModel');
        $notify->markRead(Auth::type(), Auth::id(), (int)post('id') ?: null);
        json_out(['ok' => true]);
    }

    /** Live counters for the admin and HOD screens. */
    public function counters(): void
    {
        $passes = $this->model('PassModel');
        $passes->expireStale();
        $deptId = Auth::type() === 'staff' ? (int)Auth::user()['dept_id'] : null;

        json_out([
            'ok'     => true,
            'stats'  => $passes->stats($deptId),
            'byDept' => Auth::type() === 'admin' ? $passes->outsideByDepartment() : [],
            'time'   => date('h:i:s A'),
        ]);
    }

    /** Rows for the live "students outside" tables, refreshed in place. */
    public function outside(): void
    {
        $passes = $this->model('PassModel');
        $deptId = Auth::type() === 'staff'
            ? (int)Auth::user()['dept_id']
            : ((int)get('dept', 0) ?: null);

        json_out([
            'ok'   => true,
            'rows' => array_map(fn($p) => [
                'uid'      => $p['pass_uid'],
                'name'     => $p['student_name'],
                'register' => $p['register_no'],
                'dept'     => $p['dept_code'],
                'photo'    => photo_url($p['student_photo']),
                'initials' => initials($p['student_name']),
                'staff'    => $p['staff_name'],
                'reason'   => reason_label($p['reason_code'], $p['reason_other']),
                'out'      => fmt_time($p['exit_time'] ?: $p['out_time']),
                'expiry'   => fmt_time($p['expiry_time']),
                'seconds'  => (int)$p['seconds_left'],
                'overdue'  => PassModel::overdueMins($p),
                'url'      => url('pass/view/' . $p['pass_uid']),
            ], $passes->currentlyOutside($deptId)),
        ]);
    }

    private static function ago(string $dt): string
    {
        $s = time() - strtotime($dt);
        if ($s < 60)    return 'just now';
        if ($s < 3600)  return intdiv($s, 60) . ' min ago';
        if ($s < 86400) return intdiv($s, 3600) . ' h ago';
        return date('d M, h:i A', strtotime($dt));
    }
}
