<?php
/** Administration: live analytics, account management, audit logs, reports. */
class AdminController extends Controller
{
    private $passes;
    private $students;
    private $staff;
    private $lookup;
    private $notify;
    private $logs;

    public function __construct()
    {
        Auth::require('admin');
        $this->passes   = $this->model('PassModel');
        $this->students = $this->model('StudentModel');
        $this->staff    = $this->model('StaffModel');
        $this->lookup   = $this->model('LookupModel');
        $this->notify   = $this->model('NotificationModel');
        $this->logs     = $this->model('LogModel');
    }

    public function index(): void
    {
        $this->dashboard();
    }

    public function dashboard(): void
    {
        $this->passes->expireStale();

        $this->render('admin/dashboard', [
            'title'      => 'Administration',
            'stats'      => $this->passes->stats(),
            'totals'     => [
                'students' => $this->students->countAll(),
                'staff'    => $this->staff->countStaff(),
                'watchmen' => $this->staff->countWatchmen(),
                'depts'    => count($this->lookup->departments()),
            ],
            'byDept'     => $this->passes->outsideByDepartment(),
            'perDay'     => $this->passes->passesPerDay(14),
            'byReason'   => $this->passes->byReason(30),
            'approvers'  => $this->passes->topApprovers(30),
            'outside'    => $this->passes->currentlyOutside(),
        ]);
    }

    /** Drill-down behind a department card. Returns rendered rows over AJAX. */
    public function department(string $id = '0'): void
    {
        $deptId  = (int)$id;
        $outside = $this->passes->currentlyOutside($deptId);
        $dept    = null;
        foreach ($this->lookup->departments() as $d) {
            if ((int)$d['id'] === $deptId) { $dept = $d; break; }
        }
        if (!$dept) json_out(['ok' => false, 'message' => 'Department not found.'], 404);

        json_out([
            'ok'      => true,
            'dept'    => $dept['name'],
            'count'   => count($outside),
            'students'=> array_map(fn($p) => [
                'uid'        => $p['pass_uid'],
                'name'       => $p['student_name'],
                'register'   => $p['register_no'],
                'programme'  => $p['prog_name'] . ' - Shift ' . $p['shift'],
                'photo'      => photo_url($p['student_photo']),
                'initials'   => initials($p['student_name']),
                'staff'      => $p['staff_name'],
                'reason'     => reason_label($p['reason_code'], $p['reason_other']),
                'out_time'   => fmt_time($p['exit_time'] ?: $p['out_time']),
                'expiry'     => fmt_time($p['expiry_time']),
                'seconds'    => (int)$p['seconds_left'],
                'overdue'    => PassModel::overdueMins($p),
                'url'        => url('pass/view/' . $p['pass_uid']),
            ], $outside),
        ]);
    }

    // ------------------------------------------------------------ students

    public function students(): void
    {
        $this->render('admin/students', [
            'title'      => 'Student accounts',
            'students'   => $this->students->search(trim((string)get('q', '')),
                                                    (int)get('dept', 0) ?: null, 400),
            'departments'=> $this->lookup->departments(),
            'programmes' => $this->lookup->programmes(),
            'q'          => (string)get('q', ''),
            'dept'       => (int)get('dept', 0),
        ]);
    }

    public function save_student(): void
    {
        $this->postOnly();
        $id = (int)post('id', 0);
        $d  = [
            'register_no'  => strtoupper(trim((string)post('register_no'))),
            'name'         => trim((string)post('name')),
            'dob'          => (string)post('dob'),
            'dept_id'      => (int)post('dept_id'),
            'programme_id' => (int)post('programme_id'),
            'roll_index'   => (int)post('roll_index') ?: null,
            'gender'       => post('gender') ?: null,
            'phone'        => trim((string)post('phone')) ?: null,
            'parent_phone' => trim((string)post('parent_phone')) ?: null,
            'email'        => trim((string)post('email')) ?: null,
            'blood_group'  => trim((string)post('blood_group')) ?: null,
            'residence'    => post('residence') ?: 'Day Scholar',
            'is_active'    => (int)post('is_active', 1),
        ];

        if ($d['name'] === '' || $d['register_no'] === '' || !$d['dept_id'] || !$d['programme_id']) {
            json_out(['ok' => false, 'message' => 'Name, register number, department and class are required.'], 422);
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d['dob'])) {
            json_out(['ok' => false, 'message' => 'Enter the date of birth as YYYY-MM-DD.'], 422);
        }

        try {
            if ($id) {
                $this->students->update($id, $d);
                $msg = 'Student updated.';
            } else {
                $id = $this->students->create($d);
                $msg = 'Student added. They sign in with their register number and date of birth.';
            }
        } catch (PDOException $e) {
            json_out(['ok' => false, 'message' => 'That register number is already in use.'], 409);
        }

        Logger::activity('admin', Auth::id(), Auth::user()['name'],
                         post('id') ? 'update_student' : 'create_student', 'students', $id, $d['register_no']);
        json_out(['ok' => true, 'message' => $msg, 'id' => $id]);
    }

    public function delete_student(): void
    {
        $this->postOnly();
        $id = (int)post('id');
        $this->students->delete($id);
        Logger::activity('admin', Auth::id(), Auth::user()['name'], 'deactivate_student', 'students', $id);
        json_out(['ok' => true, 'message' => 'Account deactivated. Records are kept for auditing.']);
    }

    /** Bulk import from CSV: register_no,name,dob,programme_id[,phone,parent_phone,blood_group] */
    public function import_students(): void
    {
        $this->postOnly();
        if (empty($_FILES['file']['tmp_name']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
            json_out(['ok' => false, 'message' => 'Choose a CSV file to import.'], 422);
        }
        if ($_FILES['file']['size'] > 5 * 1024 * 1024) {
            json_out(['ok' => false, 'message' => 'The file must be 5 MB or smaller.'], 422);
        }

        $progs = [];
        foreach ($this->lookup->programmes() as $p) $progs[(int)$p['id']] = $p;

        $fh = fopen($_FILES['file']['tmp_name'], 'r');
        $added = 0; $failed = [];
        $line = 0;
        while (($row = fgetcsv($fh)) !== false) {
            $line++;
            if ($line === 1 && stripos((string)$row[0], 'register') !== false) continue;  // header
            if (count($row) < 4) { $failed[] = "line $line: not enough columns"; continue; }

            $progId = (int)$row[3];
            if (!isset($progs[$progId])) { $failed[] = "line $line: unknown class id $progId"; continue; }

            try {
                $this->students->create([
                    'register_no'  => strtoupper(trim($row[0])),
                    'name'         => trim($row[1]),
                    'dob'          => trim($row[2]),
                    'programme_id' => $progId,
                    'dept_id'      => (int)$progs[$progId]['dept_id'],
                    'phone'        => isset($row[4]) ? trim($row[4]) : null,
                    'parent_phone' => isset($row[5]) ? trim($row[5]) : null,
                    'blood_group'  => isset($row[6]) ? trim($row[6]) : null,
                ]);
                $added++;
            } catch (PDOException $e) {
                $failed[] = 'line ' . $line . ': ' . trim($row[0]) . ' already exists';
            }
        }
        fclose($fh);

        Logger::activity('admin', Auth::id(), Auth::user()['name'], 'import_students', 'students', null,
                         "$added added, " . count($failed) . ' skipped');
        json_out(['ok' => true, 'added' => $added, 'failed' => array_slice($failed, 0, 25),
                  'message' => "$added students added" . ($failed ? ', ' . count($failed) . ' skipped.' : '.')]);
    }

    // --------------------------------------------------------------- staff

    public function staff(): void
    {
        $this->render('admin/staff', [
            'title'      => 'Staff accounts',
            'staff'      => $this->staff->all_staff((int)get('dept', 0) ?: null),
            'departments'=> $this->lookup->departments(),
            'courses'    => $this->lookup->allCourses(),
            'programmes' => $this->lookup->programmes(),
            'dept'       => (int)get('dept', 0),
        ]);
    }

    public function save_staff(): void
    {
        $this->postOnly();
        $id = (int)post('id', 0);
        $d = [
            'staff_code'  => strtoupper(trim((string)post('staff_code'))),
            'name'        => trim((string)post('name')),
            'dept_id'     => (int)post('dept_id'),
            'role'        => post('role') === 'hod' ? 'hod' : 'staff',
            'designation' => trim((string)post('designation')) ?: null,
            'email'       => trim((string)post('email')) ?: null,
            'phone'       => trim((string)post('phone')) ?: null,
            'is_active'   => (int)post('is_active', 1),
            'password'    => (string)post('password', ''),
        ];
        if ($d['name'] === '' || !$d['dept_id']) {
            json_out(['ok' => false, 'message' => 'Name and department are required.'], 422);
        }

        try {
            if ($id) {
                $this->staff->update($id, $d);
                if ($d['password'] !== '') $this->staff->resetPassword($id, $d['password']);
                $msg = 'Staff record updated.';
            } else {
                if (strlen($d['password']) < 6) {
                    json_out(['ok' => false, 'message' => 'Set a password of at least 6 characters.'], 422);
                }
                $id = $this->staff->create($d);
                $msg = 'Staff account created.';
            }
        } catch (PDOException $e) {
            json_out(['ok' => false, 'message' => 'That staff code is already in use.'], 409);
        }

        Logger::activity('admin', Auth::id(), Auth::user()['name'], 'save_staff', 'staff', $id, $d['staff_code']);
        json_out(['ok' => true, 'message' => $msg]);
    }

    public function assign_course(): void
    {
        $this->postOnly();
        $staffId = (int)post('staff_id');
        $this->staff->assignCourse($staffId, (int)post('course_id'), (int)post('programme_id'));
        Logger::activity('admin', Auth::id(), Auth::user()['name'], 'assign_course', 'staff', $staffId);
        json_out(['ok' => true, 'message' => 'Course assigned. It now appears in that faculty member\'s pass form.']);
    }

    public function staff_courses(string $id = '0'): void
    {
        json_out(['ok' => true, 'rows' => $this->staff->handling((int)$id)]);
    }

    public function unassign_course(): void
    {
        $this->postOnly();
        $this->staff->unassignCourse((int)post('row_id'), (int)post('staff_id'));
        json_out(['ok' => true, 'message' => 'Course removed.']);
    }

    // ------------------------------------------------------------ watchmen

    public function watchmen(): void
    {
        $this->render('admin/watchmen', [
            'title'    => 'Gate security accounts',
            'watchmen' => $this->staff->watchmen(),
        ]);
    }

    public function save_watchman(): void
    {
        $this->postOnly();
        $id = (int)post('id', 0);
        $d = [
            'username'  => strtolower(trim((string)post('username'))),
            'name'      => trim((string)post('name')),
            'gate'      => trim((string)post('gate')) ?: 'Main Gate',
            'phone'     => trim((string)post('phone')) ?: null,
            'is_active' => (int)post('is_active', 1),
            'password'  => (string)post('password', ''),
        ];
        if ($d['name'] === '') json_out(['ok' => false, 'message' => 'Enter a name.'], 422);

        try {
            if ($id) {
                $this->staff->updateWatchman($id, $d);
                if ($d['password'] !== '') $this->staff->resetWatchmanPassword($id, $d['password']);
                $msg = 'Security account updated.';
            } else {
                if (strlen($d['password']) < 6) {
                    json_out(['ok' => false, 'message' => 'Set a password of at least 6 characters.'], 422);
                }
                $id = $this->staff->createWatchman($d);
                $msg = 'Security account created.';
            }
        } catch (PDOException $e) {
            json_out(['ok' => false, 'message' => 'That username is already taken.'], 409);
        }
        Logger::activity('admin', Auth::id(), Auth::user()['name'], 'save_watchman', 'watchmen', $id);
        json_out(['ok' => true, 'message' => $msg]);
    }

    // ------------------------------------------------------- passes + logs

    /** Emergency override: cancel a live pass. */
    public function revoke(): void
    {
        $this->postOnly();
        $uid    = (string)post('uid', '');
        $reason = trim((string)post('reason', ''));
        if ($reason === '') {
            json_out(['ok' => false, 'message' => 'Give a reason for cancelling the pass.'], 422);
        }

        $pass = $this->passes->findByUid($uid);
        if (!$pass) json_out(['ok' => false, 'message' => 'Pass not found.'], 404);

        $me = Auth::user();
        if (!$this->passes->revoke((int)$pass['id'], Auth::id(), $me['name'], $reason)) {
            json_out(['ok' => false, 'message' => 'This pass is already closed and cannot be cancelled.'], 409);
        }
        $this->notify->announceRevoke($pass, $me['name'], $reason);
        Logger::activity('admin', Auth::id(), $me['name'], 'revoke_pass', 'gate_passes',
                         (int)$pass['id'], $reason);

        json_out(['ok' => true, 'message' => 'Pass cancelled. The student and the gate have been told.']);
    }

    public function passes(): void
    {
        $filters = [
            'dept_id'     => (int)get('dept', 0) ?: null,
            'status'      => get('status') ?: null,
            'reason_code' => get('reason') ?: null,
            'from'        => get('from') ?: null,
            'to'          => get('to') ?: null,
        ];
        $this->render('admin/passes', [
            'title'      => 'All movement passes',
            'passes'     => $this->passes->report($filters),
            'departments'=> $this->lookup->departments(),
            'filters'    => $filters,
        ]);
    }

    public function logs(): void
    {
        $tab = get('tab', 'activity');
        $this->render('admin/logs', [
            'title'    => 'System logs',
            'tab'      => $tab,
            'activity' => $this->logs->activity(200, trim((string)get('q', ''))),
            'logins'   => $this->logs->logins(200),
            'scans'    => $this->logs->scans(200),
            'q'        => (string)get('q', ''),
        ]);
    }

    public function notifications(): void
    {
        $this->notify->markRead('admin', Auth::id());
        $this->render('shared/notifications', [
            'title' => 'Notifications',
            'items' => $this->notify->inbox('admin', Auth::id(), 60),
        ]);
    }

    /** CSV export of whatever the pass filter currently shows. */
    public function export(): void
    {
        $rows = $this->passes->report([
            'dept_id'     => (int)get('dept', 0) ?: null,
            'status'      => get('status') ?: null,
            'reason_code' => get('reason') ?: null,
            'from'        => get('from') ?: null,
            'to'          => get('to') ?: null,
        ]);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="movement-passes-' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Pass ID', 'Register No', 'Student', 'Department', 'Class', 'Approved by',
                       'Reason', 'Out time', 'Validity', 'Expiry', 'Exit time', 'Return time', 'Status']);
        foreach ($rows as $p) {
            fputcsv($out, [
                $p['pass_uid'], $p['register_no'], $p['student_name'], $p['dept_name'],
                $p['prog_name'] . ' Shift ' . $p['shift'], $p['staff_name'],
                reason_label($p['reason_code'], $p['reason_other']),
                fmt_dt($p['out_time']), fmt_mins((int)$p['validity_mins']), fmt_dt($p['expiry_time']),
                fmt_dt($p['exit_time']), fmt_dt($p['return_time']), status_label($p['status']),
            ]);
        }
        fclose($out);
        Logger::activity('admin', Auth::id(), Auth::user()['name'], 'export_csv', 'gate_passes', null,
                         count($rows) . ' rows');
        exit;
    }
}
