/* =====================================================================
   Shared front-end behaviour.

   This file is loaded in the <head>, because each view carries its own
   inline script that runs while the body is still being parsed and needs
   these helpers to already exist. Anything that touches the page itself
   therefore waits for DOMContentLoaded.
   ===================================================================== */
(function () {
  'use strict';

  const SHC = window.SHC || {};
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const url = (p) => SHC.base + '/' + String(p).replace(/^\//, '');

  /** POST helper that always carries the CSRF token. */
  async function api(path, data) {
    const body = new FormData();
    body.append('csrf_token', SHC.csrf);
    Object.entries(data || {}).forEach(([k, v]) => {
      if (Array.isArray(v)) v.forEach((x) => body.append(k + '[]', x));
      else if (v !== null && v !== undefined) body.append(k, v);
    });
    const res = await fetch(url(path), {
      method: 'POST',
      body,
      headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': SHC.csrf },
    });
    try {
      return await res.json();
    } catch (e) {
      return { ok: false, message: 'The server sent an unexpected reply.' };
    }
  }

  async function apiGet(path) {
    try {
      const res = await fetch(url(path), { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      return await res.json();
    } catch (e) {
      return { ok: false, message: 'Could not reach the server.' };
    }
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  }

  const toast = (icon, title) =>
    window.Swal && Swal.fire({
      toast: true, position: 'top-end', icon, title,
      showConfirmButton: false, timer: 3200, timerProgressBar: true,
    });

  /**
   * Any element with data-countdown="<seconds remaining>" ticks down.
   * Colour shifts as the deadline nears, then flips to overdue.
   * Exposed so views can call it after injecting fresh rows.
   */
  function tickCountdowns(step) {
    $$('[data-countdown]').forEach((el) => {
      let s = parseInt(el.dataset.countdown, 10);
      if (isNaN(s)) return;
      if (step !== false) s -= 1;
      el.dataset.countdown = s;

      const over = s < 0;
      const abs = Math.abs(s);
      const hh = Math.floor(abs / 3600);
      const mm = Math.floor((abs % 3600) / 60);
      const ss = abs % 60;
      const p = (n) => String(n).padStart(2, '0');
      const text = hh > 0 ? hh + ':' + p(mm) + ':' + p(ss) : p(mm) + ':' + p(ss);

      el.textContent = over ? '+' + text + ' over' : text;
      el.classList.toggle('over', over);
      el.classList.toggle('danger', !over && s >= 0 && s <= 300);
      el.classList.toggle('warn', !over && s > 300 && s <= 900);
    });
  }

  // Published straight away, before any DOM work, so inline view scripts
  // can rely on it the instant they are parsed.
  window.SHCApp = { api, apiGet, toast, esc, url, tickCountdowns };

  function onReady(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  // ==================================================================
  //  Everything below touches the page, so it waits for the body.
  // ==================================================================
  onReady(function () {

    // ----------------------------------------------------------- theme
    const themeBtn = $('#themeToggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const now = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', now);
        try { localStorage.setItem('shc-theme', now); } catch (err) {}
      });
    }

    // ---------------------------------------------- mobile navigation
    const sb = $('#sidebar'), scrim = $('#sbScrim');
    if ($('#sbToggle') && sb && scrim) {
      $('#sbToggle').addEventListener('click', () => {
        sb.classList.add('open');
        scrim.classList.remove('d-none');
      });
      scrim.addEventListener('click', () => {
        sb.classList.remove('open');
        scrim.classList.add('d-none');
      });
    }

    // ----------------------------------------------------------- clock
    const clock = $('#liveClock');
    if (clock) {
      setInterval(() => {
        const d = new Date();
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        let h = d.getHours();
        const ap = h >= 12 ? 'PM' : 'AM';
        h = h % 12 || 12;
        const p = (n) => String(n).padStart(2, '0');
        clock.textContent = days[d.getDay()] + ', ' + p(d.getDate()) + ' ' + mon[d.getMonth()] + ' ' +
                            d.getFullYear() + ' \u00b7 ' + p(h) + ':' + p(d.getMinutes()) + ':' +
                            p(d.getSeconds()) + ' ' + ap;
      }, 1000);
    }

    // ------------------------------------------------------ countdowns
    if ($$('[data-countdown]').length) {
      tickCountdowns(false);
      setInterval(tickCountdowns, 1000);
    }

    // ----------------------------------------------- notification bell
    const bellCount = $('#bellCount');
    const bellList = $('#bellList');
    const navUnread = $('#navUnread');
    let lastId = 0;
    let firstPoll = true;

    const iconFor = (k) => ({
      check: 'circle-check', walk: 'person-walking', gate: 'door-open',
      out: 'right-from-bracket', in: 'right-to-bracket', ban: 'ban',
    })[k] || 'bell';

    function renderBell(items) {
      if (!bellList) return;
      if (!items.length) {
        bellList.innerHTML = '<div class="empty py-4"><i class="fa-regular fa-bell"></i>Nothing yet</div>';
        return;
      }
      bellList.innerHTML = items.map((n) =>
        '<a class="notif-item px-3 ' + (n.read ? '' : 'unread') + '" href="' + (n.link || '#') + '"' +
        ' style="text-decoration:none;color:inherit">' +
        '<span class="notif-dot"><i class="fa-solid fa-' + iconFor(n.icon) + '"></i></span>' +
        '<span class="flex-grow-1"><span class="notif-title d-block">' + esc(n.title) + '</span>' +
        '<span class="notif-body d-block">' + esc(n.body || '') + '</span></span>' +
        '<span class="notif-when">' + esc(n.when) + '</span></a>').join('');
    }

    async function pollNotifications() {
      const d = await apiGet('api/notifications?since=' + lastId);
      if (!d || !d.ok) return;

      if (bellCount) {
        bellCount.textContent = d.unread;
        bellCount.classList.toggle('d-none', d.unread === 0);
      }
      if (navUnread) {
        navUnread.textContent = d.unread;
        navUnread.classList.toggle('d-none', d.unread === 0);
      }
      renderBell(d.items || []);

      if (!firstPoll && d.new && d.new.length) {
        if (window.Swal) {
          d.new.forEach((n) => {
            Swal.fire({
              toast: true, position: 'top-end', icon: 'info',
              title: n.title, text: n.body || '',
              showConfirmButton: false, timer: 6000, timerProgressBar: true,
            });
          });
        }
        document.dispatchEvent(new CustomEvent('shc:notified', { detail: d.new }));
      }
      lastId = d.lastId || lastId;
      firstPoll = false;
    }

    if (bellList) {
      pollNotifications();
      setInterval(pollNotifications, 12000);
    }

    const markAll = $('#markAllRead');
    if (markAll) {
      markAll.addEventListener('click', async (e) => {
        e.preventDefault();
        await api('api/read', {});
        firstPoll = true;
        pollNotifications();
      });
    }

    // ------------------------------------------------------ DataTables
    if (window.jQuery && window.jQuery.fn && window.jQuery.fn.DataTable) {
      const dtDefaults = {
        pageLength: 25,
        lengthMenu: [10, 25, 50, 100],
        order: [],
        language: {
          search: '', searchPlaceholder: 'Search\u2026',
          emptyTable: 'Nothing to show yet',
          zeroRecords: 'No rows match that search',
          info: '_START_\u2013_END_ of _TOTAL_',
          infoEmpty: '0 rows',
          paginate: { previous: '\u2039', next: '\u203a' },
        },
      };
      $$('table[data-dt]').forEach((t) => {
        const opts = Object.assign({}, dtDefaults);
        if (t.dataset.dtOrder) opts.order = JSON.parse(t.dataset.dtOrder);
        if (t.dataset.dtNosort) {
          opts.columnDefs = [{ targets: JSON.parse(t.dataset.dtNosort), orderable: false }];
        }
        window.jQuery(t).DataTable(opts);
      });
    }
  });
})();
